// Module 22489
// Original file: 22489.js
// Size: 10.4 KB
// Purpose: Auto-extracted webpack module from TradingView library

(e, t, i) => {
  "use strict";
  i.r(t), i.d(t, {
    DEFAULT_THEME: () => h,
    getCurrentTheme: () => g,
    getStdTheme: () => P,
    getStdThemeNames: () => C,
    getStdThemedValue: () => x,
    getTheme: () => b,
    getThemeNames: () => w,
    getThemedColor: () => f,
    isStdThemeName: () => T,
    isStdThemedDefaultValue: () => M,
    isThemeExist: () => L,
    removeTheme: () => A,
    restoreTheme: () => y,
    saveTheme: () => I,
    savedThemeName: () => v,
    syncTheme: () => S,
    themeListChanged: () => E,
    themes: () => m,
    translateStdThemeName: () => k
  });
  var s = i(24377),
    o = i(48096),
    n = i(1765);

  function r() {
    return (0, n.getValue)("current_theme.name") || null
  }
  const a = i(34840);
  var l = i(24317),
    c = i(45345);
  const h = "light";
  var d = i(24633),
    u = i(11542);
  const _ = JSON.parse(
    '{"color-header-bg":"color-black","color-body-bg":"color-black","color-body-secondary-bg":"color-cold-gray-900","color-bg-primary":"color-cold-gray-850","color-bg-primary-hover":"color-cold-gray-800","color-bg-secondary":"color-cold-gray-900","color-bg-highlight":"color-cold-gray-900","color-bg-scroll-buttons":"color-cold-gray-800","color-legacy-bg-scroll-buttons":"color-cold-gray-550","color-legacy-bg-widget":"color-cold-gray-900","color-text-primary":"color-cold-gray-200","color-text-secondary":"color-cold-gray-450","color-text-tertiary":"color-cold-gray-400","color-text-disabled":"color-cold-gray-650","color-accent-content":"color-white","color-divider":"color-cold-gray-700","color-divider-hover":"color-cold-gray-800","color-divider-secondary":"color-cold-gray-800","color-box-shadow":"color-cold-gray-900","color-active-hover-text":"color-cold-gray-200","color-alert-text":"color-cold-gray-200","color-border":"color-cold-gray-750","color-border-chat-fields":"color-cold-gray-750","color-border-hover":"color-cold-gray-650","color-border-table":"color-cold-gray-800","color-brand":"color-tv-blue-500","color-brand-hover":"color-tv-blue-600","color-brand-active":"color-tv-blue-700","color-button-hover-bg":"color-cold-gray-850","color-chart-page-bg":"color-cold-gray-800","color-common-tooltip-bg":"color-cold-gray-750","color-danger":"color-ripe-red-600","color-danger-hover":"color-ripe-red-500","color-danger-active":"color-ripe-red-400","color-depthrenderer-fill-style":"color-cold-gray-150","color-depthrenderer-stroke-style":"color-cold-gray-650","color-disabled-border-and-color":"color-cold-gray-800","color-disabled-input":"color-cold-gray-750","color-empty-container-message":"color-cold-gray-450","color-halal":"color-iguana-green-400","color-continuous":"color-cold-gray-500","color-highlight-new":"color-tv-blue-a800","color-icons":"color-cold-gray-450","color-input-bg":"color-cold-gray-800","color-input-textarea-readonly":"color-cold-gray-650","color-input-placeholder-text":"color-cold-gray-700","color-input-publish-bg":"color-cold-gray-900","color-item-active-blue":"color-tv-blue-a900","color-item-hover-active-bg":"color-cold-gray-800","color-item-hover-bg":"color-cold-gray-800","color-item-hover-blue":"color-tv-blue-a800","color-item-selected-blue":"color-tv-blue-a800","color-item-active-text":"color-cold-gray-200","color-item-active-bg":"color-tv-blue-500","color-link":"color-tv-blue-500","color-link-hover":"color-tv-blue-600","color-link-active":"color-tv-blue-700","color-list-item":"color-cold-gray-450","color-list-nth-child-bg":"color-cold-gray-850","color-news-highlight":"color-cold-gray-800","color-pane-bg":"color-cold-gray-900","color-pane-secondary-bg":"color-cold-gray-850","color-placeholder":"color-cold-gray-650","color-popup-menu-item-hover-bg":"color-cold-gray-800","color-popup-menu-separator":"color-cold-gray-700","color-primary-symbol":"color-sky-blue-500","color-row-hover-active-bg":"color-cold-gray-800","color-sb-scrollbar-body-bg":"color-cold-gray-650","color-screener-description":"color-cold-gray-200","color-section-separator-border":"color-cold-gray-750","color-search-button-hover":"color-cold-gray-700","color-separator-table-chat":"color-cold-gray-750","color-success":"color-minty-green-700","color-success-hover":"color-minty-green-600","color-success-active":"color-minty-green-500","color-tag-active-bg":"color-cold-gray-750","color-tag-hover-bg":"color-cold-gray-800","color-text-regular":"color-cold-gray-200","color-toolbar-button-text":"color-cold-gray-200","color-toolbar-button-text-hover":"color-cold-gray-200","color-toolbar-button-text-active":"color-tv-blue-500","color-toolbar-button-text-active-hover":"color-tv-blue-600","color-toolbar-button-background-hover":"color-cold-gray-800","color-toolbar-button-background-secondary-hover":"color-cold-gray-750","color-toolbar-button-background-active":"color-tv-blue-a900","color-toolbar-button-background-active-hover":"color-tv-blue-a800","color-toolbar-toggle-button-background-active":"color-tv-blue-500","color-toolbar-toggle-button-background-active-hover":"color-tv-blue-600","color-toolbar-toggle-button-icon":"color-cold-gray-650","color-toolbar-interactive-element-text-normal":"color-cold-gray-200","color-toolbar-opened-element-bg":"color-cold-gray-800","color-toolbar-divider-background":"color-cold-gray-700","color-popup-background":"color-cold-gray-850","color-popup-element-text":"color-cold-gray-200","color-popup-element-text-hover":"color-cold-gray-250","color-popup-element-background-hover":"color-cold-gray-800","color-popup-element-secondary-text":"color-cold-gray-500","color-popup-element-hint-text":"color-cold-gray-600","color-popup-element-text-active":"color-cold-gray-200","color-popup-element-background-active":"color-tv-blue-500","color-popup-element-toolbox-text":"color-cold-gray-500","color-popup-element-toolbox-text-hover":"color-cold-gray-200","color-popup-element-toolbox-text-active-hover":"color-tv-blue-200","color-popup-element-toolbox-background-hover":"color-cold-gray-750","color-popup-element-toolbox-background-active-hover":"color-tv-blue-700","color-tooltip-bg":"color-cold-gray-750","color-tv-button-checked":"color-cold-gray-450","color-tv-dialog-caption":"color-cold-gray-50","color-tv-dropdown-item-hover-bg":"color-cold-gray-800","color-underlined-text":"color-cold-gray-450","color-widget-pages-bg":"color-cold-gray-900","color-warning":"color-tan-orange-700","color-forex-icon":"color-white","color-list-item-active-bg":"color-tv-blue-500","color-list-item-hover-bg":"color-cold-gray-800","color-list-item-text":"color-cold-gray-200","color-price-axis-label-back":"color-cold-gray-800","color-price-axis-label-text":"color-cold-gray-500","color-price-axis-gear":"color-cold-gray-200","color-price-axis-gear-hover":"color-cold-gray-400","color-price-axis-highlight":"color-cold-gray-800","color-bid":"color-tv-blue-500","color-scroll-bg":"color-cold-gray-750","color-scroll-border":"color-cold-gray-850","color-widget-border":"color-cold-gray-800","color-scroll-buttons-arrow":"color-white","color-control-intent-default":"color-cold-gray-650","color-control-intent-success":"color-minty-green-500","color-control-intent-primary":"color-tv-blue-500","color-control-intent-warning":"color-tan-orange-500","color-control-intent-danger":"color-ripe-red-500","color-growing":"color-minty-green-500","color-falling":"color-ripe-red-500","color-goto-label-background":"color-cold-gray-650","color-pre-market":"color-tan-orange-600","color-pre-market-bg":"color-tan-orange-400","color-post-market":"color-tv-blue-500","color-post-market-bg":"color-tv-blue-400","color-market-open":"color-minty-green-500","color-market-open-bg":"color-minty-green-400","color-market-closed":"color-cold-gray-400","color-market-holiday":"color-cold-gray-400","color-market-expired":"color-ripe-red-500","color-invalid-symbol":"color-ripe-red-400","color-invalid-symbol-hover":"color-ripe-red-500","color-delisted-symbol":"color-ripe-red-600","color-delisted-symbol-hover":"color-ripe-red-800","color-replay-mode":"color-tv-blue-500","color-replay-mode-point-select":"color-cold-gray-250","color-replay-mode-icon":"color-tv-blue-50","color-replay-mode-hover":"color-tv-blue-600","color-notaccurate-mode":"color-berry-pink-600","color-delay-mode":"color-tan-orange-700","color-delay-mode-bg":"color-tan-orange-400","color-eod-mode":"color-grapes-purple-700","color-eod-mode-bg":"color-grapes-purple-400","color-data-problem":"color-ripe-red-600","color-data-problem-bg":"color-ripe-red-400","color-data-problem-hover":"color-ripe-red-500","color-list-item-bg-highlighted":"color-tv-blue-a900","color-list-item-bg-selected":"color-tv-blue-a800","color-list-item-bg-highlighted-hover":"color-tv-blue-a800","color-list-item-bg-selected-hover":"color-tv-blue-a700","color-screener-header-bg":"color-cold-gray-850","color-screener-header-bg-hover":"color-cold-gray-800","color-overlay":"color-cold-gray-950","color-boost-button-content-selected":"color-tv-blue-100","color-boost-button-content-hover":"color-white","color-boost-button-bg-hover":"color-cold-gray-750","color-boost-button-border-hover":"color-cold-gray-750","color-boost-button-border-default":"color-cold-gray-700","color-x-twitter-content":"color-white","color-card-border":"color-cold-gray-700","color-card-border-hover":"color-cold-gray-600","color-background-special-primary":"color-black","color-stroke-special-primary":"color-cold-gray-800","color-selection-bg":"color-tv-blue-a700","color-default-gray":"color-cold-gray-450","color-featured-broker-badge-bg":"color-white","color-featured-broker-badge-bg-hover":"color-cold-gray-100","color-featured-broker-badge-text":"color-cold-gray-900"}'
    );
  var p = i(58978);
  const m = {
    [d.StdTheme.Light]: {
      name: d.StdTheme.Light,
      label: () => u.t(null, {
        context: "colorThemeName"
      }, i(96870)),
      order: 2,
      getThemedColor: e => (0, p.getHexColorByName)(e)
    },
    [d.StdTheme.Dark]: {
      name: d.StdTheme.Dark,
      label: () => u.t(null, {
        context: "colorThemeName"
      }, i(85119)),
      order: 1,
      getThemedColor: e => {
        const t = _[e] || e;
        return (0, p.getHexColorByName)(t)
      }
    }
  };

  function g() {
    return m[c.watchedTheme.value()] || m[h]
  }

  function f(e) {
    return g()
      .getThemedColor(e)
  }

  function y() {
    (0, c.setTheme)(r() || h)
  }

  function v() {
    return r()
  }

  function S() {
    var e;
    e = g()
      .name, (0, n.setValue)("current_theme.name", e, {
        forceFlush: !0
      })
  }

  function b(e) {
    return a.loadTheme(e)
  }

  function w() {
    return a.loadThemes()
  }

  function C() {
    return l.getStdThemeNames()
  }

  function T(e) {
    return C()
      .includes(e)
  }

  function P(e) {
    return l.getStdChartTheme(e) || {
      content: void 0
    }
  }

  function x(e, t) {
    const i = t || g()
      .name,
      s = l.getStdChartTheme(i),
      o = 0 !== e.length && e.split(".");
    return s && s.content && o ? o.reduce(((e, t) => e[t]), s.content) : null
  }

  function M(e, t, i) {
    const o = x(e, i);
    return null !== o && (0, s.areEqualRgba)((0, s.parseRgba)(o), (0, s.parseRgba)(String(t)))
  }
  async function I(e, t) {
    try {
      return await a.saveTheme(e, t)
    } finally {
      E.fire()
    }
  }
  async function A(e) {
    try {
      return await a.removeTheme(e)
    } finally {
      E.fire()
    }
  }

  function L(e) {
    return a.isThemeExist(e)
  }

  function k(e) {
    return l.translateThemeName(e)
  }
  const E = new o.Delegate
