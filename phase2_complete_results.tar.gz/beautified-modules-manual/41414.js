// Module 41414
// Original file: 41414.js
// Size: 38.9 KB
// Purpose: Auto-extracted webpack module from TradingView library

(e, t, i) => {
  "use strict";
  i.d(t, {
    LineDataSource: () => U,
    changePointUndoText: () => z
  });
  var s = i(89880),
    o = i(10555),
    n = i(50151),
    r = i(87465),
    a = i(76422),
    l = i(9343),
    c = i(37103),
    h = i(32955),
    d = i(99955),
    u = i(48943),
    _ = i(48096),
    p = i(58043),
    m = i(22613),
    g = i(51304),
    f = i(12178),
    y = i(81922),
    v = i(37293),
    S = i(95059),
    b = i(36597),
    w = i(46082),
    C = i(43337),
    T = i(78861),
    P = i(72207),
    x = i(97719),
    M = i(40472),
    I = i(22455),
    A = i(95804),
    L = i(75550);
  class k extends C.Property {
    constructor(e, t) {
      super(), this._lineSource = e, this._pointIndex = t, e.pointAdded()
        .subscribe(this, (e => {
          this._pointIndex === e && this._listeners.fire(this, `${e}`)
        })), e.pointChanged()
        .subscribe(this, (e => {
          this._pointIndex === e && this._listeners.fire(this, `${e}`)
        }))
    }
    value() {
      const e = this._lineSource.points()[this._pointIndex].price,
        t = (0, n.ensureNotNull)(this._lineSource.ownerSource())
        .formatter();
      if (t.parse) {
        const i = t.format(e),
          s = t.parse(i);
        return s.res ? s.value : e
      }
      return e
    }
    setValue(e) {
      const t = this._lineSource.points()[this._pointIndex];
      t.price = parseFloat("" + e), this._lineSource.startChanging(this._pointIndex, t), this._lineSource.setPoint(
          this._pointIndex, t), this._lineSource.model()
        .updateSource(this._lineSource), this._listeners.fire(this, "");
      const i = this._lineSource.endChanging(!0, !1);
      this._lineSource.syncMultichartState(i)
    }
  }
  var E = i(79740),
    D = i(47432),
    B = i(65045),
    V = i(56876),
    R = i(60973),
    N = i(76559);
  const O = (0, l.getLogger)("Chart.LineDataSource"),
    F = c.enabled("datasource_copypaste");
  class W {
    constructor() {
      this._states = []
    }
    start(e) {
      this._states.push(e)
    }
    finish(e) {
      const t = (0, n.ensureDefined)(this._states.pop());
      return s = t, (i = e)
        .length !== s.length ? {
          indexesChanged: !0,
          pricesChanged: !0
        } : i.reduce(((e, t, i) => {
          const o = s[i];
          return e.indexesChanged = e.indexesChanged || t.index !== o.index, e.pricesChanged = e.pricesChanged ||
            t.price !== o.price, e
        }), {
          indexesChanged: !1,
          pricesChanged: !1
        });
      var i, s
    }
    isEmpty() {
      return 0 === this._states.length
    }
  }
  let H = 0;
  const z = new A.TranslatedString("change point", s.t(null, void 0, i(76660)));
  class U extends P.DataSource {
    constructor(e, t, i, s) {
      if (super(s), this.isLineTool = !0, this.version = 1, this.toolname = "", this.customization = {
          forcePriceAxisLabel: !1,
          disableErasing: !1,
          disableSave: !1,
          showInObjectsTree: !0
        }, this._currentPointsetAndSymbolId = null, this._pointChanged = new _.Delegate, this._pointAdded = new _
        .Delegate, this._priceAxisViews = [], this._timeAxisViews = [], this._timePoint = [], this._points = [],
        this._lastPoint = null, this._paneViews = new Map, this._signaturesPaneViews = new Map, this
        ._normalizedPointsChanged = new _.Delegate, this._fixedPointsChanged = new _.Delegate, this
        ._changeStatesStack = new W, this._startMovingPoint = null, this._currentMovingPoint = null, this
        ._isActualSymbol = !1, this._isActualInterval = !1, this._isActualCurrency = !1, this._isActualUnit = !1,
        this._symbolSource = null, this._symbolSourceSymbolInfo = null, this._sharingMode = new m.WatchedValue(0),
        this._onTemplateApplying = new _.Delegate, this._onTemplateApplied = new _.Delegate, this
        ._syncStateExclusions = ["interval"], this._definitionsViewModel = null, this._hasEditableCoordinates =
        new m.WatchedValue(!0), this._syncLineStyleMuted = !1, this._onIsActualIntervalChange = new _.Delegate, this
        ._onIsActualSymbolChange = new _.Delegate, this._onPointsetUpdatedDelegate = new _.Delegate,
        this._onServerUpdateTime = new _.Delegate, this._linkKey = new m.WatchedValue(null), this
        ._serverUpdateTime = null, this._boundCalcIsActualSymbol = this.calcIsActualSymbol.bind(this), this
        ._alignerCache = null, this._alertUndoMode = !1, this._targetSignature = new m.WatchedValue(null), this
        ._firstSignatureOwnerSource = null, this._sourcesSignatures = null, this._onAlertStatusChanged = () => {
          this.updateAllViewsAndRedraw((0, M.sourceChangeEvent)(this.id()))
        }, this._model = e, this._properties = t, this._localAndServerAlertsMismatch = !1, this._properties
        .hasChild("interval") || this._properties.addChild("interval", new C.Property(e.mainSeries()
          .interval())), this.calcIsActualSymbol(), this._properties.childs()
        .intervalsVisibilities.subscribe(this, this.calcIsActualSymbol), this._properties.subscribe(this, this
          .propertiesChanged.bind(this, !1, void 0)), this.zOrderChanged()
        .subscribe(this, this.propertiesChanged.bind(this, !0, void 0)), this._createPointsProperties(), this
        .pointsCount() > 0)
        for (let e = 0; e < this.pointsCount(); e++) this._priceAxisViews.push(this.createPriceAxisView(e)), this
          ._timeAxisViews.push(new E.LineDataSourceTimeAxisView(this, e));
      this._properties.childs()
        .visible.subscribe(this, (e => {
          const t = !1 === (0, T.hideAllDrawings)()
            .value();
          e.value() ? e.value() && t && a.emit("drawing_event", this._id.value(), "show") : (this._model
            .selection()
            .isSelected(this) && this._model.selectionMacro((e => {
              e.removeSourceFromSelection(this)
            })), t && a.emit("drawing_event", this._id.value(), "hide")), this._onSourceHiddenMayChange()
        })), (0, T.hideAllDrawings)()
        .subscribe(this, this._onSourceHiddenMayChange), this._sessionConnected = this._model.chartApi()
        .isConnected()
        .spawn(), this._sessionConnected.subscribe((e => {
          e || (this._currentPointsetAndSymbolId = null)
        })), this._alertStatus.subscribe(this._onAlertStatusChanged), this._definitionsViewModel = null, this
        ._properties.setNameInOwner((0, N.propertyPathForSource)(this)), this._sourcesSignatures = e
        .sourcesSignatures()
        .spawn(), this._sourcesSignatures.subscribe(this._updateSignaturesPaneViews.bind(this)), this
        ._targetSignature.subscribe(this._updateSignaturesPaneViews.bind(this))
    }
    destroy() {
      this._paneViews.forEach(((e, t) => this._destroyPanePaneViews(t))), this.stop(), null !== this
        ._definitionsViewModel && (this._definitionsViewModel.destroy(), this._definitionsViewModel = null),
        null !== this._ownerSource && (this._ownerSource.currencyChanged()
          .unsubscribeAll(this), this._ownerSource.unitChanged()
          .unsubscribeAll(this), (0, I.isSymbolSource)(this._ownerSource) && (this._ownerSource.symbolResolved()
            .unsubscribeAll(this), this._ownerSource.isActingAsSymbolSource()
            .unsubscribe(this._boundCalcIsActualSymbol))), this.ownerSourceChanged()
        .unsubscribeAll(this), this._symbolSource?.destroy(), this._symbolSourceSymbolInfo?.destroy(), (0, T
          .hideAllDrawings)()
        .unsubscribeAll(this), this._sessionConnected.destroy(), this._alertStatus.unsubscribe(this
          ._onAlertStatusChanged), this._properties.destroy(), this._sourcesSignatures?.destroy(), this
        ._firstSignatureOwnerSource?.destroy(), super.destroy()
    }
    setId(e) {
      super.setId(e), this._properties.setNameInOwner((0, N.propertyPathForSource)(this))
    }
    priceScale() {
      return this._ownerSource ? this._ownerSource.priceScale() : null
    }
    createPriceAxisView(e) {
      return new D.LineToolPriceAxisView(this, {
        pointIndex: e
      })
    }
    model() {
      return this._model
    }
    symbol() {
      return this._properties.childs()
        .symbol.value()
    }
    linkKey() {
      return this._linkKey
    }
    serverUpdateTime() {
      return this._serverUpdateTime
    }
    setServerUpdateTime(e) {
      this._serverUpdateTime = e, this._onServerUpdateTime.fire()
    }
    serverUpdateTimeChanged() {
      return this._onServerUpdateTime
    }
    adjustedToSplitTime() {
      return null
    }
    adjustToSplit(e, t) {}
    boundToSymbol() {
      return !0
    }
    isAvailableInFloatingWidget() {
      return !0
    }
    points() {
      const e = [];
      for (let t = 0; t < this._points.length; t++) {
        const i = this._points[t];
        e.push({
          index: i.index,
          price: i.price,
          time: i.time
        })
      }
      return this._lastPoint && e.push(this._correctLastPoint(this._lastPoint)), !this.isFixed() && this
        ._currentMovingPoint && this._startMovingPoint && this._correctPoints(e), e
    }
    timeAxisPoints() {
      return this.points()
    }
    priceAxisPoints() {
      return this.points()
    }
    fixedPoint(e) {
      if (!this.isFixed()) return;
      let t;
      const i = e ? e.priceScale() : this.priceScale();
      if (this._positionPercents && null !== i && !i.isEmpty()) {
        const e = this._positionPercents,
          s = this._model.timeScale()
          .width() * e.x,
          n = i.height() * e.y;
        t = new o.Point(s, n)
      } else void 0 !== this._fixedPoint && (t = this._fixedPoint?.clone());
      if (this._currentMovingPoint && this._startMovingPoint && void 0 !== t) {
        const e = this._correctFixedPoint(t);
        e.didCorrect && (t = e.point)
      }
      return t
    }
    positionPercents() {
      return this.isFixed() ? this._positionPercents : void 0
    }
    clearFixedPoint() {
      this._fixedPoint = void 0, this._positionPercents = void 0
    }
    normalizedPoints() {
      return this._timePoint
    }
    normalizedPointsForCreating() {
      return this.normalizedPoints()
    }
    normalizedPointsChanged() {
      return this._normalizedPointsChanged
    }
    fixedPointChanged() {
      return this._fixedPointsChanged
    }
    geometry() {
      const e = (0, n.ensureNotNull)(this.priceScale());
      return this.points()
        .map((t => {
          const i = (0, n.ensureNotNull)(this.pointToScreenPoint(t)),
            s = i.x / this._model.timeScale()
            .width(),
            r = i.y / e.height();
          return new o.Point(s, r)
        }))
    }
    widthsProperty() {
      return this._properties.childs()
        .linesWidths ?? null
    }
    lineColorsProperty() {
      return this._properties.childs()
        .linesColors ?? null
    }
    backgroundColorsProperty() {
      return this._properties.childs()
        .backgroundsColors ?? null
    }
    textColorsProperty() {
      return this._properties.childs()
        .textsColors ?? null
    }
    pointsProperty() {
      return this._pointsProperty
    }
    hasEditableCoordinates() {
      return this._hasEditableCoordinates
    }
    startMoving(e, t, i, s) {
      this.isFixed() && this.restoreFixedPoint(), this._startMovingPoint = e
    }
    move(e, t, i, s) {
      if (i && (i.shiftOnly() || i.modShift()))
        if (this.isFixed()) {
          const t = this._alignScreenPointHorizontallyOrVertically((0, n.ensureDefined)(e.screen));
          this._currentMovingPoint = {
            screen: t
          }
        } else {
          const t = this._alignPointHorizontallyOrVertically((0, n.ensureDefined)(e.logical)),
            i = (0, n.ensureNotNull)(this.pointToScreenPoint(t));
          this._currentMovingPoint = {
            logical: t,
            screen: i
          }
        }
      else this._currentMovingPoint = e;
      this.updateAllViews((0, M.sourceChangeEvent)(this.id()))
    }
    endMoving(e, t, i) {
      let s = !1,
        o = !1;
      if (this._currentMovingPoint && this._startMovingPoint) {
        if (this.isFixed()) {
          const e = this._correctFixedPoint((0,
            n.ensureDefined)(this._fixedPoint));
          e.didCorrect && (this._fixedPoint = e.point, this._fixedPointsChanged.fire())
        } else {
          const e = (0, n.ensureDefined)(this._currentMovingPoint.logical),
            t = (0, n.ensureDefined)(this._startMovingPoint.logical);
          s = e.index !== t.index, o = e.price !== t.price;
          if (this._correctPoints(this._points, i)) {
            const e = this._id.value();
            a.emit("drawing_event", e, "move"), a.emit("drawing_event", e, "points_changed"), this
              ._updateAdjustedToSplitTimeValue();
            for (let e = 0; e < this._points.length; e++) this._pointChanged.fire(e)
          }
        }
        this._startMovingPoint = null, this._currentMovingPoint = null
      }
      const r = {
        indexesChanged: s,
        pricesChanged: o
      };
      return this.isFixed() ? (this.calcPositionPercents(), this.updateAllViews((0, M.sourceChangeEvent)(this
      .id())), r) : (s && this._points.forEach((e => e.interval = this._model.mainSeries()
        .interval())), this.updateAllViews((0, M.sourceChangeEvent)(this.id())), s && !e ? (this._properties
        .childs()
        .interval.setValue(this._model.mainSeries()
          .interval()), this._normalizePoints(), this.createServerPoints()) : (this
        ._copyPricesWithoutNormalization(), this._normalizedPointsChanged.fire()), r)
    }
    startMovingPoint() {
      return this._startMovingPoint ? {
        ...this._startMovingPoint
      } : null
    }
    currentMovingPoint() {
      return this._currentMovingPoint ? {
        ...this._currentMovingPoint
      } : null
    }
    changePointUndoText(e) {
      return z
    }
    startChanging(e, t) {
      this.isFixed() && this.restoreFixedPoint(), void 0 !== e && void 0 !== t && (e < this._priceAxisViews
        .length && this._priceAxisViews[e].setActive(!0), e < this._timeAxisViews.length && this._timeAxisViews[e]
        .setActive(!0)), this._changeStatesStack.start(this.points())
    }
    endChanging(e, t, i) {
      const s = this._changeStatesStack.finish(this.points());
      s.indexesChanged && this._changeStatesStack.isEmpty() ? (this._normalizePoints(), t || this
          .createServerPoints()) : (this._copyPricesWithoutNormalization(), this._normalizedPointsChanged.fire()), a
        .emit("drawing_event", this._id.value(), "points_changed"), this._updateAdjustedToSplitTimeValue();
      for (let e = 0; e < this._priceAxisViews.length; e++) this._priceAxisViews[e].setActive(!1);
      for (let e = 0; e < this._timeAxisViews.length; e++) this._timeAxisViews[e].setActive(!1);
      return s
    }
    setPoint(e, t, i, s) {
      if (this._snapTo45DegreesApplicable(i)) {
        const i = 0 === e ? 1 : e - 1;
        this.snapPoint45Degree(t, this.points()[i])
      }
      this._setPoint(e, {
        ...t,
        interval: this._model.mainSeries()
          .interval()
      })
    }
    getPoint(e) {
      return this.points()[e] || null
    }
    alignCrossHairToAnchor(e) {
      return !0
    }
    alignCrossHairToMovePoint() {
      return !1
    }
    setLastPoint(e, t, i = !0) {
      return this._lastPoint = i ? this._preparePoint(e, t) : e, this.updateAllViews((0, M.sourceChangeEvent)(this
        .id())), this._lastPoint
    }
    lastPoint() {
      return this._lastPoint
    }
    getChangePointForSync(e) {
      return this.getPoint(e)
    }
    setPoints(e) {
      const t = this._model.mainSeries()
        .interval();
      this._points = e.map((e => ({
        ...e,
        interval: e.interval ?? t
      })))
    }
    isForcedDrawPriceAxisLabel() {
      return this.customization.forcePriceAxisLabel
    }
    clearData() {
      this._points = []
    }
    denormalizeTimePoints() {
      let e = [];
      const t = this._model.mainSeries()
        .interval();
      for (let i = 0; i < this._timePoint.length; i++) {
        const s = this._model.timeScale()
          .denormalizeTimePoint(this._timePoint[i]);
        if (void 0 === s) {
          e = [];
          break
        }
        e.push({
          index: s,
          price: this._timePoint[i].price,
          interval: this._timePoint[i].interval ?? t
        })
      }
      e.length > 0 && (this._points = e)
    }
    restorePoints(e, t, i) {
      const s = this._timePoint.length > 0 && !(0, r.deepEquals)(this._timePoint, e)[0],
        o = this._properties.childs()
        .interval.value();
      this._timePoint = e.map((e => ({
        ...e,
        interval: e.interval ?? o
      })));
      const n = this._model.mainSeries()
        .interval();
      this._points = t.map((e => ({
        ...e,
        interval: n
      }))), i || this.denormalizeTimePoints(), s && this._normalizedPointsChanged.fire()
    }
    restorePositionPercents(e) {
      this._positionPercents = e, this.restoreFixedPoint()
    }
    calcIsActualSymbol() {
      const e = this.ownerSource(),
        t = this._isActualSymbol;
      if (null === e) this._isActualSymbol = !1;
      else {
        const e = this._symbolSource?.value(),
          t = this._symbolSourceSymbolInfo?.value();
        if (t && e) {
          this._migrateSymbolProperty(t);
          const i = this._properties.childs()
            .symbol,
            s = i.value();
          if (this._isActualSymbol = e.symbolSameAsCurrent(s), this._isActualSymbol) {
            const o = (0, S.extractLineToolSymbolFromSymbolInfo)(t, e.symbol());
            (0, b.areEqualSymbols)(s, o) || (O.logWarn('Possible drawing "migrating" detected from "' + s +
              '" to "' + o + '"'), O.logWarn("Series symbolInfo: " + JSON.stringify(e.symbolInfo())), O.logWarn(
              `${(new Error).stack}`)), i.setValue(o)
          }
        }
      }
      this._isActualSymbol !== t && this._onIsActualSymbolChange.fire(), this.calcIsActualInterval(), this
        .calcIsActualCurrency(), this.calcIsActualUnit(), this._onSourceHiddenMayChange()
    }
    calcIsActualCurrency() {
      const e = this.ownerSource();
      if (null === e) return void(this._isActualCurrency = !1);
      let t = this._properties.childs()
        .currencyId.value();
      if (null !== t) {
        const i = e.symbolSource();
        0, this._isActualCurrency = t === (0, S.symbolCurrency)(i.symbolInfo(), void 0, !0)
      } else {
        const t = (0, n.ensureNotNull)(e.symbolSource());
        this._isActualCurrency = null !== t.symbolInfo() && !t.isConvertedToOtherCurrency()
      }
      this._onSourceHiddenMayChange()
    }
    calcIsActualUnit() {
      const e = this.ownerSource();
      if (null === e) return void(this._isActualUnit = !1);
      const t = this._properties.childs()
        .unitId.value();
      if (null !== t) this._isActualUnit = t === (0, n.ensureNotNull)(e.symbolSource())
        .unit();
      else {
        const t = (0, n.ensureNotNull)(e.symbolSource());
        this._isActualUnit = null !== t.symbolInfo() && !t.isConvertedToOtherUnit()
      }
      this._onSourceHiddenMayChange()
    }
    calcIsActualInterval() {
      const e = this._isActualInterval,
        t = this._properties,
        i = this._model.mainSeries();
      this._isActualInterval = (0, y.isActualInterval)(w.Interval.parse(i.interval()), t.childs()
          .intervalsVisibilities), !this._isActualInterval && this._model.selection()
        .isSelected(this) && this._model.selectionMacro((e => e.removeSourceFromSelection(this))), this
        ._isActualInterval !== e && this._onIsActualIntervalChange.fire(), this._onSourceHiddenMayChange()
    }
    paneViews(e) {
      if (this.isSourceHidden()) return null;
      const t = this._getPaneViews(this.isMultiPaneAvailable() ? e : void 0);
      if (null === t) return null;
      if (1 === t.length) return [t[0]];
      const i = [];
      for (let e = t.length - 1; e >= 0; --e) i.push(t[e]);
      return i
    }
    priceAxisViews(e, t) {
      if (this.isFixed()) return null;
      if (t !== this.priceScale() || this.isSourceHidden()) return null;
      if (this._model.lineBeingEdited() === this) {
        const e = this._model.linePointBeingEdited();
        if (null !== e && e < this._priceAxisViews.length) {
          const t = this._priceAxisViews.slice(),
            i = t[e];
          return t.splice(e, 1), t.push(i), t
        }
        return this._priceAxisViews
      }
      return this._priceAxisViews
    }
    timeAxisViews() {
      if (this.isSourceHidden() || this.isFixed()) return null;
      if (this._model.lineBeingEdited() === this) {
        const e = this._model.linePointBeingEdited();
        if (null !== e && e < this._timeAxisViews.length) {
          const t = this._timeAxisViews.slice(),
            i = t[e];
          return t.splice(e, 1), t.push(i), t
        }
        return this._timeAxisViews
      }
      return this._timeAxisViews
    }
    isSavedInChart() {
      return !this.customization.disableSave
    }
    isSavedInStudyTemplates() {
      return !1
    }
    setSavingInChartEnabled(e) {
      this.customization.disableSave = !e
    }
    shouldBeRemovedOnDeselect() {
      return !1
    }
    getOrderTemplate() {
      return null
    }
    getSourceIcon() {
      return {
        type: "loadSvg",
        svgId: "linetool." + this.toolname
      }
    }
    alertId() {
      return this._alertId
    }
    async waitSettingAlertId() {
      this._pendingAlertIdPromise && (this._alertId = await this._pendingAlertIdPromise)
    }
    async setAlert(e, t = {}) {
      throw new Error("not implemented")
    }
    async restoreAlert(e, t) {
      throw new Error("not implemented")
    }
    editAlert(e) {}
    async getAlert() {
      try {
        const e = await this._getChartAlert();
        if (!e) throw O.logError("Failed to get alert, alert will not be saved with drawing in chart"), new Error(
          "got_no_alert");
        return e
      } catch (e) {
        if (e instanceof Error && "not implemented" === e.message) throw e;
        if ("not_exists" === e) throw new Error(e);
        return O.logError(`Getting alert failed: ${e instanceof Error?e.message:e}`), null
      }
    }
    getAlertSync() {
      return null
    }
    async synchronizeAlert(e = !1) {}
    syncAlert(e) {
      0
    }
    stateForAlert() {
      return null
    }
    async stateForAlertAsync() {
      return null
    }
    getAlertIsActive() {
      return !1
    }
    detachAlert() {}
    removeAlert() {}
    deleteAlert() {}
    areLocalAndServerAlertsMismatch() {
      return !1
    }
    showInObjectTree() {
      return this.customization.showInObjectsTree
    }
    setShowInObjectsTreeEnabled(e) {
      this.customization.showInObjectsTree = e
    }
    start() {
      this.createServerPoints()
    }
    processHibernate() {
      this.canBeHibernated() ? this.isStarted() && this.stop() : this.isStarted() || this.start()
    }
    canBeHibernated() {
      return this.isSourceHidden()
    }
    onData(e) {
      "pointset_error" !== e.method ? e.params.customId === this._currentPointsetIdWithPrefix() && this
        ._onPointsetUpdated(e.params.plots) : O.logError(`Error getting pointset: ${e.params[0]} ${e.params[1]}`)
    }
    isBeingEdited() {
      return this === this._model.lineBeingEdited()
    }
    isActualSymbol() {
      return this._isActualSymbol
    }
    isActualCurrency() {
      return this._isActualCurrency
    }
    isActualInterval() {
      return this._isActualInterval
    }
    isActualUnit() {
      return this._isActualUnit
    }
    onIsActualIntervalChange() {
      return this._onIsActualIntervalChange
    }
    onIsActualSymbolChange() {
      return this._onIsActualSymbolChange
    }
    setOwnerSource(e) {
      if (null !== this._ownerSource && (this._ownerSource.currencyChanged()
          .unsubscribeAll(this), this._ownerSource.unitChanged()
          .unsubscribeAll(this), this._symbolSource?.destroy(), this._symbolSource = null, this
          ._symbolSourceSymbolInfo?.destroy(), this._symbolSourceSymbolInfo = null), super.setOwnerSource(e), e) {
        this._symbolSource = e.symbolSourceWV()
          .spawn();
        const t = (0, u.combine)((e => [e.symbolInfoWV()
          .weakReference()]), this._symbolSource.weakReference());
        this._symbolSourceSymbolInfo = (0,
            u.accumulate)((e => e[0] ?? null), t.ownership()), this._symbolSourceSymbolInfo.subscribe(this
            ._boundCalcIsActualSymbol), this.setPriceScale(e.priceScale()), e.currencyChanged()
          .subscribe(this, this.calcIsActualCurrency), e.unitChanged()
          .subscribe(this, this.calcIsActualUnit), this.calcIsActualSymbol(), this._migrateZOrder(), this
          ._updateAlertCreationAvailable()
      }(0, I.isSymbolSource)(e) && (e.symbolResolved()
        .subscribe(this, this._boundCalcIsActualSymbol), e.isActingAsSymbolSource()
        .subscribe(this._boundCalcIsActualSymbol))
    }
    dataAndViewsReady() {
      return this._paneViews.size > 0
    }
    pointAdded() {
      return this._pointAdded
    }
    pointChanged() {
      return this._pointChanged
    }
    pointsetUpdated() {
      return this._onPointsetUpdatedDelegate
    }
    pointToScreenPoint(e, t) {
      const i = this._model.timeScale(),
        s = t ? t.priceScale() : this.priceScale(),
        n = (t ?? this.ownerSource())
        ?.firstValue();
      if (!s || s.isEmpty() || i.isEmpty() || null == n) return null;
      const r = i.indexToCoordinate(e.index),
        a = s.priceToCoordinate(e.price, n);
      return new o.Point(r, a)
    }
    screenPointToPoint(e, t, i) {
      const s = i ? i.priceScale() : this.priceScale(),
        o = (i ?? this.ownerSource())
        ?.firstValue();
      if (null == o || !isFinite(o) || null === s) return null;
      const n = this._model.timeScale(),
        r = t ? n.coordinateToFloatIndex(e.x) : n.coordinateToIndex(e.x);
      return {
        price: s.coordinateToPrice(e.y, o),
        index: r
      }
    }
    calcMiddlePoint(e, t) {
      return new o.Point((e.x + t.x) / 2, (e.y + t.y) / 2)
    }
    addPoint(e, t, i) {
      const s = this._preparePoint(e, t);
      return this._addPointIntenal(s, t, i)
    }
    addFixedPoint(e) {
      return this._fixedPoint = e, this.calcPositionPercents(), !0
    }
    calcPositionPercents() {
      const e = this.priceScale();
      if (!e || e.isEmpty() || void 0 === this._fixedPoint) return;
      const t = this._fixedPoint.x / this._model.timeScale()
        .width(),
        i = this._fixedPoint.y / e.height();
      return this._positionPercents = {
        x: t,
        y: i
      }, this._positionPercents
    }
    restoreFixedPoint() {
      this._fixedPoint = this.fixedPoint()
    }
    propertiesChanged(e, t) {
      this.calcIsActualInterval(), this.updateAllViewsAndRedraw((0, M.sourceChangeEvent)(this.id())), t || this
        ._syncLineStyleIfNeeded(e), e || void 0 !== this._pendingPropertyChangedEvent || (this
          ._pendingPropertyChangedEvent = setTimeout((() => {
            this._pendingPropertyChangedEvent = void 0, a.emit("drawing_event", this._id.value(),
              "properties_changed")
          }), 0))
    }
    state(e) {
      const t = this.toolname,
        i = this.ownerSource(),
        s = {
          type: t,
          id: this.id(),
          state: this.properties()
            .state(this._propertiesStateExclusions()),
          points: (0, p.deepCopy)(this._timePoint),
          zorder: this.zorder(),
          ownerSource: i?.id()
        };
      this._targetSignature.value();
      return s.isSelectionEnabled = this.isSelectionEnabled(), s.userEditEnabled = this.userEditEnabled(), this
        .linkKey()
        .value() && (s.linkKey = this.linkKey()
          .value()), delete s.state.points, e && (s.indexes = this._points), this.isFixed() && (s.positionPercents =
          this._positionPercents || this.calcPositionPercents()), "version" in this && 1 !== this.version && (s
          .version = this.version), s
    }
    updateAllViews(e) {
      this.isSourceHidden() || "data-source-change" === e.type && this._ignoreSourceEvent(e) || (this
        ._updateAllPaneViews(e), this._priceAxisViews.forEach((t => t.update(e))), this._timeAxisViews.forEach((
          t => t.update(e))))
    }
    updateAllViewsAndRedraw(e) {
      this.updateAllViews(e),
        this._model.updateSource(this)
    }
    tags() {
      return [this.toolname]
    }
    properties() {
      return this._properties
    }
    restoreExternalPoints(e, t) {
      try {
        if (this._timePoint = (0, p.deepCopy)(e.points), t.indexesChanged) {
          if (this.properties()
            .childs()
            .interval.setValue(e.interval), !this.isActualSymbol()) return void this._clearServerPoints();
          this.createServerPoints()
        } else {
          const t = Math.min(this._points.length, e.points.length);
          for (let i = 0; i < t; i++) this._points[i].price = e.points[i].price
        }
        this.updateAllViewsAndRedraw((0, M.sourceChangeEvent)(this.id()))
      } finally {
        this._normalizedPointsChanged.fire()
      }
    }
    restoreExternalState(e) {
      this.properties()
        .mergeAndFire(e)
    }
    applyTemplate(e) {
      this._onTemplateApplying.fire(e), this._applyTemplateImpl(e), this.calcIsActualSymbol(), this.updateAllViews((
          0, M.sourceChangeEvent)(this.id())), this.model()
        .lightUpdate(), this._onTemplateApplied.fire()
    }
    template() {
      return this.properties()
        .preferences()
    }
    isFixed() {
      return !1
    }
    anchorable() {
      return !1
    }
    isLocked() {
      const e = this.properties()
        .child("frozen");
      return void 0 !== e && e.value()
    }
    isSourceHidden() {
      return !this._properties.childs()
        .visible.value() || (0, T.hideAllDrawings)()
        .value() && this.canBeHidden() || !this._isActualInterval || !this._isActualSymbol || !this
        ._isActualCurrency || !this._isActualUnit
    }
    isSynchronizable() {
      return this.priceScale() === this._model.mainSeries()
        .priceScale()
    }
    copiable() {
      return F
    }
    cloneable() {
      return null !== this._ownerSource && null !== this._ownerSource.firstValue()
    }
    movable() {
      return !0
    }
    allowsMovingBetweenPanes() {
      return !1
    }
    async getPropertyDefinitionsViewModel() {
      if (null === this._definitionsViewModel) {
        const e = await this._getPropertyDefinitionsViewModelClass();
        return null === e || this._isDestroyed ? null : (this._definitionsViewModel = new e(this._model.undoModel(),
          this), this._definitionsViewModel)
      }
      return this._definitionsViewModel
    }
    title() {
      return this.translatedType()
    }
    translatedType() {
      return V.lineToolsLocalizedNames[this.toolname] ?? "Line Tool"
    }
    name() {
      return "Line Tool"
    }
    createServerPoints() {
      if (!this._isActualSymbol) return;
      if (!this._model.chartApi()
        .isConnected()
        .value()) return;
      if (this._clearServerPoints(), this._model.timeScale()
        .isEmpty()) return;
      if (0 === this._timePoint.length && this._points.length > 0 && this._normalizePoints(), !this
        ._readyToCreatePointset()) return;
      const e = this._pointsForPointset();
      if (0 === e.length) return;
      ++H, this._currentPointsetAndSymbolId = {
        pointsetId: H,
        symbolId: (0, n.ensureNotNull)(this._model.mainSeries()
          .seriesSource()
          .symbolInstanceId())
      };
      const t = (0, f.getServerInterval)(this.properties()
        .childs()
        .interval.value());
      this._model.chartApi()
        .createPointset(this._currentPointsetIdWithPrefix(), "turnaround", this._currentPointsetAndSymbolId
          .symbolId, t, e, this.onData.bind(this))
    }
    finish() {}
    realign() {
      this.calcIsActualSymbol(), this.isFixed() || this.isSourceHidden() || this._model.lineBeingCreated() ===
        this || this._model.lineBeingEdited() === this || this._currentPointsetAndSymbolId?.symbolId === this._model
        .mainSeries()
        .seriesSource()
        .symbolInstanceId() || this._clearServerPoints(), null === this._model.mainSeries()
        .symbolInfo() && (this._alignerCache = null), this.updateAllViews((0, M.sourceChangeEvent)(this.id()))
    }
    stop() {
      this._clearServerPoints()
    }
    restart() {
      this.isFixed() || (this._currentPointsetAndSymbolId = null, this.createServerPoints())
    }
    isStarted() {
      return null !== this._currentPointsetAndSymbolId
    }
    convertYCoordinateToPriceForMoving(e, t) {
      const i = (0, n.ensureNotNull)(this.priceScale());
      if (i.isEmpty()) return null;
      const s = this.ownerSource(),
        o = (0, n.ensure)((s || t)
          ?.firstValue());
      return i.coordinateToPrice(e, o)
    }
    syncMultichartState(e) {
      const t = {
          points: this._timePoint,
          pointPositionPercents: this.positionPercents(),
          interval: this._model.mainSeries()
            .interval()
        },
        i = this.linkKey()
        .value();
      if (null !== i && this.isSynchronizable()) {
        const s = {
          model: this._model,
          linkKey: i,
          symbol: this._model.mainSeries()
            .symbol(),
          finalState: t,
          changes: e
        };
        (0, T.finishChangingLineTool)(s)
      }
    }
    enableCurrentIntervalVisibility() {
      let e = this.properties()
        .childs()
        .intervalsVisibilities.state();
      void 0 !== e && (e = (0, y.mergeIntervalVisibilitiesDefaults)(e), (0, y
          .makeIntervalsVisibilitiesVisibleAtInterval)(e, this._model.mainSeries()
          .intervalObj()
          .value()), this.properties()
        .childs()
        .intervalsVisibilities.mergeAndFire(e))
    }
    clonePositionOffset() {
      return this.isFixed() ? {
        barOffset: 0,
        xCoordOffset: 20,
        yCoordOffset: 20
      } : {
        barOffset: 0,
        xCoordOffset: 0,
        yCoordOffset: -40
      }
    }
    sharingMode() {
      return this._sharingMode
    }
    share(e) {
      this.isSynchronizable() && this._sharingMode.setValue(e)
    }
    syncLineStyleState(e) {
      if (e) return {
        zOrder: this.zorder()
      };
      const {
        intervalsVisibilities: t,
        ...i
      } = this.properties()
        .state(this._syncStateExclusions);
      return {
        ...i,
        intervalsVisibilities: (0, y.mergeIntervalVisibilitiesDefaults)(t),
        zOrder: this.zorder()
      }
    }
    moveLineTool(e) {
      const t = this._model.mainSeries()
        .interval();
      e.forEach(((e, i) => this._setPoint(i, {
        ...e,
        interval: t
      }))), this._normalizePoints()
    }
    targetSignature() {
      return this._targetSignature.readonly()
    }
    setTargetSignature(e) {
      (0, n.assert)(this.supportsTargetSignature()), this._targetSignature.setValue(e)
    }
    supportsTargetSignature() {
      return !1
    }
    snapTo45DegreesAvailable() {
      return !1
    }
    alignTo45DegreesPoints() {
      if (this.snapTo45DegreesAvailable()) {
        const [e, t] = this.points();
        if (e && t) return [{
          ...e,
          pointIndex: 0
        }, {
          ...t,
          pointIndex: 1
        }]
      }
      return null
    }
    snapPoint45Degree(e, t, i) {
      const s = this._model.timeScale(),
        o = s.indexToCoordinate(t.index),
        r = s.indexToCoordinate(e.index) - o,
        a = (0, n.ensureNotNull)(this.priceScale()),
        l = t.price,
        c = e.price,
        h = (0, n.ensureNotNull)((0, n.ensureNotNull)(this.ownerSource())
          .firstValue()),
        d = a.priceToCoordinate(l, h),
        u = a.priceToCoordinate(c, h) - d,
        _ = Math.round(Math.atan2(r, u) / Math.PI * 4);
      if (2 === Math.abs(_)) i || (e.price = l);
      else if (0 === Math.abs(_) || 4 === Math.abs(_)) i || (e.index = t.index);
      else {
        const t = Math.sqrt(r * r + u * u),
          i = r < 0 ? -1 : 1,
          n = u < 0 ? -1 : 1;
        let l = Math.max(Math.abs(u), Math.abs(r));
        l /= l * Math.sqrt(2) / t;
        const c = Math.round(s.coordinateToIndex(o + l * i)),
          _ = Math.abs(s.indexToCoordinate(c) - o),
          p = a.coordinateToPrice(d + _ * n, h);
        e.index = c, e.price = p
      }
    }
    contextMenuStatName() {
      return "LineToolContextMenu"
    }
    _ignoreSourceEvent(e) {
      return e.sourceId !== this.id()
    }
    _pointsForPointset() {
      return this._timePoint.map((({
        interval: e,
        time_t: t,
        offset: i
      }) => e ? [t, i, (0, f.getServerInterval)(e)] : [t, i]))
    }
    _setPoint(e, t) {
      this._points[e] && (this._points[e].index === t.index ? this._points[e].price = t.price : this._points[e] = t,
        this._pointChanged.fire(e))
    }
    _correctLastPoint(e) {
      return (0, r.clone)(e)
    }
    _snapTo45DegreesApplicable(e) {
      return this.snapTo45DegreesAvailable() && (e?.shift() || (0, T.alignTo45Degrees)()
        .value())
    }
    _normalizePoint(e, t) {
      return {
        ...this._model.timeScale()
        .normalizeBarIndex(e.index),
        price: e.price,
        interval: e.interval
      }
    }
    _normalizePointWithoutOffset(e) {
      const t = this._model.timeScale()
        .indexToTimePoint(e.index) ?? this._utcTimeInCurrentResolution(e);
      return null === t ? null : {
        price: e.price,
        time_t: t,
        offset: 0,
        interval: e.interval
      }
    }
    _normalizePoints() {
      let e = [];
      const t = this._model.mainSeries()
        .interval();
      for (let i = 0; i < this._points.length; i++)
        if (w.Interval.isEqual(this._points[i].interval, t)) {
          if (void 0 !== this._points[i].index) {
            const t = this._normalizePoint(this._points[i], i);
            if (!t.time_t) {
              e = [];
              break
            }
            e.push(t)
          }
        } else e.push({
          ...this._timePoint[i],
          price: this._points[i].price
        });
      this._timePoint = e, this._normalizedPointsChanged.fire()
    }
    _getStartBarAligner() {
      const e = this._model.mainSeries()
        .interval();
      if (null === this._alignerCache || this._alignerCache.resolution !== this._model.mainSeries()
        .interval()) {
        const t = this._model.mainSeries()
          .symbolInfo();
        if (!t) return null;
        this._alignerCache = {
          resolution: e,
          aligner: (0, h.createTimeToBarTimeAligner)(e, t)
        }
      }
      return this._alignerCache.aligner
    }
    _utcTimeInCurrentResolution(e) {
      const t = this._model.timeScale()
        .points(),
        i = t.firstPoint(),
        s = t.lastPoint(),
        o = this._model.mainSeries()
        .syncModel();
      if (null === i || null === s || null === o) return null;
      const r = (0, n.ensureNotNull)(t.indexOf(i, !1)),
        a = (0, n.ensureNotNull)(t.indexOf(s, !1));
      if (e.index >= r && e.index <= a) return null;
      const l = e.index < r ? r : a,
        c = (0, n.ensureNotNull)(t.valueAt(l)),
        h = e.index - l;
      return (0, d.extrapolateBarsFrontByCount)(o.barBuilder(), 1e3 * c, h)
        .time / 1e3
    }
    _setPaneViews(e, t, i) {
      if (this._isDestroyed)
        for (const t of e) t.destroy && t.destroy();
      else this._paneViews.set(t, e), void 0 !== t && i && t.onDestroyed()
        .subscribe(this, (() => this._destroyPanePaneViews(t))), this._model.lightUpdate()
    }
    _getPaneViews(e) {
      return this._paneViews.get(e) ?? []
    }
    _updateAllPaneViews(e) {
      this._paneViews.forEach((t => {
        for (const i of t) i.update(e)
      }));
      for (const [, t] of this._signaturesPaneViews)
        for (const i of t) i.update(e)
    }
    _alignPointHorizontallyOrVertically(e) {
      const t = (0, n.ensureNotNull)(this.pointToScreenPoint(e)),
        i = (0, n.ensureDefined)((0, n.ensureNotNull)(this._startMovingPoint)
          .logical),
        s = (0, n.ensureDefined)((0, n.ensureNotNull)(this._startMovingPoint)
          .screen),
        o = Math.abs(s.x - t.x),
        r = Math.abs(s.y - t.y);
      if (o < 10 && r < 10) return e;
      return {
        index: o < r ? i.index : e.index,
        price: o < r ? e.price : i.price
      }
    }
    _alignScreenPointHorizontallyOrVertically(e) {
      const t = (0, n.ensureDefined)((0, n.ensureNotNull)(this._startMovingPoint)
          .screen),
        i = Math.abs(t.x - e.x),
        s = Math.abs(t.y - e.y);
      return i < 10 && s < 10 ? e : i < s ? new o.Point(t.x, e.y) : new o.Point(e.x, t.y)
    }
    _correctPoints(e, t) {
      const i = (0, n.ensure)(this._currentMovingPoint?.screen),
        s = (0, n.ensure)(this._startMovingPoint?.screen),
        o = i.subtract(s);
      if (o.length() < 1 && !t) return !1;
      const r = Math.round((0, n.ensure)(this._currentMovingPoint?.logical)
        .index - (0,
          n.ensure)(this._startMovingPoint?.logical)
        .index);
      for (const t of e) {
        const e = (0, n.ensureNotNull)(this.pointToScreenPoint(t))
          .add(o);
        t.index = t.index + r, t.price = (0, n.ensureNotNull)(this.screenPointToPoint(e))
          .price
      }
      return !0
    }
    _correctFixedPoint(e) {
      if (void 0 === this._fixedPoint) return {
        didCorrect: !1,
        point: e
      };
      const t = (0, n.ensureDefined)((0, n.ensureNotNull)(this._currentMovingPoint)
          .screen),
        i = (0, n.ensureDefined)((0, n.ensureNotNull)(this._startMovingPoint)
          .screen),
        s = t.subtract(i);
      return s.length() >= 1 ? {
        didCorrect: !0,
        point: e.add(s)
      } : {
        didCorrect: !1,
        point: e
      }
    }
    _currentPointsetIdWithPrefix() {
      return "pointset_" + (0, n.ensureNotNull)(this._currentPointsetAndSymbolId)
        .pointsetId
    }
    _clearServerPoints() {
      null !== this._currentPointsetAndSymbolId && this._model.chartApi()
        .isConnected()
        .value() && this._model.chartApi()
        .removePointset(this._currentPointsetIdWithPrefix()), this._currentPointsetAndSymbolId = null
    }
    _createPointProperty(e) {
      const t = this._pointsProperty.childs()
        .points;
      t.addChild("" + e, new C.Property({}));
      const i = t[e];
      i.addChild("price", new k(this, e)), i.addChild("bar", new L.LineDataSourcePointIndexProperty(this, e))
    }
    _createPointsProperties() {
      this._pointsProperty = new C.Property, this._pointsProperty.addChild("points", new C.Property);
      for (let e = 0; e < this.pointsCount(); e++) this._createPointProperty(e)
    }
    _alignPointToRangeOfActualData(e) {
      const t = (0, n.ensureNotNull)(this._model.mainSeries()
          .bars()
          .firstIndex()),
        i = (0, n.ensureNotNull)(this._model.mainSeries()
          .bars()
          .lastIndex());
      let s = Math.max(e.index, t);
      return s = Math.min(s, i), {
        ...e,
        index: s
      }
    }
    _migrateSymbolProperty(e) {
      const t = this._properties.childs();
      if (t.symbolStateVersion.value() < 2) {
        const i = (0, n.ensureNotNull)(this.ownerSource()),
          s = (0, n.ensureNotNull)(i.symbolSource()),
          o = this._model.mainSeries();
        if (s === o) return void t.symbolStateVersion.setValueSilently(2);
        if (null === o.symbolInfo()) return;
        if (null === s.symbolInfo()) return;
        o.symbolSameAsCurrent(t.symbol.value()) && t.symbol.setValueSilently((0, S
          .extractLineToolSymbolFromSymbolInfo)(e, s.symbol())), t.symbolStateVersion.setValueSilently(2)
      }
    }
    _migrateZOrder() {
      const e = this._properties.childs();
      e.zOrderVersion.value() < 2 && (this.ownerSource() === this.model()
        .mainSeries() && this.setZorder(this.zorder() - this.model()
          .mainSeries()
          .obsoleteZOrder()), e.zOrderVersion.setValueSilently(2))
    }
    _preparePoint(e, t) {
      const i = e;
      return this._snapTo45DegreesApplicable(t) && this.points()
        .length >= 2 && this.snapPoint45Degree(i, this.points()[this.points()
          .length - 2]), i
    }
    _addPointIntenal(e, t, i) {
      this._points.push({
        ...e,
        interval: this._model.mainSeries()
          .interval()
      });
      const s = this._points.length === this.pointsCount();
      return s ? (this._lastPoint = null, i || (this._normalizePoints(), this.createServerPoints())) : this
        ._lastPoint = e, this._pointAdded.fire(this._points.length - 1), s
    }
    _onSourceHiddenMayChange() {
      this.isSourceHidden() && this._model.selectionMacro((e => {
        e.removeSourceFromSelection(this)
      })), this._model.invalidate(g.InvalidationMask.validateAction((() => {
        this !== this._model.lineBeingCreated() && (this._isDestroyed || this.processHibernate())
      })))
    }
    _saveAlertIdInState() {
      return !0
    }
    _onPointsetUpdated(e) {
      if (0 === e.length) return;
      const t = this.properties()
        .childs()
        .interval.value();
      for (const {
          index: i,
          value: s
        }
        of e) {
        const {
          price: e,
          interval: o = t
        } = (0, n.ensureDefined)(this._timePoint[i]), [r, a] = s, l = {
          index: r,
          time: a,
          price: e,
          interval: o
        };
        if (this._points.length <= i) {
          const e = this._points.push(l);
          this._pointAdded.fire(e - 1)
        } else this._points[i] = l, this._pointChanged.fire(i)
      }
      this._onPointsetUpdatedDelegate.fire(), this.updateAllViewsAndRedraw((0, M.sourceChangeEvent)(this.id()))
    }
    _onMainSeriesSymbolResolved() {
      const e = this.ownerSource();
      null === e || this._model.mainSeries() === e.symbolSource() || this.isSourceHidden() || this
        .createServerPoints()
    }
    _readyToCreatePointset() {
      return this._timePoint.length > 0
    }
    _propertiesStateExclusions() {
      return []
    }
    _syncLineStyleIfNeeded(e) {
      const t = this.linkKey()
        .value();
      t && !this._syncLineStyleMuted && this._syncLineStyleChanges(t, this.syncLineStyleState(e))
    }
    _muteSyncLineStyle() {
      this._syncLineStyleMuted = !0
    }
    _unmuteSyncLineStyleWithoutApplyingChanges() {
      this.propertiesChanged(), this._syncLineStyleMuted = !1
    }
    _applyTemplateImpl(e) {
      e.intervalsVisibilities = (0, y.mergeIntervalVisibilitiesDefaults)(e.intervalsVisibilities);
      const t = this.properties();
      t.applyTemplate(e, (0, R.factoryDefaults)(this.toolname.toLowerCase())), t.saveDefaults(), this
        .propertiesChanged()
    }
    _getPropertyDefinitionsViewModelClass() {
      return Promise.resolve(null)
    }
    _getAlertPlots() {
      return []
    }
    _getUndoHistory() {
      return this._model.undoModel()
        .undoHistory()
    }
    async _synchronizeAlert(e) {}
    _linePointsToAlertPlot(e, t, i, s) {
      return null
    }
    _getAlertCreationAvailable() {
      return !1
    }
    _onAnchoredChange() {
      if (this.isFixed()) {
        const e = (0, n.ensureNotNull)(this.pointToScreenPoint(this.points()[0]));
        this.addFixedPoint(e)
      } else {
        if (!this._fixedPoint) return;
        const e = (0, n.ensureNotNull)(this.screenPointToPoint(this._fixedPoint));
        this._points[0] = {
            ...e,
            interval: this._model.mainSeries()
              .interval()
          }, this.startChanging(), this.setPoint(0, e), this.endChanging(!1, !1), this._timePoint[0] = this
          ._normalizePoint(this._points[0], 0), this.clearFixedPoint()
      }
      const e = this.linkKey()
        .value();
      null !== e && this.isSynchronizable() && (0, T.restoreLineToolState)({
        model: this._model,
        linkKey: e,
        state: this.state()
      })
    }
    _syncLineStyleChanges(e, t, i) {
      this.anchorable() && this.isFixed() !== Boolean(this._positionPercents) && this._onAnchoredChange(), (0, T
        .changeLineStyle)({
        linkKey: e,
        state: t,
        alertId: i,
        model: this._model
      })
    }
    _updateAdjustedToSplitTimeValue(e) {}
    _createSignatureSourcePaneViews(e) {
      return []
    }
    _updateSignaturesPaneViews() {
      const e = this.targetSignature()
        .value();
      if (null !== e || 0 !== this._signaturesPaneViews.size) {
        for (const [t, i] of this._signaturesPaneViews) t.signature()
          .value() !== e && (i.forEach((e => e.destroy?.())), this._signaturesPaneViews.delete(t));
        for (const t of this._model.studiesWV(!0)
            .value()) t.signature()
          .value() !== e || this._signaturesPaneViews.has(t) || this._signaturesPaneViews.set(t, this
            ._createSignatureSourcePaneViews(t))
      }
    }
    static _configureProperties(e) {
      if (this._addCollectedProperties(e), e.hasChild("symbolStateVersion") || e.addProperty("symbolStateVersion",
          1), e.hasChild("zOrderVersion") || e.addProperty("zOrderVersion", 1), e.hasChild("visible") || e
        .addProperty("visible", !0),
        e.hasChild("frozen") || e.addProperty("frozen", !1), e.hasChild("symbol") || e.addProperty("symbol", ""), e
        .hasChild("currencyId") || e.addProperty("currencyId", null), e.hasChild("unitId") || e.addProperty(
          "unitId", null), e.hasChild("adjustedToSplitTime") || e.addProperty("adjustedToSplitTime", null), e
        .hasChild("intervalsVisibilities")) {
        const t = (0, r.merge)((0, r.clone)(v.intervalsVisibilitiesDefaults), e.childs()
          .intervalsVisibilities.state());
        e.removeProperty("intervalsVisibilities"), e.addChild("intervalsVisibilities", new x
          .IntervalsVisibilitiesProperty(t))
      } else e.addChild("intervalsVisibilities", new x.IntervalsVisibilitiesProperty(v
        .intervalsVisibilitiesDefaults));
      e.hasChild("title") || e.addProperty("title", ""), ["symbolStateVersion", "zOrderVersion", "visible",
        "frozen", "symbol", "currencyId", "unitId", "symbolInfo", "points", "interval", "title"].forEach((t => e
        .addExcludedKey(t, 5))), e.hasChild("singleChartOnly") && e.removeProperty("singleChartOnly"), e.hasChild(
        "font") && e.removeProperty("font")
    }
    static _addCollectedProperties(e) {
      e.hasChild("linewidth") && e.addChild("linesWidths", new B.LineToolWidthsProperty([(0, n.ensureDefined)(e
          .child("linewidth"))])), e.hasChild("linecolor") && e.addChild("linesColors", new B
          .LineToolColorsProperty([(0, n.ensureDefined)(e.child("linecolor"))])), e.hasChild("backgroundColor") && e
        .addChild("backgroundsColors", new B.LineToolColorsProperty([(0, n.ensureDefined)(e.child(
          "backgroundColor"))])), e.hasChild("textColor") && e.addChild("textsColors", new B.LineToolColorsProperty(
          [(0, n.ensureDefined)(e.child("textColor"))])), e.hasChild("linestyle") && e.addChild("linesStyles", new B
          .LineToolCollectedProperty([(0, n.ensureDefined)(e.child("linestyle"))])), ["linesWidths", "linesColors",
          "backgroundsColors", "textsColors", "linesStyles"].forEach((t => {
          e.addExcludedKey(t, 7)
        }))
    }
    _areAlertsOnLineToolProhibited() {
      return null !== this._ownerSource && !this._ownerSource.canHasAlertOnLineTools()
    }
    _removeAlertSubscriptions() {
      this._unsubscribeAlertCallbacks?.(), this._unsubscribeAlertCallbacks = void 0
    }
    _addAlertSubscriptions(e, t = {}) {}
    _destroyPanePaneViews(e) {
      const t = this._paneViews.get(e);
      if (void 0 !== t)
        for (const e of t) e.destroy && e.destroy();
      void 0 !== e && e.onDestroyed()
        .unsubscribeAll(this), this._paneViews.delete(e)
    }
    _copyPricesWithoutNormalization() {
      const e = Math.min(this._points.length, this._timePoint.length);
      for (let t = 0; t < e; t++) this._timePoint[t].price = this._points[t].price
    }
    async _getChartAlert() {
      throw new Error("not implemented")
    }
    async _syncAlertWithAlertFacade(e = {}) {
      try {
        const t = await this.getAlert();
        if (!t) return;
        this._addAlertSubscriptions(t, e)
      } catch (e) {
        if (e instanceof Error && "not_exists" === e.message && this.hasAlert()
          .value()) {
          this._alertStatus.setValue(0);
          return void(await getChartAlertsFacade())
            .removeAlertFromAllChartsSilently(this.id(), (0, n.ensureDefined)(this._alertId))
        }
        O.logError("Failed to set alert, alert will not be saved with drawing in chart")
      }
    }
    async _awaitForPointset() {
      const e = {};
      try {
        await Promise.race([new Promise(((e, t) => {
          setTimeout((() => t(new Error("Timeout"))), 3e3)
        })), new Promise((t => {
          this.pointsetUpdated()
            .subscribe(e, (() => t()))
        }))])
      } catch (e) {
        throw e
      } finally {
        this.pointsetUpdated()
          .unsubscribeAll(e)
      }
    }
  }
