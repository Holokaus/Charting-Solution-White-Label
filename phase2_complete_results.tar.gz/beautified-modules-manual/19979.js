// Module 19979
// Original file: 19979.js
// Size: 14.0 KB
// Purpose: Auto-extracted webpack module from TradingView library

(e, t, i) => {
  "use strict";
  i.d(t, {
    Std: () => h
  });
  var s = i(37236),
    o = i(51101);
  class n {
    constructor(e, t, i) {
      this._timezone = e, this._preMarketSessionSpec = t, this._postMarketSessionSpec = i
    }
    getPreAndPostMarketTimes(e) {
      if (0 === e.length) return {
        preMarket: [],
        postMarket: []
      };
      const t = [],
        i = [];
      let o = null,
        n = null,
        r = e[0],
        a = (0, s.utc_to_cal)(this._timezone, r);
      this._isInPreMarketSession(a) && (n = r), this._isInPostMarketSession(a) && (o = r);
      for (let l = 1; l < e.length; l++) {
        const c = e[l],
          h = (0, s.utc_to_cal)(this._timezone, c);
        null !== o && this._isInPostMarketSession(a) && !this._isInPostMarketSession(h) && (i.push({
            start: o,
            stop: r
          }), o = null), null === n && this._isInPreMarketSession(h) && (n = c), null === o && this
          ._isInPostMarketSession(h) && (o = c), null !== n && this._isInPreMarketSession(a) && !this
          ._isInPreMarketSession(h) && (t.push({
            start: n,
            stop: r
          }), n = null), r = c, a = h
      }
      return null !== n && t.push({
        start: n,
        stop: e[e.length - 1]
      }), null !== o && i.push({
        start: o,
        stop: e[e.length - 1]
      }), {
        preMarket: t,
        postMarket: i
      }
    }
    _isInPreMarketSession(e) {
      if (null === this._preMarketSessionSpec) return !1;
      const t = this._preMarketSessionSpec.getWeekIndex(e);
      return this._anyEntryContains(this._preMarketSessionSpec.getEntriesForWeek(t)
        .list(), e)
    }
    _isInPostMarketSession(e) {
      if (null === this._postMarketSessionSpec) return !1;
      const t = this._postMarketSessionSpec.getWeekIndex(e);
      return this._anyEntryContains(this._postMarketSessionSpec.getEntriesForWeek(t)
        .list(), e)
    }
    _anyEntryContains(e, t) {
      if (void 0 === e) return !1;
      for (let i = 0; i < e.length; i++)
        if (e[i].contains(t)) return !0;
      return !1
    }
  }
  var r = i(51829),
    a = i(4659);
  const l = 1e-10,
    c = e => e ? 1 : 0,
    h = {};

  function d(e, t, i, s, o) {
    let n = o,
      r = 0;
    if (isNaN(e.get(t - 1))) return {
      index: NaN,
      value: NaN
    };
    for (let i = 0; i < t; ++i) s(e.get(i), n) && (r = i, n = e.get(i));
    return {
      index: r,
      value: n
    }
  }
  h.max_series_default_size = 10001, h.n = e => e.symbol.index + 1, h.nz = (e, t = 0) => isFinite(e) ? e : t, h.na =
    function(e) {
      return 0 === arguments.length ? NaN : isNaN(e) ? 1 : 0
    }, h.isZero = e => Math.abs(e) <= 1e-10 ? 1 : 0, h.toBool = e => isFinite(e) && !h.isZero(e), h.eq = (e, t) => h
    .isZero(e - t), h.neq = (e, t) => c(!h.eq(e, t)), h.ge = (e, t) => c(h.isZero(e - t) || e > t), h.gt = (e, t) => c(!
      h.isZero(e - t) && e > t), h.lt = (e, t) => c(!h.isZero(e - t) && e < t), h.le = (e, t) => c(h.isZero(e - t) ||
      e < t), h.and = (e, t) => isNaN(e) || isNaN(t) ? NaN : h.isZero(e) || h.isZero(t) ? 0 : 1, h.or = (e, t) => isNaN(
      e) || isNaN(t) ? NaN : h.isZero(e) && h.isZero(t) ? 0 : 1, h.not = e => isNaN(e) ? NaN : h.isZero(e) ? 1 : 0, h
    .eps = () => l, h.greaterOrEqual = (e, t, i) => t - e < (i || l), h.lessOrEqual = (e, t, i) => e - t < (i || l), h
    .equal = (e, t, i) => Math.abs(e - t) < (i || l), h.greater = (e, t, i) => e - t > (i || l), h.less = (e, t, i) =>
    t - e > (i || l), h.compare = (e, t, i) => h.equal(e, t, i) ? 0 : h.greater(e, t, i) ? 1 : -1, h.max = Math.max, h
    .min = Math.min, h.pow = Math.pow, h.abs = Math.abs, h.log = Math.log, h.log10 = e => Math.log(e) / Math.LN10, h
    .sqrt = Math.sqrt, h.sign = e => isNaN(e) ? NaN : h.isZero(e) ? 0 : e > 0 ? 1 : -1, h.exp = Math.exp, h.sin = Math
    .sin, h.cos = Math.cos, h.tan = Math.tan, h.asin = Math.asin, h.acos = Math.acos, h.atan = Math.atan, h.floor = Math
    .floor, h.ceil = Math.ceil, h.round = Math.round, h.avg = (...e) => {
      if (2 === e.length) return (e[0] + e[1]) / 2;
      let t = 0;
      for (let i = 0; i < e.length; i++) t += e[i];
      return t / e.length
    }, h.open = e => e.symbol.open, h.high = e => e.symbol.high, h.low = e => e.symbol.low, h.close = e => e.symbol
    .close, h.hl2 = e => (e.symbol.high + e.symbol.low) / 2, h.hlc3 = e => (e.symbol.high + e.symbol.low + e.symbol
      .close) / 3, h.ohlc4 = e => (e.symbol.open + e.symbol.high + e.symbol.low + e.symbol.close) / 4, h.volume = e => e
    .symbol.volume, h.updatetime = e => e.symbol.updatetime, h.time = e => e.symbol.bartime(), h.period = e => e.symbol
    .period, h.tickerid = e => e.symbol.tickerid, h.currencyCode = e => e.symbol.currencyCode, h.unitId = e => e.symbol
    .unitId, h.ticker = e => e.symbol.ticker, h.interval = e => e.symbol.interval, h.isdwm = e => e.symbol.isdwm(), h
    .isintraday = e => !e.symbol.isdwm(),
    h.isdaily = e => "D" === e.symbol.resolution, h.isweekly = e => "W" === e.symbol.resolution, h.ismonthly = e =>
    "M" === e.symbol.resolution, h.year = (e, t) => h.timepart(e.symbol, s.YEAR, t), h.month = (e, t) => h.timepart(e
      .symbol, s.MONTH, t), h.weekofyear = (e, t) => h.timepart(e.symbol, s.WEEK_OF_YEAR, t), h.dayofmonth = (e, t) => h
    .timepart(e.symbol, s.DAY_OF_MONTH, t), h.dayofweek = (e, t) => h.timepart(e.symbol, s.DAY_OF_WEEK, t), h.hour = (e,
      t) => h.timepart(e.symbol, s.HOUR_OF_DAY, t), h.minute = (e, t) => h.timepart(e.symbol, s.MINUTE, t), h.second = (
      e, t) => h.timepart(e.symbol, s.SECOND, t), h.add_days_considering_dst = (e, t, i) => (0, s
      .add_days_considering_dst)((0, s.get_timezone)(e), t, i), h.add_years_considering_dst = (e, t, i) => (0, s
      .add_years_considering_dst)((0, s.get_timezone)(e), t, i), h.selectSessionBreaks = (e, t) => {
      if (h.isdwm(e) || void 0 === e.symbol.session.timezone) return [];
      const i = (0, o.newBarBuilder)(e.symbol.period, e.symbol.session, null),
        s = [],
        n = t.length;
      if (i.moveTo(t[n - 1]), 1 === n && i.startOfBar(0) === t[0]) s.push(t[0]);
      else {
        for (let e = n - 2; e >= 0; --e) {
          const o = t[e];
          if (o >= i.startOfBar(0)) continue;
          i.moveTo(o);
          const n = t[e + 1];
          s.push(n)
        }
        s.reverse()
      }
      return s
    }, h.selectPreAndPostMarketTimes = (e, t) => {
      if (h.isdwm(e) || void 0 === e.symbol.session.timezone) return {
        preMarket: [],
        postMarket: []
      };
      return new n(e.symbol.session.timezone, e.symbol.preMarketSubsession ?? null, e.symbol.postMarketSubsession ??
          null)
        .getPreAndPostMarketTimes(t)
    }, h.iff = (e, t, i) => h.not(e) ? i : t, h.rising = (e, t) => {
      for (let i = 1; i < t + 1; ++i)
        if (e.get(i) > e.get(0)) return 0;
      return 1
    }, h.falling = (e, t) => {
      for (let i = 1; i < t + 1; ++i)
        if (e.get(i) < e.get(0)) return 0;
      return 1
    }, h.timepart = (e, t, i) => {
      const o = (0, s.utc_to_cal)(e.session.timezone, i || e.bartime());
      return (0, s.get_part)(o, t)
    }, h.rsi = (e, t) => h.isZero(t) ? 100 : h.isZero(e) ? 0 : 100 - 100 / (1 + e / t), h.sum = (e, t, i) => {
      const s = i.new_var(),
        o = h.nz(e.get()) + h.nz(s.get(1)) - h.nz(e.get(t));
      return s.set(o), o
    }, h.sma = (e, t, i) => {
      const s = h.sum(e, t, i);
      return h.na(e.get(t - 1)) ? NaN : s / t
    }, h.smma = (e, t, i) => {
      const s = i.new_var(e),
        o = h.sma(s, t, i),
        n = i.new_var(),
        r = (n.get(1) * (t - 1) + e) / t;
      return n.set(h.na(n.get(1)) ? o : r), n.get(0)
    }, h.rma = (e, t, i) => {
      const s = h.sum(e, t, i),
        o = t - 1,
        n = e.get(o),
        r = i.new_var(),
        a = r.get(1),
        l = e.get(),
        c = h.na(n) ? NaN : h.na(a) ? s / t : (l + a * o) / t;
      return r.set(c), c
    }, h.fixnan = (e, t) => {
      const i = t.new_var();
      return isNaN(e) ? i.get(1) : (i.set(e), e)
    }, h.tr = (e, t) => {
      let i = t.new_var(h.close(t))
        .get(1);
      return e && isNaN(i) && (i = h.close(t)), h.max(h.max(h.high(t) - h.low(t), h.abs(h.high(t) - i)), h.abs(h.low(
        t) - i))
    }, h.atr = (e, t) => {
      const i = t.new_var(h.tr(void 0, t));
      return h.rma(i, e, t)
    }, h.ema = (e, t, i) => {
      const s = h.sum(e, t, i),
        o = i.new_var(),
        n = e.get(0),
        r = e.get(t - 1),
        a = o.get(1),
        l = h.na(r) ? NaN : h.na(a) ? s / t : 2 * (n - a) / (t + 1) + a;
      return o.set(l), l
    }, h.wma = (e, t, i) => {
      let s = 0;
      for (let i = t = Math.round(t); i >= 0; i--) {
        s += (t - i) * e.get(i)
      }
      return 2 * s / (t * (t + 1))
    }, h.vwma = (e, t, i) => {
      const s = i.new_var(h.volume(i)),
        o = i.new_var(e.get(0) * h.volume(i));
      return h.sma(o, t, i) / h.sma(s, t, i)
    }, h.swma = (e, t) => (e.get(0) + 2 * e.get(1) + 2 * e.get(2) + e.get(3)) / 6, h.supertrend = (e, t, i) => {
      const s = h.atr(t, i),
        o = i.new_var(s)
        .get(1),
        n = h.hl2(i);
      let r = n + s * e,
        a = n - s * e;
      const l = h.close(i),
        c = i.new_var(l)
        .get(1),
        d = i.new_var(),
        u = h.nz(d.get(1)),
        _ = i.new_var(),
        p = h.nz(_.get(1));
      a = h.gt(a, u) || h.lt(c, u) ? a : u, d.set(a), r = h.lt(r, p) || h.gt(c, p) ? r : p, _.set(r);
      let m = h.na();
      const g = i.new_var(),
        f = g.get(1);
      m = h.na(o) ? 1 : f === p ? l > r ? -1 : 1 : l < a ? 1 : -1;
      const y = -1 === m ? a : r;
      return g.set(y), h.n(i) <= t ? [Number.NaN, 0] : [y, m]
    }, h.lowestbars = (e, t, i) => -d(e, t, 0, ((e, t) => h.lt(e, t)), Number.MAX_SAFE_INTEGER)
    .index, h.lowest = (e, t, i) => d(e, t, 0, ((e, t) => h.lt(e, t)), Number.MAX_SAFE_INTEGER)
    .value, h.highestbars = (e, t, i) => -d(e, t, 0, ((e, t) => h.gt(e, t)), Number.MIN_SAFE_INTEGER)
    .index, h.highest = (e, t, i) => d(e, t, 0, ((e, t) => h.gt(e, t)), Number.MIN_SAFE_INTEGER)
    .value, h.cum = (e, t) => {
      const i = t.new_var(),
        s = h.nz(i.get(1)) + e;
      return i.set(s), s
    }, h.accdist = e => {
      const t = h.high(e),
        i = h.low(e),
        s = h.close(e),
        o = h.volume(e);
      return h.cum(s === t && s === i || t === i ? 0 : o * (2 * s - i - t) / (t - i), e)
    }, h.correlation = (e, t, i, s) => {
      const o = h.sma(e, i, s),
        n = h.sma(t, i, s),
        r = s.new_var(e.get() * t.get());
      return (h.sma(r, i, s) - o * n) / Math.sqrt(h.variance2(e, o, i) * h.variance2(t, n, i))
    }, h.stoch = (e, t, i, s, o) => {
      const n = h.highest(t, s, o),
        r = h.lowest(i, s, o);
      return h.fixnan(100 * (e.get() - r) / (n - r), o)
    }, h.tsi = (e, t, i, s) => {
      const o = s.new_var(h.change(e)),
        n = s.new_var(h.abs(h.change(e))),
        r = s.new_var(h.ema(o, i, s)),
        a = s.new_var(h.ema(n, i, s));
      return h.ema(r, t, s) / h.ema(a, t, s)
    }, h.cross = (e, t, i) => {
      if (isNaN(e) || isNaN(t)) return !1;
      const s = i.new_var((o = e - t) < 0 ? -1 : 0 === o ? 0 : 1);
      var o;
      return !isNaN(s.get(1)) && s.get(1) !== s.get()
    }, h.linreg = (e, t, i) => {
      let s = 0,
        o = 0,
        n = 0,
        r = 0;
      for (let i = 0; i < t; ++i) {
        const a = e.get(i),
          l = t - 1 - i + 1;
        s += l, o += a, n += l * l, r += a * l
      }
      const a = (t * r - s * o) / (t * n - s * s);
      return o / t - a * s / t + a + a * (t - 1 - i)
    }, h.sar = (e, t, i, s) => {
      const o = s.new_var(),
        n = s.new_var(),
        r = s.new_var(),
        a = h.high(s),
        l = h.low(s),
        c = h.close(s),
        d = s.new_var(a),
        u = s.new_var(l),
        _ = s.new_var(c),
        p = s.new_var();
      let m = p.get(1),
        g = n.get(1),
        f = r.get(1);
      n.set(g), r.set(f);
      let y = !1;
      const v = u.get(1),
        S = u.get(2),
        b = d.get(1),
        w = d.get(2),
        C = _.get(),
        T = _.get(1);
      2 === h.n(s) && (h.greater(C, T) ? (o.set(1), r.set(d.get()), m = v, f = d.get()) : (o.set(-1), r.set(u.get()),
        m = b, f = u.get()), y = !0, n.set(e), g = e);
      let P = m + g * (f - m);
      return 1 === o.get() ? h.greater(P, u.get()) && (y = !0, o.set(-1), P = Math.max(d.get(), r.get()), r.set(u
        .get()), n.set(e)) : h.less(P, d.get()) && (y = !0, o.set(1), P = Math.min(u.get(), r.get()), r.set(d.get()), n
          .set(e)), y || (1 === o.get() ? h.greater(d.get(), r.get()) && (r.set(d.get()), n.set(Math.min(n.get() + t,
          i))) : h.less(u.get(), r.get()) && (r.set(u.get()), n.set(Math.min(n.get() + t, i)))), 1 === o.get() ? (P =
          Math.min(P, v), h.n(s) > 2 && (P = Math.min(P, S))) : (P = Math.max(P, b), h.n(s) > 2 && (P = Math.max(P,
        w))), p.set(P), P
    }, h.alma = (e, t, i, s) => {
      const o = Math.floor(i * (t - 1)),
        n = t / s * (t / s),
        r = [];
      let a = 0;
      for (let e = 0; e < t; ++e) {
        const t = Math.exp(-1 * Math.pow(e - o, 2) / (2 * n));
        a += t, r.push(t)
      }
      for (let e = 0; e < t; ++e) r[e] /= a;
      let l = 0;
      for (let i = 0; i < t; ++i) l += r[i] * e.get(t - i - 1);
      return l
    }, h.change = e => e.get() - e.get(1), h.roc = (e, t) => {
      const i = e.get(t);
      return 100 * (e.get() - i) / i
    }, h.dev = (e, t, i) => {
      const s = h.sma(e, t, i);
      return h.dev2(e, t, s)
    }, h.dev2 = (e, t, i) => {
      let s = 0;
      for (let o = 0; o < t; o++) {
        const t = e.get(o);
        s += h.abs(t - i)
      }
      return s / t
    }, h.stdev = (e, t, i) => {
      const s = h.variance(e, t, i);
      return h.sqrt(s)
    }, h.variance = (e, t, i) => {
      const s = h.sma(e, t, i);
      return h.variance2(e, s, t)
    }, h.variance2 = (e, t, i) => {
      let s = 0;
      for (let o = 0; o < i; o++) {
        const i = e.get(o),
          n = h.abs(i - t);
        s += n * n
      }
      return s / i
    }, h.percentrank = (e, t) => {
      if (h.na(e.get(t - 1))) return NaN;
      let i = 0;
      const s = e.get();
      for (let o = 1; o < t; o++) {
        const t = e.get(o);
        h.ge(s, t) && i++
      }
      return 100 * i / t
    }, h.createNewSessionCheck = e => {
      if (void 0 === e.symbol.session.timezone) return () => !1;
      const t = (0, o.newBarBuilder)(e.symbol.period, e.symbol.session, null);
      return e => t.indexOfBar(e) === r.SessionStage.POST_SESSION && (t.moveTo(e), !0)
    }, h.createNthBarInSessionCheck = e => {
      if (void 0 === e.symbol.session.timezone) return () => !1;
      const t = (0, o.newBarBuilder)(e.symbol.period, e.symbol.session, null);
      return (e, i) => (t.indexOfBar(e) === r.SessionStage.POST_SESSION && t.moveTo(e), t.indexOfBar(e) === i)
    }, h.error = (e, t) => {
      throw new a.StudyError(e, t)
    }, h.dmi = (e, t, i) => {
      const s = i.new_var(h.high(i)),
        o = i.new_var(h.low(i)),
        n = h.change(s),
        r = -h.change(o),
        a = i.new_var(h.na(n) || h.na(r) ? h.na() : h.and(h.gt(n, r), h.gt(n, 0)) ? n : 0),
        l = i.new_var(h.na(r) ? h.na() : h.and(h.gt(r, n), h.gt(r, 0)) ? r : 0),
        c = h.atr(e, i),
        d = h.fixnan(100 * h.rma(a, e, i) / c, i),
        u = h.fixnan(100 * h.rma(l, e, i) / c, i);
      let _ = d + u;
      h.isZero(_) && (_ += 1);
      const p = Math.abs(d - u) / _ * 100,
        m = i.new_var(p),
        g = h.rma(m, t, i),
        f = i.new_var(g);
      return [d, u, p, g, (f.get(0) + f.get(e - 1)) / 2]
    }, h.zigzag = (e, t, i) => new m(e, t, i)
    .lastPrice(), h.zigzagbars = (e, t, i) => {
      const s = new m(e, t, i);
      return -1 === s.lastIndex() ? NaN : s.lastIndex() - h.n(i)
    };
  const u = 0,
    _ = 1;
  class p {
    constructor(e, t, i, s, o) {
      this._areaRight = e, this._areaLeft = t, this._pivotType = i, this._series = s, this._currentIndex = o.new_var(
          0), this._currentValue = o.new_var(NaN), this._pivotIndex = o.new_var(-1), this._index = h.n(o), this
        ._isNewBar = o.symbol.isNewBar;
      const n = this._currentIndex.get(1),
        r = this._currentValue.get(1),
        a = this._pivotIndex.get(1);
      this._index > 1 && (this._currentIndex.set(n), this._currentValue.set(r), this._pivotIndex.set(a))
    }
    isPivotFound() {
      return -1 !== this._pivotIndex.get()
    }
    pivotIndex() {
      return this._pivotIndex.get()
    }
    currentValue() {
      return this._currentValue.get()
    }
    pivotType() {
      return this._pivotType
    }
    reset() {
      this._currentValue.set(NaN), this._currentIndex.set(0), this._pivotIndex.set(-1)
    }
    isRightSideOk(e) {
      return e - this._currentIndex.get() === this._areaRight
    }
    isViolate(e, t) {
      if (e < 1 || isNaN(this._currentValue.get())) return !0;
      const i = this._series.get(this._index - e);
      return !!isNaN(i) || (i === this._currentValue.get() ? t : this._pivotType === _ ? i > this._currentValue
      .get() : i < this._currentValue.get())
    }
    processPoint(e) {
      this.isViolate(e, !1) && (this._currentValue.set(this._series.get()), this._currentIndex.set(e))
    }
    isRestartNeeded(e) {
      return e - this._currentIndex.get() > this._areaRight
    }
    update() {
      if (this._isNewBar && this.isPivotFound() && this.reset(), this.processPoint(this._index), this.isRightSideOk(
          this._index)) {
        if (-1 === this._pivotIndex.get()) {
          let e = !0;
          for (let t = 0; t < this._areaLeft; ++t)
            if (this.isViolate(this._currentIndex.get() - 1 - t, !0)) {
              e = !1;
              break
            } e && this._pivotIndex.set(this._currentIndex.get())
        }
      } else - 1 !== this._pivotIndex.get() && this._pivotIndex.set(-1);
      if (this.isRestartNeeded(this._index)) {
        this.reset();
        for (let e = 0; e <= this._areaRight; ++e) this.processPoint(this._index - this._areaRight + e)
      }
    }
  }
  p.LOW = 0, p.HIGH = 1;
  class m {
    constructor(e, t, i) {
      this._deviation = e;
      const s = i.new_var(h.high(i)),
        o = i.new_var(h.low(i));
      s.get(2 * t + 1), o.get(2 * t + 1), this._pivotHigh = new p(t, t, _, s, i), this._pivotLow = new p(t, t, u, o,
          i), this._lastVal = i.new_var(NaN), this._lastIndex = i.new_var(-1), this._lastType = i.new_var(), this
        ._index = h.n(i), this._isBarClosed = i.symbol.isBarClosed;
      const n = this._lastIndex.get(1),
        r = this._lastVal.get(1),
        a = this._lastType.get(1);
      this._index > 1 && this.addPivot(n, r, a), this.processPivot(this._pivotHigh), this.processPivot(this._pivotLow)
    }
    addPivot(e, t, i) {
      this._lastIndex.set(e), this._lastVal.set(t), this._lastType.set(i)
    }
    updatePivot(e, t) {
      this._lastIndex.set(e), this._lastVal.set(t)
    }
    lastPrice() {
      return this._lastVal.get()
    }
    lastIndex() {
      return this._lastIndex.get()
    }
    addPoint(e, t, i) {
      if (isNaN(this._lastVal.get())) return void this.addPivot(e, t, i);
      const s = this._lastVal.get();
      if (this._lastType.get() === i) {
        return void((i === _ ? t > s : t < s) && this.updatePivot(e, t))
      }
      Math.abs(s - t) / t > this._deviation && this.addPivot(e, t, i)
    }
    processPivot(e) {
      e.update(), this._isBarClosed && e.isPivotFound() && this.addPoint(e.pivotIndex(), e.currentValue(), e
        .pivotType())
    }
  }
  h.vwap = (e, t, i) => {
    const s = i.new_var(),
      o = i.new_var();
    return t && (s.reset_hist(), o.reset_hist()), s.set(h.nz(s.get(1)) + e.get(0) * h.volume(i)), o.set(h.nz(o.get(
      1)) + h.volume(i)), s.get(0) / o.get(0)
  }, h.vwapBands = (e, t, i, s) => {
    const o = s.new_var(),
      n = s.new_var();
    t && (o.reset_hist(), n.reset_hist());
    const r = e.get(0);
    let a = h.volume(s),
      l = r * a;
    l += h.nz(o.get(1)), a += h.nz(n.get(1)), o.set(l), n.set(a);
    const c = l / a,
      d = s.new_var();
    t && d.reset_hist();
    let u = h.volume(s) * h.pow(r, 2);
    u += h.nz(d.get(1)), d.set(u);
    const _ = h.max(u / a - h.pow(c, 2), 0),
      p = Math.sqrt(_);
    return [c, c + p * i, c - p * i]
  }
