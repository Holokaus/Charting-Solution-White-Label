// Module 16329
// Original file: 16329.js
// Size: 21.4 KB
// Purpose: Auto-extracted webpack module from TradingView library

(e, t, i) => {
  "use strict";
  i.d(t, {
    SessionsSpec: () => T
  });
  var s, o = i(50151),
    n = i(37236),
    r = i(16879),
    a = i(71149);

  function l(e, t) {
    return e.compareTo(t)
  }! function(e) {
    e[e.LeftFirst = -1] = "LeftFirst", e[e.Unchanged = 0] = "Unchanged", e[e.RightFirst = 1] = "RightFirst"
  }(s || (s = {}));
  class c {
    constructor(e, t, i) {
      (0, o.assert)(Number.isFinite(e) && Number.isFinite(t) && Number.isFinite(i), "Invalid arguments"), this
        ._dayOfWeek = e, this._start = t, this._length = i
    }
    start() {
      return this._start + n.minutesPerDay * this.sessionStartDaysOffset()
    }
    startOffset() {
      return this._start
    }
    sessionStartDaysOffset() {
      return this._start >= 0 ? 0 : this._start % n.minutesPerDay == 0 ? -Math.ceil(this._start / n.minutesPerDay) : -
        Math.floor(this._start / n.minutesPerDay)
    }
    isOvernight() {
      return this._start < 0
    }
    dayOfWeek() {
      return this._dayOfWeek
    }
    sessionStartDayOfWeek() {
      let e = this._dayOfWeek - this.sessionStartDaysOffset();
      return e < n.SUNDAY && (e += 7), e
    }
    length() {
      return this._length
    }
    compareTo(e) {
      const t = this._weight(),
        i = t + this._length,
        s = e._weight(),
        o = s + e._length;
      return t <= s && s < i || s <= t && t < o ? 0 : t > s ? 1 : -1
    }
    contains(e) {
      return this._contains((0, n.get_minutes_with_hours)(e), (0, n.get_day_of_week)(e))
    }
    _weight() {
      return this._dayOfWeek * n.minutesPerDay + this._start
    }
    _contains(e, t) {
      let i = t - this._dayOfWeek;
      i > 0 && (i -= 7);
      const s = i * n.minutesPerDay + e;
      return s >= this._start && s < this._start + this._length
    }
  }
  class h {
    constructor(e, t, i) {
      this.weekIndex = e, this.entryIndex = t, this.entries = i
    }
    getEntry() {
      return this.entries[this.entryIndex]
    }
  }
  class d {
    constructor(e, t, i, s) {
      this._maxTradingDayLength = null, this._list = e, this._entriesByDay = t, this._firstDayOfWeek = i, this
        ._weekEndsCount = s
    }
    firstDayOfWeek() {
      return this._firstDayOfWeek
    }
    entriesByDay() {
      return this._entriesByDay
    }
    list() {
      return this._list
    }
    isWeekEnd(e) {
      return !this._entriesByDay.has(e)
    }
    weekEndsCount() {
      return this._weekEndsCount
    }
    longestSessionLength() {
      return 0 === this._list.length ? 0 : Math.max(...this._list.map((e => e.length())))
    }
    maxTradingDayLength() {
      if (null == this._maxTradingDayLength) {
        const e = new Map;
        for (const t of this._list) {
          const i = t.dayOfWeek();
          e.set(i, t.length() + (e.get(i) ?? 0))
        }
        let t = 0;
        e.forEach((e => {
          t = Math.max(t, e)
        })), this._maxTradingDayLength = t
      }
      return this._maxTradingDayLength
    }
  }
  class u {
    constructor(e, t, i) {
      this._startDay = e, this._entries = i, this._specEndDay = t
    }
    getEntries() {
      return this._entries
    }
    getStartDay() {
      return this._startDay
    }
    getSpecEndDay() {
      return this._specEndDay
    }
    isOpenEnded() {
      return null == this._specEndDay
    }
  }
  const _ = [n.MONDAY, n.TUESDAY, n.WEDNESDAY, n.THURSDAY, n.FRIDAY],
    p = [n.SUNDAY, n.MONDAY, n.TUESDAY, n.WEDNESDAY, n.THURSDAY, n.FRIDAY, n.SATURDAY];

  function m(e) {
    return e >= 48 && e <= 57
  }
  const g = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  class f extends Map {
    constructor() {
      super(...arguments), this._keyStringsToKey = new Map
    }
    get(e) {
      const t = this._keyStringsToKey.get(e.toString());
      return t && super.get(t)
    }
    set(e, t) {
      const i = e.toString(),
        s = this._keyStringsToKey.get(i);
      return void 0 !== s && super.delete(s), this._keyStringsToKey.set(i, e), super.set(e, t)
    }
    has(e) {
      return this._keyStringsToKey.has(e.toString())
    }
  }

  function y(e) {
    return e.length > 0
  }
  class v {
    constructor() {
      this.historyEntries = [], this.timezone = "", this.adjustSessionsIndexes = null
    }
    parseSessions(e, t) {
      this._parseHistoryEntries(e, t, !1)
    }
    parseSessionsAndValidateDateTime(e, t) {
      this._parseHistoryEntries(e, t, !0)
    }
    static parseHolidaysAndCorrections(e, t, i, s) {
      return this._parseHolidaysAndCorrectionsImpl(e, t, i, s)
    }
    static parseHolidaysAndCorrectionsAndValidateDateTime(e, t, i) {
      return this._parseHolidaysAndCorrectionsImpl(e, t, i, !0)
    }
    _clearAll() {
      this.timezone = "", this.historyEntries = [], this.adjustSessionsIndexes = []
    }
    _parseHistoryEntries(e, t, i) {
      this._clearAll();
      const s = t.split("/");
      let o = null,
        n = null;
      this.hasHistoryCorrections = s.length > 1;
      for (let t = 0; t < s.length; t++) {
        const r = s[t].split("#");
        let a = null;
        if (t !== s.length - 1) {
          if (2 !== r.length) throw new Error(`bad session history entry definition: ${s[t]}`);
          a = v._parseDay(r[1], "session history entry end", i)
            .toCalendar()
        } else {
          if (1 !== r.length) throw new Error(`bad session history entry definition: ${s[t]}`);
          a = null
        }
        if (null !== n && null !== a && a.getTime() < n.getTime()) throw new Error(
          `history sessions are not listed in ascending order (${n} -> ${a}`);
        const l = this._parseSessionsImpl(e, r[0], i);
        o = this._adjustStartToPreviousSession(l.firstDayOfWeek());
        const c = new u(o, a, l);
        this.historyEntries.push(c), n = a
      }
    }
    _parseSessionsImpl(e, t, i) {
      this.timezone = e, t = this._parseFirstDayOfWeek(t);
      const s = new Map,
        o = [];
      if ("24x7" === t.toLowerCase())
        for (const e of p) {
          const t = v._createSessionEntry(e, 0, 0, 0, 0);
          o.push(t);
          const i = [];
          i.push(t), s.set(e, i)
        } else {
          let e = !1;
          const n = new Map;
          for (const i of t.split("|")) {
            const t = i.split(":")
              .filter(y);
            if (1 !== t.length && 2 !== t.length) throw new Error(`bad session section: ${i}`);
            const s = 1 === t.length;
            if (s) {
              if (e) throw new Error(`duplicated default section: ${i}`);
              e = !0
            }
            const o = s ? _ : v._parseWorkingDays(t[1]);
            for (const e of o) s && n.has(e) || n.set(e, t[0])
          }
          for (const e of p) {
            const t = n.get(e);
            if (void 0 !== t)
              for (const n of t.split(",")
                  .filter(y)) {
                const t = v._parseSessionEntry(e, n, i);
                let r = s.get(e);
                void 0 === r && (r = []), r.push(t), o.push(t), s.set(e, r)
              }
          }
        }
      o.sort(l);
      const n = new Set;
      for (const e of o) n.add(e.dayOfWeek());
      const r = 7 - n.size;
      return new d(o, s, this._firstDayOfWeek, r)
    }
    _parseFirstDayOfWeek(e) {
      const t = e.split(";");
      if (this._firstDayOfWeek = n.MONDAY, t.length > 2) throw new Error(`bad sessions spec: ${e}`);
      if (1 === t.length) return e;
      let i = 1;
      let s = t[0].indexOf("-") >= 0 ? NaN : parseInt(t[0]);
      if (isNaN(s) && (i = 0, s = parseInt(t[1])), s < n.SUNDAY || s > n.SATURDAY) throw new Error(
        `bad sessions spec: ${e}`);
      return this._firstDayOfWeek = s, t[i]
    }
    _adjustStartToPreviousSession(e) {
      if (0 === this.historyEntries.length) return null;
      const t = (0, o.ensureNotNull)(this.historyEntries[this.historyEntries.length - 1].getSpecEndDay()),
        i = e - (0, n.get_day_of_week)(t);
      if (0 === i) return t;
      const s = (0, n.clone)(t);
      return (0,
        n.add_date)(s, i), t.getTime() < s.getTime() || (0, n.add_date)(s, 7), s
    }
    static _parseSessionEntry(e, t, i) {
      const s = t.split("-");
      if (2 !== s.length) throw new Error(`bad session entry: ${t}`);
      let o = 0,
        n = s[0];
      if (n.includes("F")) {
        const e = n.split("F");
        n = e[0], o = "" !== e[1] ? parseInt(e[1]) : 1
      }
      let r = 0,
        a = s[1];
      if (a.includes("F")) {
        const e = a.split("F");
        a = e[0], r = "" !== e[1] ? parseInt(e[1]) : 1
      }
      const l = this._minutesFromHHMM(n, t, i),
        c = this._minutesFromHHMM(a, t, i);
      return this._createSessionEntry(e, l, c, o, r)
    }
    static _minutesFromHHMM(e, t, i) {
      if (4 === e.length && m(e.charCodeAt(0)) && m(e.charCodeAt(1)) && m(e.charCodeAt(2)) && m(e.charCodeAt(3))) {
        const t = parseInt(e),
          s = Math.trunc(t / 100),
          o = t % 100;
        if (!i || s < 24 && o < 60) return o + 60 * s
      }
      throw new Error(`incorrect entry syntax: ${t}`)
    }
    static _parseDay(e, t, i) {
      if (8 === e.length && m(e.charCodeAt(0)) && m(e.charCodeAt(1)) && m(e.charCodeAt(2)) && m(e.charCodeAt(3)) && m(
          e.charCodeAt(4)) && m(e.charCodeAt(5)) && m(e.charCodeAt(6)) && m(e.charCodeAt(7))) {
        const t = parseInt(e.substring(0, 4)),
          s = parseInt(e.substring(4, 6)),
          o = parseInt(e.substring(6, 8));
        if (!i || this._isValidDayOfMonth(o, s, t)) return new a.BusinessDay(t, s, o)
      }
      throw new Error(`bad ${t} date: ${e}`)
    }
    static _isValidDayOfMonth(e, t, i) {
      return !(t < 1 || t > 12) && (!(e < 1 || e > g[t]) || !(2 !== t || 29 !== e || !(0, n.is_leap_year)(i)))
    }
    static _parseWorkingDays(e) {
      const t = [];
      for (let i = 0; i < e.length; i++) {
        const s = e.charCodeAt(i) - 48;
        if (s < 1 || s > 7) throw new Error(`Invalid days specification: ${e}`);
        t.includes(s) || t.push(s)
      }
      return t
    }
    static _createSessionEntry(e, t, i, s, r) {
      (0, o.assert)(s >= 0 && s < 7), (0, o.assert)(r >= 0 && r < 7), 0 === i && (i = n.minutesPerDay), s === r &&
        i <= t && (s += 1), (0, o.assert)(s >= r), s > 0 && (t -= s * n.minutesPerDay), r > 0 && (i -= r * n
          .minutesPerDay);
      const a = i - t;
      return (0, o.assert)(e >= n.SUNDAY && e <= n.SATURDAY), (0, o.assert)(t < n.minutesPerDay), (0, o.assert)(a >
        0), new c(e, t, a)
    }
    static _parseHolidaysAndCorrectionsImpl(e, t, i, s) {
      const o = new f;
      if ("" !== t) {
        const e = [];
        for (const i of t.split(",")) {
          const t = this._parseDay(i, "holiday", s);
          o.set(t, e)
        }
      }
      if ("" === i) return o;
      for (const e of i.split(";")) {
        const t = e.split(":");
        if (2 !== t.length) throw new Error(`bad correction section: ${e}`);
        const i = [];
        if ("dayoff" !== t[0])
          for (const e of t[0].split(",")) i.push(this._parseSessionEntry(1, e, s));
        for (const e of t[1].split(",")) {
          const t = this._parseDay(e, "correction", s),
            r = (0, n.get_day_of_week)(t.toCalendar()),
            a = [];
          for (let e = 0; e < i.length; e++) {
            const t = i[e];
            a.push(new c(r, t.startOffset(), t.length()))
          }
          o.set(t, a)
        }
      }
      return o
    }
  }

  function S(e, t) {
    return e.compareTo(t) < 0
  }
  const b = (0, n.get_timezone)("Etc/UTC");
  var w;
  ! function(e) {
    e[e.Closest = 0] = "Closest", e[e.FirstInDay = -1] = "FirstInDay", e[e.LastInDay = 1] = "LastInDay"
  }(w || (w = {}));
  class C {
    constructor(e) {
      this._value = e
    }
    get() {
      return this._value
    }
    set(e) {
      this._value = e
    }
  }
  class T {
    constructor(e = "Etc/UTC", t = "0000-0000", i = "", s = "", o = !1) {
      const r = new v;
      o ? r.parseSessionsAndValidateDateTime(e, t) : r.parseSessions(e, t), this._entries = r.historyEntries, this
        ._hasHistoryCorrections = r.hasHistoryCorrections, this._presentHistoryEntry = r.historyEntries[r
          .historyEntries.length - 1], this._timezone = r.timezone, this._timezoneObj = (0, n.get_timezone)(r
          .timezone),
        this._holidayAndCorrectionMap = o ? v.parseHolidaysAndCorrectionsAndValidateDateTime(e, i, s) : v
        .parseHolidaysAndCorrections(e, i, s, o);
      const a = this._holidayAndCorrectionMap.keys();
      this._entriesHash = new Map;
      const l = this._prepareSessionsBorderParams();
      this._borderWeeksIndicesHash = l.borderWeeksIndicesHash, this._yearToWeeksIndicesHash = l
        .yearToWeeksIndicesHash, this._weekIndicesOfLastHistoryWeek = l.weekIndicesOfLastHistoryWeek, this
        ._presentStartWeekIndex = l.startPresentSessionWeekIndex, this._yearToCalculatedAddedWeekIndicesHash =
        new Map, "" === i && "" === s && null === this._weekIndicesOfLastHistoryWeek ? this._isThereCorrections = !1 :
        this._isThereCorrections = !0;
      for (const e of a) {
        const t = this.getWeekIndex(e.toCalendar());
        this._entriesHash.set(t, new C(null))
      }
    }
    hasHistoryCorrections() {
      return this._hasHistoryCorrections
    }
    firstDayOfWeek() {
      return this._presentHistoryEntry.getEntries()
        .firstDayOfWeek()
    }
    includesDay(e) {
      return this._getEntriesForDay(e)
        .length > 0
    }
    getEntriesForWeek(e) {
      if (!this._isThereCorrections) return this._presentHistoryEntry.getEntries();
      (0, o.assert)(e >= 0);
      const t = e,
        i = this._entriesHash.get(t);
      if (void 0 === i) {
        return this._getHistoryAndIndexForWeek(t)
          .getEntries()
      }
      let s = i.get();
      if (null !== s) return s;
      let r = null;
      const c = this._borderWeeksIndicesHash.get(t);
      r = void 0 === c ? this._getHistoryAndIndexForWeek(t)
        .getEntries() : this._prepareBorderWeekHistory(c);
      const h = new Map(r.entriesByDay());
      let u = [...r.list()];
      const _ = this._weekIndexToLocalDateTime(e),
        m = this._weekIndexToLocalDateTime(e + 1),
        g = a.BusinessDay.fromCalendar(_),
        f = a.BusinessDay.fromCalendar(m);
      for (const [e, t] of this._selectHolidays(g, f)) {
        const i = (0, n.get_day_of_week)(e.toCalendar());
        u = u.filter((e => e.dayOfWeek() !== i)), u.push(...t), 0 === t.length ? h.delete(i) : h.set(i, t)
      }
      u.sort(l);
      const y = p.length - h.size;
      return s = new d(u, h, r.firstDayOfWeek(), y), i.set(s), s
    }
    getHistoryByIndex(e) {
      return this._entries[e]
    }
    timezone() {
      return this._timezone
    }
    timezoneObj() {
      return this._timezoneObj
    }
    longestSessionLength() {
      let e = this._presentHistoryEntry.getEntries()
        .longestSessionLength();
      for (let t = 0; t < this._entries.length - 1; t++) {
        const i = this._entries[t].getEntries()
          .longestSessionLength();
        e = Math.max(e, i)
      }
      let t = -1 / 0;
      for (const e of this._holidayAndCorrectionMap.values()) t = Math.max(t, ...e.map((e => e.length())));
      return Math.max(t, e)
    }
    isWeekEnd(e) {
      const t = this.getWeekIndex(e);
      let i;
      return i = void 0 === this._borderWeeksIndicesHash.get(t) ? this._getHistoryAndIndexForWeek(t)
        .getEntries() : this.getEntriesForWeek(t), i.isWeekEnd((0, n.get_day_of_week)(e))
    }
    isCalWeekEnd(e) {
      const t = (0, n.get_day_of_week)(e);
      if (!this._isThereCorrections) return this._presentHistoryEntry.getEntries()
        .isWeekEnd(t);
      const i = this.getWeekIndex(e),
        s = this.getEntriesForWeek(i),
        o = a.BusinessDay.fromCalendar(e),
        r = this._holidayAndCorrectionMap.get(o);
      return void 0 === r ? s.isWeekEnd(t) : 0 === r.length
    }
    holidaysFromYearStart(e) {
      const t = e instanceof a.BusinessDay ? e : a.BusinessDay.fromCalendar(e);
      return this._holidaysFromYearStart(t)
    }
    daysOffFromYearStart(e) {
      const t = (0, n.get_cal)(b, (0, n.get_year)(e), n.JANUARY, 1),
        i = this.getWeekIndex(t),
        s = (0, n.get_day_of_week)(t),
        o = (0, n.get_day_of_week)(e) - 1;
      if ((0,
          n.get_day_of_year)(e) + s <= n.LAST_DAY_OF_WEEK + n.FIRST_DAY_OF_WEEK) return this
        ._getDaysOffForWeekInBorders(i, s, o);
      const r = this.getWeekIndex(e);
      let a = this._getDaysOffForWeekInBorders(i, s, n.LAST_DAY_OF_WEEK);
      for (let e = i + 1; e < r; e++) {
        a += this.getEntriesForWeek(e)
          .weekEndsCount()
      }
      return a += this._getDaysOffForWeekInBorders(r, n.FIRST_DAY_OF_WEEK, o), a
    }
    weekEndsCountForSingleSession() {
      return (0, o.assert)(!this.hasHistoryCorrections()), this._presentHistoryEntry.getEntries()
        .weekEndsCount()
    }
    intradayCanBeBuiltFrom24x7(e) {
      for (const t of this._entries)
        if (!t.getEntries()
          .list()
          .every((t => t.start() % e == 0 && t.length() % e == 0))) return !1;
      return !0
    }
    intradayCanBeBuiltFrom24x7Seconds(e) {
      for (const t of this._entries)
        if (!t.getEntries()
          .list()
          .every((t => 60 * t.start() % e == 0 && 60 * t.length() % e == 0))) return !1;
      return !0
    }
    indexOfSession(e, t, i) {
      (0, o.assert)(t >= n.SUNDAY && t <= n.SATURDAY), (0, o.assert)(i >= 0 && i < n.minutesPerDay);
      const s = this.getEntriesForWeek(e),
        a = s.list();
      let l = (0, r.lowerbound)(a, new c(t, i, 0), S);
      if (l < a.length) return new h(e, l, [...a]);
      let d = e + 1,
        u = this.getEntriesForWeek(d);
      if (0 !== u.list()
        .length) {
        const e = 7 - t + u.firstDayOfWeek() - 1;
        if (i = -(n.minutesPerDay - i + e * n.minutesPerDay), l = (0, r.lowerbound)(u.list(), new c(u
          .firstDayOfWeek(), i, 0), S), l < u.list()
          .length) return new h(d, l, [...u.list()])
      }
      for (;;)
        if (d++, i -= n.minutesPerWeek, u = this.getEntriesForWeek(d), 0 !== u.list()
          .length && (l = (0, r.lowerbound)(u.list(), new c(s.firstDayOfWeek(), i, 0), S), !(l >= u.list()
            .length))) return new h(d, l, [...u.list()])
    }
    findSession(e, t, i, s = 0) {
      const o = this.indexOfSession(e, t, i),
        n = o.entries;
      let r = o.entryIndex;
      if (0 !== s) {
        const e = n[r].dayOfWeek(),
          t = s > 0 ? 1 : -1;
        for (;;) {
          const i = r + t;
          if (i < 0 || i >= n.length || n[i].dayOfWeek() !== e) break;
          r = i
        }
      }
      return new h(o.weekIndex, r, n)
    }
    getWeekIndex(e) {
      return this._isThereCorrections ? T._getWeekIndexImpl(e) : 0
    }
    correctTradingDay(e) {
      const t = this._correctTradingDay(this.getWeekIndex(e), (0, n.get_day_of_week)(e), (0, n.get_minutes_with_hours)
          (e)),
        i = (0, n.clone)(e);
      return (0, n.add_date)(i, t), i
    }
    alignToSessionStart(e, t = 0) {
      const i = (0, n.get_day_of_week)(e),
        s = (0, n.get_minutes_from_midnight)(e),
        o = this.getWeekIndex(e),
        r = this.findSession(o, i, s, t),
        a = r.getEntry(),
        l = a.dayOfWeek() - i + 7 * Math.trunc(r.weekIndex - o);
      0 !== l && (0, n.add_date)(e, l);
      const c = a.startOffset();
      return (0, n.set_hms)(e, Math.trunc(c / 60), c % 60, 0, 0), a.length()
    }
    businessDaysToCalendarDays(e, t) {
      return this._businessDaysToCalendarDays(this.getWeekIndex(e), (0, n.get_day_of_week)(e), t)
    }
    calendarDaysToBusinessDays(e, t) {
      return this._calendarDaysToBusinessDays(this.getWeekIndex(e), (0, n.get_day_of_week)(e), t)
    }
    alignToNearestSessionStart(e, t) {
      return this._alignToNearestSessionValue(e, t, this._entrySessionStart.bind(this))
    }
    alignToNearestSessionEnd(e, t) {
      return this._alignToNearestSessionValue(e, t, this._entrySessionEnd.bind(this))
    }
    bordersOfDailyBar(e) {
      const t = this._getEntriesForDay(e);
      if (0 === t.length) return null;
      const i = t.slice();
      i.sort(l);
      const s = this._getLeftEntryBorder(e, i[0]),
        o = i[i.length - 1],
        r = 60 * (o.startOffset() + o.length()) - 1,
        a = (0, n.clone)(e);
      return (0, n.set_seconds)(a, r), {
        from: s,
        to: a
      }
    }
    leftBorderOfDailyBar(e) {
      const t = this._getEntriesForDay(e);
      if (0 === t.length) return null;
      const i = t.slice();
      return i.sort(l), this._getLeftEntryBorder(e, i[0])
    }
    checkSession() {
      return this._checkEachHistorySession() && this._checkSpecialEntries() && this._checkTooManyCorrectionsOnWeek()
    }
    inSession(e) {
      e = new Date(1e3 * Math.floor(e.getTime() / 1e3));
      const t = this.alignToNearestSessionStart(e, -1),
        i = this.alignToNearestSessionEnd(t, 1);
      return !(e.getTime() > i.getTime())
    }
    hasWeekEnds() {
      for (const e of this._entries)
        if (0 !== e.getEntries()
          .weekEndsCount()) return !0;
      return !1
    }
    getWeekIndicesWithAdditionalWeekBars(e) {
      let t = this._yearToCalculatedAddedWeekIndicesHash.get(e);
      return void 0 === t && (t = this._calculateAddedIndices(e), this._yearToCalculatedAddedWeekIndicesHash.set(e,
        t)), t
    }
    _prepareSessionsBorderParams() {
      const e = new Map,
        t = new Map;
      let i = null;
      this._entries.length > 1 && (i = Array.from({
        length: this._entries.length - 1
      }, (() => 0)));
      let s = 0;
      for (let n = 0; n < this._entries.length - 1; n++) {
        const r = this._entries[n + 1],
          a = (0, o.ensureNotNull)(r.getStartDay());
        s = T._getWeekIndexImpl(a), e.set(s, n + 1), this._addToYearHash(t, a, s), this._entriesHash.set(s, new C(
          null)), (0, o.ensureNotNull)(i)[n] = s
      }
      return {
        borderWeeksIndicesHash: e,
        yearToWeeksIndicesHash: t,
        startPresentSessionWeekIndex: s,
        weekIndicesOfLastHistoryWeek: i
      }
    }
    _addToYearHash(e, t, i) {
      const s = (0, n.get_year)(t);
      let o = e.get(s);
      void 0 === o && (o = [], e.set(s, o)), o.push(i)
    }
    _getHistoryAndIndexForWeek(e) {
      if (this._presentStartWeekIndex <= e) return this._presentHistoryEntry;
      const t = this._getIndexOfHistoryEntry(e);
      return this._entries[t]
    }
    _getIndexOfHistoryEntry(e) {
      let t = 0,
        i = this._entries.length - 1,
        s = Math.floor((t + i) / 2);
      for ((0, o.assert)(null !== this._weekIndicesOfLastHistoryWeek);;) {
        if (this._weekIndicesOfLastHistoryWeek[s] >= e) {
          if (i = s - 1, i < t) return s
        } else if (t = s + 1, i < t) return s + 1;
        s = Math.floor((t + i) / 2)
      }
    }
    _selectHolidays(e, t) {
      const i = new Set;
      for (const [s, o] of this._holidayAndCorrectionMap) s.compareTo(e) >= 0 && s.compareTo(t) < 0 && i.add([s, o]);
      return i
    }
    _prepareBorderWeekHistory(e) {
      const t = this._entries[e - 1],
        i = this._entries[e],
        s = new Map,
        r = [],
        a = (0, n.get_day_of_week)((0, o.ensureNotNull)(i.getStartDay()));
      for (let e = 0; e < p.length; e++) {
        const o = p[e];
        if (o < a) {
          const e = t.getEntries()
            .entriesByDay()
            .get(o);
          void 0 !== e && (r.push(...e), s.set(o, e))
        } else {
          const e = i.getEntries()
            .entriesByDay()
            .get(o);
          void 0 !== e && (r.push(...e), s.set(o, e))
        }
      }
      return new d(r, s, i.getEntries()
        .firstDayOfWeek(), 0)
    }
    _holidaysFromYearStart(e) {
      if (!this._isThereCorrections) return 0;
      (0, o.assert)(!this.hasHistoryCorrections());
      const t = e.firstDayOfYear();
      let i = 0;
      for (const [s, o] of this._selectHolidays(t, e)) {
        const e = s.getDayOfWeek(),
          t = 0 === o.length;
        this._presentHistoryEntry.getEntries()
          .isWeekEnd(e) ? i += t ? 0 : -1 : i += t ? 1 : 0
      }
      return i
    }
    _getDaysOffForWeekInBorders(e, t, i) {
      let s = 0;
      const o = this.getEntriesForWeek(e);
      for (let e = t; e <= i; e++) o.entriesByDay()
        .has(e) || s++;
      return s
    }
    _weekIndexToLocalDateTime(e) {
      const t = Math.floor(86400 * e * 7 + 86400 - 62167219200),
        i = (0, n.get_cal_from_unix_timestamp_ms)(b, 1e3 * t);
      return (0, n.set_hms)(i, 0, 0, 0, 0), i
    }
    _correctTradingDay(e, t, i) {
      const s = this.findSession(e, t, i, 0);
      return s.getEntry()
        .dayOfWeek() - t + 7 * Math.trunc(s.weekIndex - e)
    }
    _entrySessionValue(e, t, i, s) {
      t = (0, n.clone)(t);
      let o = (0, n.get_day_of_week)(t);
      const r = e.getEntry();
      let a = r.dayOfWeek() - r.sessionStartDaysOffset();
      const l = this.getWeekIndex(t);
      let c = Math.trunc(e.weekIndex - l),
        h = !1;
      if (a < n.SUNDAY && (c <= 0 ? h = !0 : c--, a += 7), (c > 0 && i >= 0 || c < 0 && i < 0) && (0, n.add_date)(t,
          7 * c), !r.contains(t)) {
        let e = a - o;
        h && i < 0 && (e = -(7 - a + o)), (0, n.add_date)(t, e), o = (0, n.get_day_of_week)(t)
      }
      if (r.isOvernight()) {
        const e = r.sessionStartDaysOffset(),
          i = (o - (r.dayOfWeek() - e) + 7) % 7;
        0 !== i && (0, n.add_date)(t, -i)
      }
      const d = s(r);
      return (0, n.set_seconds)(t, d), t
    }
    _businessDaysToCalendarDays(e, t, i) {
      let s = 0,
        o = 0;
      for (; o < i;) {
        const r = this.getEntriesForWeek(e);
        for (let e = t; e <= n.SATURDAY; e++)
          if (s++, void 0 !== r.entriesByDay()
            .get(e) && o++, o >= i) return s;
        e++, t = n.SUNDAY
      }
      return s
    }
    _calendarDaysToBusinessDays(e, t, i) {
      let s = 0,
        o = 0;
      for (; s < i;) {
        const r = this.getEntriesForWeek(e);
        for (let e = t; e <= n.SATURDAY; e++)
          if (s++, void 0 !== r.entriesByDay()
            .get(e) && o++, s >= i) return o;
        e++, t = n.SUNDAY
      }
      return o
    }
    _entrySessionStart(e, t, i) {
      return this._entrySessionValue(e, t, i, (e => 60 * e.start()))
    }
    _entrySessionEnd(e, t, i) {
      return this._entrySessionValue(e, t, i, (e => 60 * (e.start() + e.length()) - 1))
    }
    _alignToNearestSessionValue(e, t, i) {
      const s = (0, n.get_day_of_week)(e),
        o = (0, n.get_minutes_with_hours)(e),
        r = this.getWeekIndex(e);
      let a = this.findSession(r, s, o);
      if (1 === t) return i(a, e, t);
      const l = a.getEntry(),
        c = l.contains(e),
        d = r === a.weekIndex,
        u = l.sessionStartDaysOffset() - l.dayOfWeek() >= 0;
      if (c && (d || u)) return i(a, e, t);
      let _ = a.entryIndex - 1;
      if (_ < 0) {
        let e = a.weekIndex,
          t = a.entries;
        if (0 === e) e--, _ += t.length;
        else
          for (; _ < 0;) e--, t = this.getEntriesForWeek(e)
            .list(), _ += t.length;
        a = new h(e, _, t)
      } else a = new h(a.weekIndex, _, a.entries);
      return i(a, e, t)
    }
    _getEntriesForDay(e) {
      const t = (0, n.get_day_of_week)(e),
        i = this.getEntriesForWeek(this.getWeekIndex(e))
        .entriesByDay()
        .get(t);
      return void 0 !== i ? i : []
    }
    _getLeftEntryBorder(e, t) {
      let i = t.startOffset();
      const s = -Math.trunc((i - 1439) / 1440);
      i += 1440 * s;
      const o = (0, n.get_cal)(b, (0, n.get_year)(e), (0, n.get_month)(e), (0, n.get_day_of_month)(e), Math.trunc(i /
        60), i % 60, 0);
      return (0, n.add_date)(o, -s), o
    }
    _checkEachHistorySession() {
      for (const e of this._entries) {
        const t = e.getEntries()
          .list();
        if (!this._checkEntriesForIntersections(t, t, t)) return !1
      }
      return !0
    }
    _checkEntriesForIntersections(e, t, i) {
      const s = this._buildTestEntries(e, t, i);
      for (let e = 0; e < s.length - 1; e++)
        for (let t = e + 1; t < s.length; t++)
          if (0 === s[e].compareTo(s[t])) return !1;
      return !0
    }
    _buildTestEntries(e, t, i) {
      const s = [];
      for (let t = 0; t < e.length; t++) {
        const i = e[t],
          o = new c(i.dayOfWeek(), i.startOffset(), i.length());
        s.push(o)
      }
      for (let e = 0; e < t.length; e++) {
        const i = t[e],
          o = new c(i.dayOfWeek() + 7, i.startOffset(), i.length());
        s.push(o)
      }
      for (let e = 0; e < i.length; e++) {
        const t = i[e],
          o = new c(t.dayOfWeek() + 14, t.startOffset(), t.length());
        s.push(o)
      }
      return s
    }
    _checkSpecialEntries() {
      for (const [e] of this._entriesHash) {
        const t = this.getEntriesForWeek(e)
          .list(),
          i = this.getEntriesForWeek(e - 1)
          .list(),
          s = this.getEntriesForWeek(e + 1)
          .list();
        if (!this._checkEntriesForIntersections(i, t, s)) return !1
      }
      return !0
    }
    _checkTooManyCorrectionsOnWeek() {
      if (this._entries.length < 2) return !0;
      for (let e = 0; e < this._entries.length - 2; e++) {
        const t = this._entries[e],
          i = this._entries[e + 1];
        if (this.getWeekIndex((0, o.ensureNotNull)(t.getSpecEndDay())) === this.getWeekIndex((0, o.ensureNotNull)(i
            .getSpecEndDay()))) return !1
      }
      return !0
    }
    _calculateAddedIndices(e) {
      const t = [],
        i = this._yearToWeeksIndicesHash.get(e);
      if (void 0 === i) return t;
      for (const e of i) {
        const i = (0, o.ensureDefined)(this._borderWeeksIndicesHash.get(e)),
          s = this._entries[i],
          r = this._entries[i - 1];
        let a = s.getEntries()
          .firstDayOfWeek() - r.getEntries()
          .firstDayOfWeek();
        for (; a > 0;) {
          const r = (0, n.clone)((0, o.ensureNotNull)(s.getStartDay()));
          if ((0, n.add_date)(r, -a), !this.isCalWeekEnd(r)) {
            const s = {
              entryIndex: i,
              weekIndex: e
            };
            t.push(s);
            break
          }
          a--
        }
      }
      return t
    }
    static _getWeekIndexImpl(e) {
      const t = (0, n.get_cal_utc)((0, n.get_year)(e), (0, n.get_month)(e), 1);
      (0, n.add_date)(t, (0, n.get_day_of_month)(e) - (0, n.get_day_of_week)(e));
      const i = t.getTime() / 1e3;
      return (0, o.assert)((i + 62167219200) % 86400 == 0), Math.trunc((i + 62167219200) / 86400 / 7)
    }
  }
