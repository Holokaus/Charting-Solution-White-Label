// Module 60973
// Original file: 60973.js
// Size: 35.8 KB
// Purpose: Auto-extracted webpack module from TradingView library

(e, t, i) => {
  "use strict";
  var {
    clone: s,
    merge: o
  } = i(87465), n = i(86572)
    .PlDisplay;
  const {
    generateColor: r
  } = i(52859), {
      getStdChartTheme: a
    } = i(24317), {
      DEFAULT_THEME: l
    } = i(22489), c = i(49156)
    .colors;
  var h = i(86572)
    .TradedGroupHorizontalAlignment,
    d = i(82095),
    u = i(36947)
    .LineToolPitchforkStyle,
    _ = i(45580)
    .LineToolBarsPatternMode,
    p = i(4359),
    m = p.LineStudyPlotStyle,
    g = p.STUDYPLOTDISPLAYTARGET,
    f = i(19679),
    y = i(97902)
    .PriceAxisLastValueMode,
    v = i(7024)
    .MagnetMode,
    S = i(25672)
    .LineEnd,
    b = i(93201)
    .ColorType;
  const w = i(59883)
    .DEFAULT_LINE_TOOL_LINE_WIDTH;
  var C = i(97760)
    .StatsPosition,
    T = i(57511)
    .sessionsPreferencesDefault,
    P = i(72755)
    .axisLabelBackgroundColor,
    x = i(59064)
    .mainSeriesProperties;
  const {
    LINESTYLE_SOLID: M,
    LINESTYLE_DASHED: I
  } = i(69558);
  var A = i(9343)
    .getLogger("Chart.Defaults");
  const {
    colorWhite: L,
    colorWhiteAlpha25: k,
    colorTvBlue50: E,
    colorTvBlue500: D,
    colorTvBlue500Alpha30: B,
    colorTvBlue500Alpha25: V,
    colorTvBlue500Alpha20: R,
    colorTvBlue600: N,
    colorDeepBlue200: O,
    colorDeepBlue300: F,
    colorDeepBlue500: W,
    colorDeepBlue500Alpha20: H,
    colorSkyBlue500: z,
    colorSkyBlue500Alpha20: U,
    colorSkyBlue500Alpha25: j,
    colorSkyBlue700: G,
    colorSkyBlue700Alpha70: q,
    colorDefaultRed: $,
    colorRipeRed200: K,
    colorRipeRed300: Y,
    colorRipeRed400: Z,
    colorRipeRed400Alpha5: X,
    colorRipeRed500: J,
    colorRipeRed500Alpha30: Q,
    colorRipeRed500Alpha20: ee,
    colorRipeRed600: te,
    colorGrapesPurple500: ie,
    colorGrapesPurple500Alpha0: se,
    colorGrapesPurple500Alpha20: oe,
    colorGrapesPurple500Alpha70: ne,
    colorBerryPink400: re,
    colorBerryPink500: ae,
    colorBerryPink500Alpha20: le,
    colorBerryPink500Alpha25: ce,
    colorMintyGreen100: he,
    colorMintyGreen400: de,
    colorMintyGreen500: ue,
    colorMintyGreen500Alpha20: _e,
    colorIguanaGreen300: pe,
    colorIguanaGreen500: me,
    colorIguanaGreen500Alpha20: ge,
    colorTanOrange300: fe,
    colorTanOrange500: ye,
    colorTanOrange500Alpha20: ve,
    colorTanOrange600: Se,
    colorTanOrange700: be,
    colorColdGray150: we,
    colorColdGray400: Ce,
    colorColdGray450: Te,
    colorColdGray500: Pe,
    colorColdGray550: xe,
    colorColdGray900: Me,
    colorColdGray750: Ie,
    colorForestGreen300: Ae,
    colorForestGreen300Alpha5: Le
  } = c;
  var ke = function(e) {
    var t = function(e, t) {
        return {
          color: e,
          visible: t
        }
      },
      i = function(e, t, i, s) {
        const o = {
          coeff: e,
          color: t,
          visible: i
        };
        return s && (o.text = ""), o
      },
      p = function(e, t, i, s, o) {
        return {
          coeff: e,
          color: t,
          visible: i,
          linestyle: void 0 === s ? M : s,
          linewidth: void 0 === o ? w : o
        }
      },
      A = function(e, t, i) {
        return {
          color: e,
          width: void 0 === i ? w : i,
          visible: t
        }
      },
      ke = function(e, t, i, s, o) {
        return {
          color: e,
          visible: t,
          width: i,
          x: s,
          y: o
        }
      },
      Ee = function(e, t, i, s, o, n) {
        return {
          coeff1: e,
          coeff2: t,
          color: i,
          visible: s,
          linestyle: void 0 === o ? M : o,
          linewidth: void 0 === n ? w : n
        }
      };
    if (void 0 === TradingView.defaultProperties) {
      var Be;
      switch (window.locale) {
        case "ar_AE":
          Be = "Asia/Dubai";
          break;
        case "au":
          Be = "Australia/Sydney";
          break;
        case "br":
          Be = "America/Sao_Paulo";
          break;
        case "ca":
          Be = "America/Toronto";
          break;
        case "de_DE":
        case "it":
          Be = "Europe/Berlin";
          break;
        case "es":
          Be = "Europe/Madrid";
          break;
        case "he_IL":
        case "tr":
          Be = "Europe/Athens";
          break;
        case "hu_HU":
        case "pl":
          Be = "Europe/Warsaw";
          break;
        case "id":
        case "th_TH":
        case "vi_VN":
          Be = "Asia/Bangkok";
          break;
        case "in":
          Be = "Asia/Kolkata";
          break;
        case "ja":
        case "kr":
          Be = "Asia/Tokyo";
          break;
        case "ms_MY":
          Be = "Asia/Singapore";
          break;
        case "ru":
          Be = "Europe/Moscow";
          break;
        case "uk":
          Be = "Europe/London";
          break;
        case "zh_CN":
        case "zh_TW":
          Be = "Asia/Shanghai";
          break;
        default:
          Be = "Etc/UTC"
      }
      const e = a(l);
      TradingView.defaultProperties = {
        chartproperties: o({
          timezone: Be,
          priceScaleSelectionStrategyName: "auto",
          inactivityGaps: !1,
          paneProperties: {
            backgroundType: b.Solid,
            gridLinesMode: "both",
            vertGridProperties: {
              style: M
            },
            horzGridProperties: {
              style: M
            },
            crossHairProperties: {
              style: I,
              transparency: 0,
              width: 1
            },
            topMargin: 10,
            bottomMargin: 8,
            axisProperties: {
              autoScale: !0,
              autoScaleDisabled: !1,
              lockScale: !1,
              percentage: !1,
              percentageDisabled: !1,
              indexedTo100: !1,
              log: !1,
              logDisabled: !1,
              alignLabels: !0,
              isInverted: !1
            },
            legendProperties: {
              showStudyArguments: !0,
              showStudyTitles: !0,
              showStudyValues: !0,
              showSeriesTitle: !0,
              showSeriesOHLC: !0,
              showLegend: !0,
              showLastDayChange: !1,
              showBarChange: !0,
              showVolume: !1,
              showBackground: !0,
              showPriceSource: !0,
              backgroundTransparency: 50,
              showLogo: !0,
              showTradingButtons: !0,
              showTradingButtonsMobile: !0,
              showSeriesLegendCloseOnMobile: !0
            },
            separatorColor: we
          },
          scalesProperties: {
            fontSize: 12,
            scaleSeriesOnly: !1,
            showSeriesLastValue: !0,
            seriesLastValueMode: y.LastValueAccordingToScale,
            showSeriesPrevCloseValue: !1,
            showStudyLastValue: !0,
            showSymbolLabels: !1,
            showStudyPlotLabels: !1,
            showBidAskLabels: !1,
            showPrePostMarketPriceLabel: !0,
            showFundamentalNameLabel: !1,
            showFundamentalLastValue: !0,
            barSpacing: f.DEFAULT_BAR_SPACING,
            axisHighlightColor: V,
            axisLineToolLabelBackgroundColorCommon: P.common,
            axisLineToolLabelBackgroundColorActive: P.active,
            showPriceScaleCrosshairLabel: !0,
            showTimeScaleCrosshairLabel: !0,
            crosshairLabelBgColorLight: Me,
            crosshairLabelBgColorDark: Ie,
            saveLeftEdge: !1
          },
          mainSeriesProperties: o(x, e.content.mainSourceProperties),
          chartEventsSourceProperties: {
            visible: !0,
            futureOnly: !0,
            breaks: {
              color: "#555555",
              visible: !1,
              style: I,
              width: 1
            }
          },
          tradingProperties: {
            showPositions: !0,
            positionPL: {
              visibility: !0,
              display: n.Money
            },
            bracketsPL: {
              visibility: !0,
              display: n.Money
            },
            positionAndBracketsPL: !0,
            showOrders: !0,
            showExecutions: !0,
            showExecutionsLabels: !1,
            showReverse: !0,
            horizontalAlignment: h.Right,
            extendLeft: !0,
            lineLength: 5,
            lineWidth: 1,
            lineStyle: M
          },
          volumePaneSize: "large"
        }, e.content.chartProperties),
        sessions: o(T, e.content.sessions),
        drawings: {
          magnet: !1,
          magnetSnapsToIndicators: !1,
          magnetMode: v.WeakMagnet,
          stayInDrawingMode: !1,
          drawOnAllCharts: !0,
          drawOnAllChartsMode: 1
        },
        linetoolorder: {
          extendLeft: "inherit",
          lineLength: "inherit",
          lineLengthUnit: "percentage",
          lineColor: $,
          lineActiveBuyColor: "#4094e8",
          lineInactiveBuyColor: "rgba(64, 148, 232, 0.5)",
          lineActiveSellColor: "#e75656",
          lineInactiveSellColor: "rgba(231, 86, 86, 0.5)",
          lineStyle: "inherit",
          lineWidth: "inherit",
          bodyBorderActiveBuyColor: "#4094e8",
          bodyBorderInactiveBuyColor: "rgba(64, 148, 232, 0.5)",
          bodyBorderActiveSellColor: "#e75656",
          bodyBorderInactiveSellColor: "rgba(231, 86, 86, 0.5)",
          bodyBackgroundColor: k,
          bodyBackgroundTransparency: 25,
          bodyTextInactiveLimitColor: "rgba(38, 140, 2, 0.5)",
          bodyTextActiveLimitColor: "#268c02",
          bodyTextInactiveStopColor: "rgba(231, 86, 86, 0.5)",
          bodyTextActiveStopColor: "#e75656",
          bodyTextInactiveBuyColor: "rgba(64, 148, 232, 0.5)",
          bodyTextActiveBuyColor: "#4094e8",
          bodyTextInactiveSellColor: "rgba(231, 86, 86, 0.5)",
          bodyTextActiveSellColor: "#e75656",
          bodyFontFamily: "Verdana",
          bodyFontSize: 9,
          bodyFontBold: !0,
          bodyFontItalic: !1,
          quantityBorderActiveBuyColor: "#4094e8",
          quantityBorderInactiveBuyColor: "rgba(64, 148, 232, 0.5)",
          quantityBorderActiveSellColor: "#e75656",
          quantityBorderInactiveSellColor: "rgba(231, 86, 86, 0.5)",
          quantityBackgroundInactiveBuyColor: "rgba(64, 148, 232, 0.5)",
          quantityBackgroundActiveBuyColor: "#4094e8",
          quantityBackgroundInactiveSellColor: "rgba(231, 86, 86, 0.5)",
          quantityBackgroundActiveSellColor: "#e75656",
          quantityTextColor: L,
          quantityTextTransparency: 0,
          quantityFontFamily: "Verdana",
          quantityFontSize: 9,
          quantityFontBold: !0,
          quantityFontItalic: !1,
          cancelButtonBorderActiveBuyColor: "#4094e8",
          cancelButtonBorderInactiveBuyColor: "rgba(64, 148, 232, 0.5)",
          cancelButtonBorderActiveSellColor: "#e75656",
          cancelButtonBorderInactiveSellColor: "rgba(231, 86, 86, 0.5)",
          cancelButtonBackgroundColor: k,
          cancelButtonBackgroundTransparency: 25,
          cancelButtonIconActiveBuyColor: "#4094e8",
          cancelButtonIconInactiveBuyColor: "rgba(64, 148, 232, 0.5)",
          cancelButtonIconActiveSellColor: "#e75656",
          cancelButtonIconInactiveSellColor: "rgba(231, 86, 86, 0.5)",
          tooltip: "",
          modifyTooltip: "",
          cancelTooltip: ""
        },
        linetoolposition: {
          extendLeft: "inherit",
          lineLength: "inherit",
          lineLengthUnit: "percentage",
          lineBuyColor: "#4094e8",
          lineSellColor: "#e75656",
          lineStyle: "inherit",
          lineWidth: "inherit",
          bodyBorderBuyColor: "#4094e8",
          bodyBorderSellColor: "#e75656",
          bodyBackgroundColor: k,
          bodyBackgroundTransparency: 25,
          bodyTextPositiveColor: "#268c02",
          bodyTextNeutralColor: "#646464",
          bodyTextNegativeColor: "#e75656",
          bodyFontFamily: "Verdana",
          bodyFontSize: 9,
          bodyFontBold: !0,
          bodyFontItalic: !1,
          quantityBorderBuyColor: "#4094e8",
          quantityBorderSellColor: "#e75656",
          quantityBackgroundBuyColor: "#4094e8",
          quantityBackgroundSellColor: "#e75656",
          quantityTextColor: L,
          quantityTextTransparency: 0,
          quantityFontFamily: "Verdana",
          quantityFontSize: 9,
          quantityFontBold: !0,
          quantityFontItalic: !1,
          reverseButtonBorderBuyColor: "#4094e8",
          reverseButtonBorderSellColor: "#e75656",
          reverseButtonBackgroundColor: k,
          reverseButtonBackgroundTransparency: 25,
          reverseButtonIconBuyColor: "#4094e8",
          reverseButtonIconSellColor: "#e75656",
          closeButtonBorderBuyColor: "#4094e8",
          closeButtonBorderSellColor: "#e75656",
          closeButtonBackgroundColor: k,
          closeButtonBackgroundTransparency: 25,
          closeButtonIconBuyColor: "#4094e8",
          closeButtonIconSellColor: "#e75656",
          tooltip: "",
          protectTooltip: "",
          closeTooltip: "",
          reverseTooltip: ""
        },
        linetoolexecution: {
          direction: "buy",
          arrowHeight: 8,
          arrowSpacing: 1,
          arrowBuyColor: "#4094e8",
          arrowSellColor: "#e75656",
          text: "",
          textColor: c.colorBlack,
          textTransparency: 0,
          fontFamily: "Verdana",
          fontSize: 10,
          fontBold: !1,
          fontItalic: !1,
          tooltip: ""
        },
        linetoolimage: {
          transparency: 0,
          cssWidth: 0,
          cssHeight: 0,
          angle: 0
        },
        linetoolbezierquadro: {
          linecolor: D,
          linewidth: w,
          fillBackground: !1,
          backgroundColor: R,
          transparency: 50,
          linestyle: M,
          extendLeft: !1,
          extendRight: !1,
          leftEnd: S.Normal,
          rightEnd: S.Normal
        },
        linetoolbeziercubic: {
          linecolor: W,
          linewidth: w,
          fillBackground: !1,
          backgroundColor: H,
          transparency: 80,
          linestyle: M,
          extendLeft: !1,
          extendRight: !1,
          leftEnd: S.Normal,
          rightEnd: S.Normal
        },
        linetooltrendline: {
          linecolor: D,
          linewidth: w,
          linestyle: M,
          extendLeft: !1,
          extendRight: !1,
          leftEnd: S.Normal,
          rightEnd: S.Normal,
          horzLabelsAlign: "center",
          vertLabelsAlign: "bottom",
          textcolor: D,
          fontsize: 14,
          bold: !1,
          italic: !1,
          alwaysShowStats: !1,
          showMiddlePoint: !1,
          showPriceLabels: !1,
          showPriceRange: !1,
          showPercentPriceRange: !1,
          showPipsPriceRange: !1,
          showBarsRange: !1,
          showDateTimeRange: !1,
          showDistance: !1,
          showAngle: !1,
          statsPosition: C.Right
        },
        linetoolinfoline: {
          linecolor: D,
          linewidth: w,
          linestyle: M,
          extendLeft: !1,
          extendRight: !1,
          leftEnd: S.Normal,
          rightEnd: S.Normal,
          horzLabelsAlign: "center",
          vertLabelsAlign: "bottom",
          textcolor: D,
          fontsize: 14,
          bold: !1,
          italic: !1,
          alwaysShowStats: !0,
          showMiddlePoint: !1,
          showPriceLabels: !1,
          showPriceRange: !0,
          showPercentPriceRange: !0,
          showPipsPriceRange: !0,
          showBarsRange: !0,
          showDateTimeRange: !0,
          showDistance: !0,
          showAngle: !0,
          statsPosition: C.Center
        },
        linetooltimecycles: {
          linecolor: "#159980",
          linewidth: w,
          fillBackground: !0,
          backgroundColor: "rgba(106, 168, 79, 0.5)",
          transparency: 50,
          linestyle: M
        },
        linetoolsineline: {
          linecolor: "#159980",
          linewidth: w,
          linestyle: M
        },
        linetooltrendangle: {
          linecolor: D,
          linewidth: w,
          linestyle: M,
          fontsize: 12,
          bold: !1,
          italic: !1,
          alwaysShowStats: !1,
          showMiddlePoint: !1,
          showPriceLabels: !1,
          showPriceRange: !1,
          showPercentPriceRange: !1,
          showPipsPriceRange: !1,
          showBarsRange: !1,
          extendRight: !1,
          extendLeft: !1,
          statsPosition: C.Right
        },
        linetooldisjointangle: {
          linecolor: ue,
          linewidth: w,
          linestyle: M,
          fillBackground: !0,
          backgroundColor: _e,
          transparency: 20,
          extendLeft: !1,
          extendRight: !1,
          leftEnd: S.Normal,
          rightEnd: S.Normal,
          textcolor: ue,
          fontsize: 12,
          bold: !1,
          italic: !1,
          showPrices: !1,
          showPriceRange: !1,
          showDateTimeRange: !1,
          showBarsRange: !1,
          labelVisible: !1,
          labelHorzAlign: "left",
          labelVertAlign: "bottom",
          labelTextColor: ue,
          labelFontSize: 14,
          labelBold: !1,
          labelItalic: !1
        },
        linetoolflatbottom: {
          linecolor: ye,
          linewidth: w,
          linestyle: M,
          fillBackground: !0,
          backgroundColor: ve,
          transparency: 20,
          extendLeft: !1,
          extendRight: !1,
          leftEnd: S.Normal,
          rightEnd: S.Normal,
          textcolor: ye,
          fontsize: 12,
          bold: !1,
          italic: !1,
          showPrices: !1,
          showPriceRange: !1,
          showDateTimeRange: !1,
          showBarsRange: !1,
          labelVisible: !1,
          labelHorzAlign: "left",
          labelVertAlign: "bottom",
          labelTextColor: ye,
          labelFontSize: 14,
          labelBold: !1,
          labelItalic: !1
        },
        linetoolriskrewardshort: {
          linecolor: Pe,
          linewidth: 1,
          textcolor: L,
          fontsize: 12,
          fillLabelBackground: !0,
          labelBackgroundColor: "#585858",
          fillBackground: !0,
          stopBackground: ee,
          profitBackground: _e,
          stopBackgroundTransparency: 80,
          profitBackgroundTransparency: 80,
          drawBorder: !1,
          borderColor: "#667b8b",
          compact: !1,
          riskDisplayMode: "percents",
          accountSize: 1e3,
          lotSize: 1,
          risk: 25,
          alwaysShowStats: !1,
          showPriceLabels: !0,
          currency: "NONE"
        },
        linetoolriskrewardlong: {
          linecolor: Pe,
          linewidth: 1,
          textcolor: L,
          fontsize: 12,
          fillLabelBackground: !0,
          labelBackgroundColor: "#585858",
          fillBackground: !0,
          stopBackground: ee,
          profitBackground: _e,
          stopBackgroundTransparency: 80,
          profitBackgroundTransparency: 80,
          drawBorder: !1,
          borderColor: "#667b8b",
          compact: !1,
          riskDisplayMode: "percents",
          accountSize: 1e3,
          lotSize: 1,
          risk: 25,
          alwaysShowStats: !1,
          showPriceLabels: !0,
          currency: "NONE"
        },
        linetoolarrow: {
          linecolor: D,
          linewidth: w,
          linestyle: M,
          extendLeft: !1,
          extendRight: !1,
          leftEnd: S.Normal,
          rightEnd: S.Arrow,
          horzLabelsAlign: "center",
          vertLabelsAlign: "bottom",
          textcolor: D,
          fontsize: 14,
          bold: !1,
          italic: !1,
          alwaysShowStats: !1,
          showMiddlePoint: !1,
          showPriceLabels: !1,
          showPriceRange: !1,
          showPercentPriceRange: !1,
          showPipsPriceRange: !1,
          showBarsRange: !1,
          showDateTimeRange: !1,
          showDistance: !1,
          showAngle: !1,
          statsPosition: C.Right
        },
        linetoolray: {
          linecolor: D,
          linewidth: w,
          linestyle: M,
          extendLeft: !1,
          extendRight: !0,
          leftEnd: S.Normal,
          rightEnd: S.Normal,
          horzLabelsAlign: "center",
          vertLabelsAlign: "bottom",
          textcolor: D,
          fontsize: 14,
          bold: !1,
          italic: !1,
          alwaysShowStats: !1,
          showMiddlePoint: !1,
          showPriceLabels: !1,
          showPriceRange: !1,
          showPercentPriceRange: !1,
          showPipsPriceRange: !1,
          showBarsRange: !1,
          showDateTimeRange: !1,
          showDistance: !1,
          showAngle: !1,
          statsPosition: C.Right
        },
        linetoolextended: {
          linecolor: D,
          linewidth: w,
          linestyle: M,
          extendLeft: !0,
          extendRight: !0,
          leftEnd: S.Normal,
          rightEnd: S.Normal,
          horzLabelsAlign: "center",
          vertLabelsAlign: "bottom",
          textcolor: D,
          fontsize: 14,
          bold: !1,
          italic: !1,
          alwaysShowStats: !1,
          showMiddlePoint: !1,
          showPriceLabels: !1,
          showPriceRange: !1,
          showPercentPriceRange: !1,
          showPipsPriceRange: !1,
          showBarsRange: !1,
          showDateTimeRange: !1,
          showDistance: !1,
          showAngle: !1,
          statsPosition: C.Right
        },
        linetoolhorzline: {
          linecolor: D,
          linewidth: w,
          linestyle: M,
          showPrice: !0,
          textcolor: D,
          fontsize: 12,
          bold: !1,
          italic: !1,
          horzLabelsAlign: "center",
          vertLabelsAlign: "middle"
        },
        linetoolhorzray: {
          linecolor: D,
          linewidth: w,
          linestyle: M,
          showPrice: !0,
          textcolor: D,
          fontsize: 12,
          bold: !1,
          italic: !1,
          horzLabelsAlign: "center",
          vertLabelsAlign: "top"
        },
        linetoolvertline: {
          linecolor: D,
          linewidth: w,
          linestyle: M,
          extendLine: !0,
          showTime: !0,
          horzLabelsAlign: "center",
          vertLabelsAlign: "middle",
          textcolor: D,
          textOrientation: "vertical",
          fontsize: 14,
          bold: !1,
          italic: !1
        },
        linetoolcrossline: {
          linecolor: D,
          linewidth: w,
          linestyle: M,
          showPrice: !0,
          showTime: !0
        },
        linetoolfibtimezone: {
          horzLabelsAlign: "right",
          vertLabelsAlign: "bottom",
          showLabels: !0,
          fillBackground: !1,
          transparency: 80,
          trendline: {
            visible: !0,
            color: "#808080",
            linewidth: 1,
            linestyle: I
          },
          level1: p(0, Pe, !0),
          level2: p(1, D, !0),
          level3: p(2, D, !0),
          level4: p(3, D, !0),
          level5: p(5, D, !0),
          level6: p(8, D, !0),
          level7: p(13, D, !0),
          level8: p(21, D, !0),
          level9: p(34, D, !0),
          level10: p(55, D, !0),
          level11: p(89, D, !0)
        },
        linetooltext: {
          color: D,
          fontsize: 14,
          fillBackground: !1,
          backgroundColor: V,
          backgroundTransparency: 70,
          drawBorder: !1,
          borderColor: xe,
          bold: !1,
          italic: !1,
          fixedSize: !0,
          wordWrap: !1,
          wordWrapWidth: 200
        },
        linetooltextabsolute: {
          color: D,
          fontsize: 14,
          fillBackground: !1,
          backgroundColor: V,
          backgroundTransparency: 70,
          drawBorder: !1,
          borderColor: xe,
          bold: !1,
          italic: !1,
          fixedSize: !1,
          wordWrap: !1,
          wordWrapWidth: 200
        },
        linetoolballoon: {
          color: L,
          backgroundColor: ne,
          borderColor: se,
          fontsize: 14,
          transparency: 30
        },
        linetoolcomment: {
          color: L,
          backgroundColor: D,
          borderColor: D,
          fontsize: 16,
          transparency: 0
        },
        linetoolbrush: {
          linecolor: z,
          linewidth: w,
          smooth: 5,
          fillBackground: !1,
          backgroundColor: z,
          transparency: 50,
          leftEnd: S.Normal,
          rightEnd: S.Normal
        },
        linetoolhighlighter: {
          linecolor: ee,
          smooth: 5,
          transparency: 80,
          width: 20
        },
        linetoolpolyline: {
          linecolor: z,
          linewidth: w,
          linestyle: M,
          fillBackground: !0,
          backgroundColor: U,
          transparency: 80,
          filled: !1
        },
        linetoolsignpost: {
          emoji: "🙂",
          showImage: !1,
          plateColor: D,
          fontSize: 12,
          bold: !1,
          italic: !1
        },
        linetoolpath: {
          lineColor: D,
          lineWidth: w,
          lineStyle: M,
          leftEnd: S.Normal,
          rightEnd: S.Arrow
        },
        linetoolarrowmarkleft: {
          color: D,
          arrowColor: D,
          fontsize: 14,
          bold: !1,
          italic: !1,
          showLabel: !0
        },
        linetoolarrowmarkup: {
          color: ue,
          arrowColor: ue,
          fontsize: 14,
          bold: !1,
          italic: !1,
          showLabel: !0
        },
        linetoolarrowmarkright: {
          color: D,
          arrowColor: D,
          fontsize: 14,
          bold: !1,
          italic: !1,
          showLabel: !0
        },
        linetoolarrowmarkdown: {
          color: te,
          arrowColor: te,
          fontsize: 14,
          bold: !1,
          italic: !1,
          showLabel: !0
        },
        linetoolflagmark: {
          flagColor: D
        },
        linetoolpricelabel: {
          color: L,
          backgroundColor: D,
          borderColor: D,
          fontWeight: "bold",
          fontsize: 14,
          transparency: 0
        },
        linetoolarrowmarker: {
          backgroundColor: N,
          textColor: N,
          bold: !0,
          italic: !1,
          fontsize: 16
        },
        linetoolrotatedrectangle: {
          color: me,
          fillBackground: !0,
          backgroundColor: ge,
          transparency: 50,
          linewidth: w
        },
        linetoolcircle: {
          color: ye,
          backgroundColor: ve,
          fillBackground: !0,
          linewidth: w,
          textColor: ye,
          fontSize: 14,
          bold: !1,
          italic: !1
        },
        linetoolellipse: {
          color: J,
          fillBackground: !0,
          backgroundColor: ee,
          transparency: 50,
          linewidth: w,
          textColor: J,
          fontSize: 14,
          bold: !1,
          italic: !1
        },
        linetoolarc: {
          color: ae,
          fillBackground: !0,
          backgroundColor: le,
          transparency: 80,
          linewidth: w
        },
        linetoolprediction: {
          linecolor: D,
          linewidth: w,
          sourceBackColor: D,
          sourceTextColor: L,
          sourceStrokeColor: D,
          targetStrokeColor: D,
          targetBackColor: D,
          targetTextColor: L,
          successBackground: me,
          successTextColor: L,
          failureBackground: J,
          failureTextColor: L,
          intermediateBackColor: "#ead289",
          intermediateTextColor: "#6d4d22",
          transparency: 10,
          centersColor: "#202020"
        },
        linetooltriangle: {
          color: ue,
          fillBackground: !0,
          backgroundColor: _e,
          transparency: 80,
          linewidth: w
        },
        linetoolcallout: {
          color: L,
          backgroundColor: q,
          transparency: 50,
          linewidth: w,
          fontsize: 14,
          bordercolor: G,
          bold: !1,
          italic: !1,
          wordWrap: !1,
          wordWrapWidth: 200
        },
        linetoolparallelchannel: {
          linecolor: D,
          linewidth: w,
          linestyle: M,
          extendLeft: !1,
          extendRight: !1,
          fillBackground: !0,
          backgroundColor: R,
          transparency: 20,
          showMidline: !0,
          midlinecolor: D,
          midlinewidth: 1,
          midlinestyle: I,
          labelVisible: !1,
          labelHorzAlign: "left",
          labelVertAlign: "bottom",
          labelTextColor: D,
          labelFontSize: 14,
          labelBold: !1,
          labelItalic: !1
        },
        linetoolelliottimpulse: {
          degree: 7,
          showWave: !0,
          color: "#3d85c6",
          linewidth: w
        },
        linetoolelliotttriangle: {
          degree: 7,
          showWave: !0,
          color: ye,
          linewidth: w
        },
        linetoolelliotttriplecombo: {
          degree: 7,
          showWave: !0,
          color: "#6aa84f",
          linewidth: w
        },
        linetoolelliottcorrection: {
          degree: 7,
          showWave: !0,
          color: "#3d85c6",
          linewidth: w
        },
        linetoolelliottdoublecombo: {
          degree: 7,
          showWave: !0,
          color: "#6aa84f",
          linewidth: w
        },
        linetoolbarspattern: {
          color: D,
          mode: _.Bars,
          mirrored: !1,
          flipped: !1
        },
        linetoolghostfeed: {
          averageHL: 20,
          variance: 50,
          candleStyle: {
            upColor: he,
            downColor: K,
            drawWick: !0,
            drawBorder: !0,
            borderColor: "#378658",
            borderUpColor: ue,
            borderDownColor: J,
            wickColor: Pe
          },
          transparency: 50
        },
        study: {
          inputs: {},
          styles: {},
          bands: {},
          graphics: {},
          ohlcPlots: {},
          palettes: {},
          filledAreasStyle: {},
          filledAreas: {},
          visible: !0,
          showLegendValues: !0,
          showLegendInputs: !0,
          showLabelsOnPriceScale: !0,
          precision: "default"
        },
        linetoolpitchfork: {
          fillBackground: !0,
          transparency: 80,
          style: u.Original,
          median: {
            visible: !0,
            color: J,
            linewidth: w,
            linestyle: M
          },
          extendLines: !1,
          level0: p(.25, fe, !1),
          level1: p(.382, pe, !1),
          level2: p(.5, ue, !0),
          level3: p(.618, ue, !1),
          level4: p(.75, z, !1),
          level5: p(1, D, !0),
          level6: p(1.5, ie, !1),
          level7: p(1.75, ae, !1),
          level8: p(2, Y, !1)
        },
        linetoolpitchfan: {
          fillBackground: !0,
          transparency: 80,
          median: {
            visible: !0,
            color: J,
            linewidth: w,
            linestyle: M
          },
          level0: p(.25, fe, !1),
          level1: p(.382, pe, !1),
          level2: p(.5, z, !0),
          level3: p(.618, ue, !1),
          level4: p(.75, z, !1),
          level5: p(1, D, !0),
          level6: p(1.5, ie, !1),
          level7: p(1.75, ae, !1),
          level8: p(2, Y, !1)
        },
        linetoolgannfan: {
          linewidth: w,
          showLabels: !0,
          fillBackground: !0,
          transparency: 80,
          level1: Ee(1, 8, ye, !0),
          level2: Ee(1, 4, ue, !0),
          level3: Ee(1, 3, me, !0),
          level4: Ee(1, 2, ue, !0),
          level5: Ee(1, 1, z, !0),
          level6: Ee(2, 1, D, !0),
          level7: Ee(3, 1, ie, !0),
          level8: Ee(4, 1, ae, !0),
          level9: Ee(8, 1, J, !0)
        },
        linetoolganncomplex: {
          fillBackground: !1,
          arcsBackground: {
            fillBackground: !0,
            transparency: 80
          },
          reverse: !1,
          scaleRatio: "",
          showLabels: !0,
          labelsStyle: {
            fontSize: 12,
            bold: !1,
            italic: !1
          },
          levels: [A(Pe, !0), A(ye, !0), A(z, !0), A(me, !0), A(ue, !0), A(Pe, !0)],
          fanlines: [ke(O, !1, w, 8, 1), ke(J, !1, w, 5, 1), ke(Pe, !1, w, 4, 1), ke(ye, !1, w, 3, 1), ke(z, !0, w,
            2, 1), ke(me, !0, w, 1, 1), ke(ue, !0, w, 1, 2), ke(ue, !1, w, 1, 3), ke(D, !1, w, 1, 4), ke(F, !1,
            w, 1, 5), ke(O, !1, w, 1, 8)],
          arcs: [ke(ye, !0, w, 1, 0), ke(ye, !0, w, 1, 1), ke(ye, !0, w, 1.5, 0), ke(z, !0, w, 2, 0), ke(z, !0, w,
            2, 1), ke(me, !0, w, 3, 0), ke(me, !0, w, 3, 1), ke(ue, !0, w, 4, 0), ke(ue, !0, w, 4, 1), ke(D, !0,
            w, 5, 0), ke(D, !0, w, 5, 1)]
        },
        linetoolgannfixed: {
          fillBackground: !1,
          arcsBackground: {
            fillBackground: !0,
            transparency: 80
          },
          reverse: !1,
          levels: [A(Pe, !0), A(ye, !0), A(z, !0), A(me, !0), A(ue, !0), A(Pe, !0)],
          fanlines: [ke(O, !1, w, 8, 1), ke(J, !1, w, 5, 1), ke(Pe, !1, w, 4, 1), ke(ye, !1, w, 3, 1), ke(z, !0, w,
            2, 1), ke(me, !0, w, 1, 1), ke(ue, !0, w, 1, 2), ke(ue, !1, w, 1, 3), ke(D, !1, w, 1, 4), ke(F, !1,
            w, 1, 5), ke(O, !1, w, 1, 8)],
          arcs: [ke(ye, !0, w, 1, 0), ke(ye, !0, w, 1, 1), ke(ye, !0, w, 1.5, 0), ke(z, !0, w, 2, 0), ke(z, !0, w,
            2, 1), ke(me, !0, w, 3, 0), ke(me, !0, w, 3, 1), ke(ue, !0, w, 4, 0), ke(ue, !0, w, 4, 1), ke(D, !0,
            w, 5, 0), ke(D, !0, w, 5, 1)]
        },
        linetoolgannsquare: {
          color: "rgba(21, 56, 153, 0.8)",
          linewidth: w,
          linestyle: M,
          showTopLabels: !0,
          showBottomLabels: !0,
          showLeftLabels: !0,
          showRightLabels: !0,
          fillHorzBackground: !0,
          horzTransparency: 80,
          fillVertBackground: !0,
          vertTransparency: 80,
          reverse: !1,
          fans: t(Ce, !1),
          hlevel1: i(0, Pe, !0),
          hlevel2: i(.25, ye, !0),
          hlevel3: i(.382, z, !0),
          hlevel4: i(.5, me, !0),
          hlevel5: i(.618, ue, !0),
          hlevel6: i(.75, D, !0),
          hlevel7: i(1, Pe, !0),
          vlevel1: i(0, Pe, !0),
          vlevel2: i(.25, ye, !0),
          vlevel3: i(.382, z, !0),
          vlevel4: i(.5, me, !0),
          vlevel5: i(.618, ue, !0),
          vlevel6: i(.75, D, !0),
          vlevel7: i(1, Pe, !0)
        },
        linetoolfibspeedresistancefan: {
          fillBackground: !0,
          transparency: 80,
          grid: {
            color: "rgba(21, 56, 153, 0.8)",
            linewidth: 1,
            linestyle: M,
            visible: !0
          },
          linewidth: w,
          linestyle: M,
          showTopLabels: !0,
          showBottomLabels: !0,
          showLeftLabels: !0,
          showRightLabels: !0,
          reverse: !1,
          hlevel1: i(0, Pe, !0),
          hlevel2: i(.25, ye, !0),
          hlevel3: i(.382, z, !0),
          hlevel4: i(.5, me, !0),
          hlevel5: i(.618, ue, !0),
          hlevel6: i(.75, D, !0),
          hlevel7: i(1, Pe, !0),
          vlevel1: i(0, Pe, !0),
          vlevel2: i(.25, ye, !0),
          vlevel3: i(.382, z, !0),
          vlevel4: i(.5, me, !0),
          vlevel5: i(.618, ue, !0),
          vlevel6: i(.75, D, !0),
          vlevel7: i(1, Pe, !0)
        },
        linetoolfibretracement: {
          showCoeffs: !0,
          showPrices: !0,
          fillBackground: !0,
          transparency: 80,
          extendLines: !1,
          extendLinesLeft: !1,
          horzLabelsAlign: "left",
          vertLabelsAlign: "middle",
          showText: !0,
          horzTextAlign: "center",
          vertTextAlign: "middle",
          reverse: !1,
          coeffsAsPercents: !1,
          fibLevelsBasedOnLogScale: !1,
          labelFontSize: 12,
          trendline: {
            visible: !0,
            color: Pe,
            linewidth: w,
            linestyle: I
          },
          levelsStyle: {
            linewidth: w,
            linestyle: M
          },
          level1: i(0, Pe, !0, !0),
          level2: i(.236, J, !0, !0),
          level3: i(.382, ye, !0, !0),
          level4: i(.5, me, !0, !0),
          level5: i(.618, ue, !0, !0),
          level6: i(.786, z, !0, !0),
          level7: i(1, Pe, !0, !0),
          level8: i(1.618, D, !0, !0),
          level9: i(2.618, J, !0, !0),
          level10: i(3.618, ie, !0, !0),
          level11: i(4.236, ae, !0, !0),
          level12: i(1.272, ye, !1, !0),
          level13: i(1.414, J, !1, !0),
          level16: i(2, ue, !1, !0),
          level14: i(2.272, ye, !1, !0),
          level15: i(2.414, me, !1, !0),
          level17: i(3, z, !1, !0),
          level18: i(3.272, Pe, !1, !0),
          level19: i(3.414, D, !1, !0),
          level20: i(4, J, !1, !0),
          level21: i(4.272, ie, !1, !0),
          level22: i(4.414, ae, !1, !0),
          level23: i(4.618, ye, !1, !0),
          level24: i(4.764, ue, !1, !0)
        },
        linetoolfibchannel: {
          showCoeffs: !0,
          showPrices: !0,
          fillBackground: !0,
          transparency: 80,
          extendLeft: !1,
          extendRight: !1,
          horzLabelsAlign: "left",
          vertLabelsAlign: "middle",
          coeffsAsPercents: !1,
          labelFontSize: 12,
          levelsStyle: {
            linewidth: w,
            linestyle: M
          },
          level1: i(0, Pe, !0),
          level2: i(.236, J, !0),
          level3: i(.382, ye, !0),
          level4: i(.5, me, !0),
          level5: i(.618, ue, !0),
          level6: i(.786, z, !0),
          level7: i(1, Pe, !0),
          level8: i(1.618, D, !0),
          level9: i(2.618, J, !0),
          level10: i(3.618, ie, !0),
          level11: i(4.236, ae, !0),
          level12: i(1.272, ye, !1),
          level13: i(1.414, J, !1),
          level16: i(2, ue, !1),
          level14: i(2.272, ye, !1),
          level15: i(2.414, me, !1),
          level17: i(3, z, !1),
          level18: i(3.272, Pe, !1),
          level19: i(3.414, D, !1),
          level20: i(4, J, !1),
          level21: i(4.272, ie, !1),
          level22: i(4.414, ae, !1),
          level23: i(4.618, ye, !1),
          level24: i(4.764, ue, !1)
        },
        linetoolprojection: {
          showCoeffs: !0,
          fillBackground: !0,
          transparency: 80,
          color1: R,
          color2: oe,
          linewidth: w,
          trendline: {
            visible: !0,
            color: Ce,
            linestyle: M
          },
          level1: p(1, "#808080", !0)
        },
        linetool5pointspattern: {
          color: D,
          textcolor: L,
          fillBackground: !0,
          backgroundColor: D,
          fontsize: 12,
          bold: !1,
          italic: !1,
          transparency: 85,
          linewidth: w
        },
        linetoolcypherpattern: {
          color: D,
          textcolor: L,
          fillBackground: !0,
          backgroundColor: D,
          fontsize: 12,
          bold: !1,
          italic: !1,
          transparency: 85,
          linewidth: w
        },
        linetooltrianglepattern: {
          color: W,
          textcolor: L,
          fillBackground: !0,
          backgroundColor: W,
          fontsize: 12,
          bold: !1,
          italic: !1,
          transparency: 85,
          linewidth: w
        },
        linetoolabcd: {
          color: ue,
          textcolor: L,
          fontsize: 12,
          bold: !1,
          italic: !1,
          linewidth: w
        },
        linetoolthreedrivers: {
          color: W,
          textcolor: L,
          fillBackground: !0,
          backgroundColor: "rgba(149, 40, 204, 0.5)",
          fontsize: 12,
          bold: !1,
          italic: !1,
          transparency: 50,
          linewidth: w
        },
        linetoolheadandshoulders: {
          color: ue,
          textcolor: L,
          fillBackground: !0,
          backgroundColor: ue,
          fontsize: 12,
          bold: !1,
          italic: !1,
          transparency: 85,
          linewidth: w
        },
        linetoolfibwedge: {
          showCoeffs: !0,
          fillBackground: !0,
          transparency: 80,
          trendline: {
            visible: !0,
            color: "#808080",
            linewidth: w,
            linestyle: M
          },
          level1: p(.236, J, !0),
          level2: p(.382, ye, !0),
          level3: p(.5, me, !0),
          level4: p(.618, ue, !0),
          level5: p(.786, z, !0),
          level6: p(1, Pe, !0),
          level7: p(1.618, D, !1),
          level8: p(2.618, J, !1),
          level9: p(3.618, W, !1),
          level10: p(4.236, ae, !1),
          level11: p(4.618, ae, !1)
        },
        linetoolfibcircles: {
          showCoeffs: !0,
          fillBackground: !0,
          transparency: 80,
          coeffsAsPercents: !1,
          trendline: {
            visible: !0,
            color: Pe,
            linewidth: w,
            linestyle: I
          },
          level1: p(.236, J, !0),
          level2: p(.382, ye, !0),
          level3: p(.5, ue, !0),
          level4: p(.618, me, !0),
          level5: p(.786, z, !0),
          level6: p(1, Pe, !0),
          level7: p(1.618, D, !0),
          level8: p(2.618, ae, !0),
          level9: p(3.618, D, !0),
          level10: p(4.236, ae, !0),
          level11: p(4.618, J, !0)
        },
        linetoolfibspeedresistancearcs: {
          showCoeffs: !0,
          fillBackground: !0,
          transparency: 80,
          fullCircles: !1,
          trendline: {
            visible: !0,
            color: Pe,
            linewidth: w,
            linestyle: I
          },
          level1: p(.236, J, !0),
          level2: p(.382, ye, !0),
          level3: p(.5, ue, !0),
          level4: p(.618, me, !0),
          level5: p(.786, z, !0),
          level6: p(1, Pe, !0),
          level7: p(1.618, D, !0),
          level8: p(2.618, ae, !0),
          level9: p(3.618, D, !0),
          level10: p(4.236, ae, !0),
          level11: p(4.618, J, !0)
        },
        linetooltrendbasedfibextension: {
          showCoeffs: !0,
          showPrices: !0,
          fillBackground: !0,
          transparency: 80,
          extendLines: !1,
          extendLinesLeft: !1,
          horzLabelsAlign: "left",
          vertLabelsAlign: "middle",
          showText: !0,
          horzTextAlign: "center",
          vertTextAlign: "middle",
          reverse: !1,
          coeffsAsPercents: !1,
          fibLevelsBasedOnLogScale: !1,
          labelFontSize: 12,
          trendline: {
            visible: !0,
            color: Pe,
            linewidth: w,
            linestyle: I
          },
          levelsStyle: {
            linewidth: w,
            linestyle: M
          },
          level1: i(0, Pe, !0, !0),
          level2: i(.236, J, !0, !0),
          level3: i(.382, ye, !0, !0),
          level4: i(.5, me, !0, !0),
          level5: i(.618, ue, !0, !0),
          level6: i(.786, z, !0, !0),
          level7: i(1, Pe, !0, !0),
          level8: i(1.618, D, !0, !0),
          level9: i(2.618, J, !0, !0),
          level10: i(3.618, ie, !0, !0),
          level11: i(4.236, ae, !0, !0),
          level12: i(1.272, ye, !1, !0),
          level13: i(1.414, J, !1, !0),
          level16: i(2, ue, !1, !0),
          level14: i(2.272, ye, !1, !0),
          level15: i(2.414, me, !1, !0),
          level17: i(3, z, !1, !0),
          level18: i(3.272, Pe, !1, !0),
          level19: i(3.414, D, !1, !0),
          level20: i(4, J, !1, !0),
          level21: i(4.272, ie, !1, !0),
          level22: i(4.414, ae, !1, !0),
          level23: i(4.618, ye, !1, !0),
          level24: i(4.764, ue, !1, !0)
        },
        linetooltrendbasedfibtime: {
          showCoeffs: !0,
          fillBackground: !0,
          transparency: 80,
          horzLabelsAlign: "right",
          vertLabelsAlign: "bottom",
          trendline: {
            visible: !0,
            color: Pe,
            linewidth: w,
            linestyle: I
          },
          level1: p(0, Pe, !0),
          level2: p(.382, J, !0),
          level3: p(.5, pe, !1),
          level4: p(.618, me, !0),
          level5: p(1, ue, !0),
          level6: p(1.382, z, !0),
          level7: p(1.618, Pe, !0),
          level8: p(2, D, !0),
          level9: p(2.382, ae, !0),
          level10: p(2.618, ie, !0),
          level11: p(3, W, !0)
        },
        linetoolschiffpitchfork: {
          fillBackground: !0,
          transparency: 80,
          style: u.Schiff,
          median: {
            visible: !0,
            color: J,
            linewidth: w,
            linestyle: M
          },
          extendLines: !1,
          level0: p(.25, fe, !1),
          level1: p(.382, pe, !1),
          level2: p(.5, ue, !0),
          level3: p(.618, ue, !1),
          level4: p(.75, z, !1),
          level5: p(1, D, !0),
          level6: p(1.5, ie, !1),
          level7: p(1.75, ae, !1),
          level8: p(2, Y, !1)
        },
        linetoolschiffpitchfork2: {
          fillBackground: !0,
          transparency: 80,
          style: u.Schiff2,
          median: {
            visible: !0,
            color: J,
            linewidth: w,
            linestyle: M
          },
          extendLines: !1,
          level0: p(.25, fe, !1),
          level1: p(.382, pe, !1),
          level2: p(.5, ue, !0),
          level3: p(.618, ue, !1),
          level4: p(.75, z, !1),
          level5: p(1, D, !0),
          level6: p(1.5, ie, !1),
          level7: p(1.75, ae, !1),
          level8: p(2, Y, !1)
        },
        linetoolinsidepitchfork: {
          fillBackground: !0,
          transparency: 80,
          style: u.Inside,
          median: {
            visible: !0,
            color: J,
            linewidth: w,
            linestyle: M
          },
          extendLines: !1,
          level0: p(.25, fe, !1),
          level1: p(.382, pe, !1),
          level2: p(.5, ue, !0),
          level3: p(.618, ue, !1),
          level4: p(.75, z, !1),
          level5: p(1, D, !0),
          level6: p(1.5, ie, !1),
          level7: p(1.75, ae, !1),
          level8: p(2, Y, !1)
        },
        linetoolregressiontrend: {
          linewidth: 1,
          linestyle: M,
          styles: {
            upLine: {
              display: g.All,
              color: B,
              linestyle: M,
              linewidth: w
            },
            downLine: {
              display: g.All,
              color: B,
              linestyle: M,
              linewidth: w
            },
            baseLine: {
              display: g.All,
              color: Q,
              linestyle: I,
              linewidth: 1
            },
            extendLines: !1,
            showPearsons: !0,
            transparency: 70
          }
        }
      }, De(TradingView.defaultProperties.chartproperties), Ve()
    }
    if (void 0 === TradingView.defaultProperties["study_MA@tv-basicstudies"] && (TradingView.defaultProperties[
        "study_MA@tv-basicstudies"] = {
        description: "Moving Average",
        shortDescription: "MA",
        inputs: {
          length: 9,
          source: "close"
        },
        styles: {
          MovAvg: {
            display: g.All,
            color: D,
            linestyle: M,
            linewidth: 1,
            plottype: m.Line,
            histogramBase: 0,
            title: "MA"
          }
        }
      }), void 0 === TradingView.defaultProperties["study_PivotPointsHighLow@tv-basicstudies"] && (TradingView
        .defaultProperties["study_PivotPointsHighLow@tv-basicstudies"] = {
          fontsize: 10,
          borderColor: D,
          backColor: E,
          textColor: Me
        }), void 0 === TradingView.defaultProperties["study_PivotPointsStandard@tv-basicstudies"]) {
      var Re = !0;
      TradingView.defaultProperties["study_PivotPointsStandard@tv-basicstudies"] = {
        _hardCodedDefaultsVersion: 1,
        fontsize: 11,
        levelsStyle: {
          showLabels: !0,
          visibility: {
            P: Re,
            "S1/R1": Re,
            "S2/R2": Re,
            "S3/R3": Re,
            "S4/R4": Re,
            "S5/R5": Re
          },
          colors: {
            P: Se,
            "S1/R1": Se,
            "S2/R2": Se,
            "S3/R3": Se,
            "S4/R4": Se,
            "S5/R5": Se
          },
          widths: {
            P: 1,
            "S1/R1": 1,
            "S2/R2": 1,
            "S3/R3": 1,
            "S4/R4": 1,
            "S5/R5": 1
          }
        }
      }
    }
    void 0 === TradingView.defaultProperties["study_ZigZag@tv-basicstudies"] && (TradingView.defaultProperties[
      "study_ZigZag@tv-basicstudies"] = {
      color: D,
      linewidth: 2
    });
    const Ne = {
      styles: {
        splitByBlocks: !1
      },
      graphics: {
        tpoLevels: {
          tpo: {
            tpoPoc: {
              color: ""
            },
            tpoPoorHigh: {
              color: ""
            },
            tpoPoorLow: {
              color: ""
            },
            tpoSingleprints: {
              color: ""
            },
            tpoVah: {
              color: ""
            },
            tpoVal: {
              color: ""
            },
            volumePoc: {
              color: ""
            },
            volumeVah: {
              color: ""
            },
            volumeVal: {
              color: ""
            }
          }
        },
        tpoVolumeRows: {
          tpo: {
            valuesColor: "",
            colors: {
              nonVa: "",
              va: ""
            }
          }
        }
      }
    };

    function Oe(e) {
      const t = {
        styles: {
          developingPoc: {
            color: ""
          },
          developingVAHigh: {
            color: ""
          },
          developingVALow: {
            color: ""
          }
        },
        graphics: {
          horizlines: {
            pocLines: {
              color: ""
            },
            vahLines: {
              color: ""
            },
            valLines: {
              color: ""
            }
          },
          hhists: {
            histBars2: {
              colors: ["", ""],
              valuesColor: ""
            },
            histBarsVA: {
              colors: ["", ""],
              valuesColor: ""
            }
          }
        }
      };
      return e && (t.graphics.polygons = {
        histBoxBg: {
          color: ""
        }
      }), t
    }
    void 0 === TradingView.defaultProperties["study_TPOPeriodic@tv-volumebyprice"] && (TradingView.defaultProperties[
      "study_TPOPeriodic@tv-volumebyprice"] = Ne), void 0 === TradingView.defaultProperties[
      "study_TPOSessions@tv-volumebyprice"] && (TradingView.defaultProperties[
      "study_TPOSessions@tv-volumebyprice"] = Ne), void 0 === TradingView.defaultProperties[
      "study_VbPSessions@tv-volumebyprice"] && (TradingView.defaultProperties[
      "study_VbPSessions@tv-volumebyprice"] = Oe(!0)), void 0 === TradingView.defaultProperties[
      "study_VbPSessionsRoughDetailed@tv-volumebyprice"] && (TradingView.defaultProperties[
      "study_VbPSessionsRoughDetailed@tv-volumebyprice"] = Oe(!0)), void 0 === TradingView.defaultProperties[
      "study_VbPPeriodic@tv-volumebyprice"] && (TradingView.defaultProperties[
      "study_VbPPeriodic@tv-volumebyprice"] = Oe(!0)), void 0 === TradingView.defaultProperties[
      "study_VbPVisible@tv-volumebyprice"] && (TradingView.defaultProperties["study_VbPVisible@tv-volumebyprice"] =
      Oe(!1));
    const Fe = {
      styles: {
        developingPoc: {
          color: ""
        },
        developingVAHigh: {
          color: ""
        },
        developingVALow: {
          color: ""
        }
      },
      graphics: {
        hhists: {
          histBars2: {
            colors: ["", ""],
            valuesColor: ""
          },
          histBarsVA: {
            colors: ["", ""],
            valuesColor: ""
          }
        },
        horizlines: {
          pocLines: {
            color: ""
          },
          vahLines: {
            color: ""
          },
          valLines: {
            color: ""
          }
        },
        polygons: {
          histBoxBg: {
            color: ""
          }
        }
      }
    };
    if (void 0 === TradingView.defaultProperties["study_VbPFixed@tv-volumebyprice"] && (TradingView.defaultProperties[
        "study_VbPFixed@tv-volumebyprice"] = Fe), void 0 === TradingView.defaultProperties[
        "study_VbPFixed@tv-basicstudies"] && (TradingView.defaultProperties["study_VbPFixed@tv-basicstudies"] = Fe),
      void 0 === TradingView.defaultProperties.linetoolanchoredvp && (TradingView.defaultProperties
        .linetoolanchoredvp = Oe(!0)),
      void 0 === TradingView.defaultProperties["study_VbPAutoAnchored@tv-volumebyprice"] && (TradingView
        .defaultProperties["study_VbPAutoAnchored@tv-volumebyprice"] = Oe(!0)), void 0 === TradingView
      .defaultProperties["study_ElliottWave@tv-basicstudies"] && (TradingView.defaultProperties[
        "study_ElliottWave@tv-basicstudies"] = {
        inputs: {},
        level0: t($, !1),
        level1: t("#008000", !1),
        level2: t("#0000ff", !1),
        level3: t("#ff00ff", !1),
        level4: t("#0080ff", !0),
        level5: t($, !0),
        level6: t("#008000", !0),
        level7: t("#0000ff", !0),
        level8: t("#ff00ff", !0)
      }), void 0 === TradingView.defaultProperties["study_LinearRegression@tv-basicstudies"] && (TradingView
        .defaultProperties["study_LinearRegression@tv-basicstudies"] = {
          styles: {
            upLine: {
              display: g.All,
              color: B,
              linestyle: M,
              linewidth: 1
            },
            downLine: {
              display: g.All,
              color: B,
              linestyle: M,
              linewidth: 1
            },
            baseLine: {
              display: g.All,
              color: Q,
              linestyle: M,
              linewidth: 1
            },
            extendLines: !0,
            showPearsons: !0,
            backgroundColor: "rgba(153, 21, 21, 0.3)",
            transparency: 70
          }
        }), void 0 === TradingView.defaultProperties["study_Compare@tv-basicstudies"] && (TradingView
        .defaultProperties["study_Compare@tv-basicstudies"] = {
          minTick: "default"
        }), void 0 === TradingView.defaultProperties["study_Overlay@tv-basicstudies"]) {
      TradingView.defaultProperties["study_Overlay@tv-basicstudies"] = {
        style: d.STYLE_LINE,
        allowExtendTimeScale: !1,
        showPriceLine: !1,
        minTick: "default",
        candleStyle: {
          upColor: de,
          downColor: re,
          drawWick: !0,
          drawBorder: !0,
          drawBody: !0,
          borderColor: "#378658",
          borderUpColor: de,
          borderDownColor: re,
          wickColor: "#737375",
          wickUpColor: de,
          wickDownColor: re,
          barColorsOnPrevClose: !1
        },
        hollowCandleStyle: {
          upColor: de,
          downColor: re,
          drawWick: !0,
          drawBorder: !0,
          drawBody: !0,
          borderColor: "#378658",
          borderUpColor: de,
          borderDownColor: re,
          wickColor: "#737375",
          wickUpColor: de,
          wickDownColor: re,
          barColorsOnPrevClose: !1
        },
        barStyle: {
          upColor: de,
          downColor: re,
          barColorsOnPrevClose: !1,
          dontDrawOpen: !1,
          thinBars: !0
        },
        lineStyle: {
          color: be,
          linestyle: M,
          linewidth: 2,
          priceSource: "close"
        },
        lineWithMarkersStyle: {
          color: be,
          linestyle: M,
          linewidth: 2,
          priceSource: "close"
        },
        steplineStyle: {
          color: be,
          linestyle: M,
          linewidth: 2,
          priceSource: "close"
        },
        areaStyle: {
          color1: D,
          color2: D,
          linecolor: D,
          linestyle: M,
          linewidth: 2,
          priceSource: "close",
          transparency: 95
        },
        baselineStyle: {
          baselineColor: Te,
          topFillColor1: Le,
          topFillColor2: Le,
          bottomFillColor1: X,
          bottomFillColor2: X,
          topLineColor: Ae,
          bottomLineColor: Z,
          topLineWidth: 2,
          bottomLineWidth: 2,
          topLineStyle: 0,
          bottomLineStyle: 2,
          priceSource: "close",
          transparency: 50,
          baseLevelPercentage: 50
        },
        hiloStyle: {
          color: D,
          showBorders: !0,
          borderColor: D,
          showLabels: !0,
          labelColor: D,
          drawBody: !0
        },
        columnStyle: {
          upColor: r(ue, 50),
          downColor: r(J, 50),
          barColorsOnPrevClose: !0,
          priceSource: "close",
          baselinePosition: "bottom"
        },
        hlcAreaStyle: {
          highLineVisible: !0,
          highLineColor: z,
          highLineStyle: M,
          highLineWidth: 2,
          lowLineVisible: !0,
          lowLineColor: ae,
          lowLineStyle: M,
          lowLineWidth: 2,
          closeLineColor: D,
          closeLineStyle: M,
          closeLineWidth: 2,
          highCloseFillColor: j,
          closeLowFillColor: ce
        },
        hlcBarsStyle: {
          color: D,
          barColorsOnPrevClose: !1,
          thinBars: !0
        },
        styles: {
          open: {
            display: g.All,
            color: $,
            linestyle: M,
            linewidth: 1,
            plottype: m.Line,
            histogramBase: 0
          },
          high: {
            display: g.All,
            color: $,
            linestyle: M,
            linewidth: 1,
            plottype: m.Line,
            histogramBase: 0
          },
          low: {
            display: g.All,
            color: $,
            linestyle: M,
            linewidth: 1,
            plottype: m.Line,
            histogramBase: 0
          },
          close: {
            display: g.All,
            color: $,
            linestyle: M,
            linewidth: 1,
            plottype: m.Line,
            histogramBase: 0
          }
        }
      }
    }
    for (var We = e.split("."), He = TradingView.defaultProperties, ze = 0; ze < We.length; ze++) He && (He = He[We[
      ze]]);
    return null != He ? s(He) : {}
  };

  function Ee(e, t, i, s, o) {
    if (s)
      for (var n in s) {
        var r = n.split("."),
          a = c(r[0]),
          l = void 0 !== o && o === r[0];
        0 !== r.length && l && (a = c((r = r.slice(1))[0])), 0 !== r.length && e.hasOwnProperty(a) ? h(e, r, s[n]) || d(
          n) : l && d(n)
      }

    function c(e) {
      return t && t[e] ? t[e] : e
    }

    function h(e, t, i, s) {
      var o = c(t[0]);
      return !!e.hasOwnProperty(o) && (t.length > 1 ? h(e[o], t.slice(1), i) : (e[o] && e[o].setValue ? e[o].setValue(
        i) : e[o] = i, !0))
    }

    function d(e) {
      i || A.logWarn("Path `" + e + "` does not exist.")
    }
  }

  function De(e, t, i, s) {
    window.__defaultsOverrides && Ee(e, t, i, window.__defaultsOverrides, s)
  }

  function Be(e, t) {
    window.__settingsOverrides && Ee(e, null, !1, window.__settingsOverrides, t)
  }

  function Ve() {
    var e = /^linetool.+/;
    Object.keys(TradingView.defaultProperties)
      .forEach((function(t) {
        e.test(t) && De(TradingView.defaultProperties[t], null, !1, t)
      }))
  }

  function Re(e, t) {
    return t ? function(e, t) {
      var i = ke(e);
      if (!window._UNIT_TESTS) {
        var n = s(TVSettings.getJSON(e, null));
        if (function(e) {
            var t = new Set(["linetoolregressiontrend"]);
            return e.startsWith("study_") || t.has(e)
          }(e) && n && function(e) {
            if (!e) return !1;
            e = e.toString();
            var t = new RegExp("\\d+")
              .exec(e),
              i = null !== t && t[0] === e;
            return i
          }(n.version)) {
          var r = n.inputs,
            a = t.updateStudyInputs(n.id, n.version, "last", r, null);
          n.inputs = a, n = t.updateStudyState(n, n)
        }
        o(i, n), Be(i, e)
      }
      return i
    }(e, t) : function(e) {
      var t = ke(e);
      if (!window._UNIT_TESTS) {
        var i = s(TVSettings.getJSON(e, null));
        if (i) {
          o(t, i);
          const s = e.split(".");
          Be(t, void 0 === s[1] ? e : s[1])
        }
      }
      return t
    }(e)
  }
  Re.create = function(e, t) {
      if (t) {
        var i = ke(e);
        TradingView.defaultProperties[e] = o(t, i)
      }
    }, Re.remove = function(e) {
      TradingView.defaultProperties[e] = void 0
    }, TradingView.saveDefaults = function(e, t) {
      void 0 === t ? TVSettings.remove(e) : TVSettings.setJSON(e, t)
    }, TradingView.factoryDefaults = ke, window.applyDefaultOverridesToLinetools = Ve, window.applyDefaultsOverrides =
    De, window.applyPropertiesOverrides = Ee, window.defaults = Re, t.applyDefaultOverridesToLinetools = Ve, t
    .applyDefaultsOverrides = De, t.applyPropertiesOverrides = Ee, t.defaults = Re, t.factoryDefaults = ke, t
    .saveDefaults = TradingView.saveDefaults, t.createDefaults = Re.create, t.removeDefaults = Re.remove
