// Module 51101
// Original file: 51101.js
// Size: 17.7 KB
// Purpose: Auto-extracted webpack module from TradingView library

(e, t, i) => {
  "use strict";
  i.r(t), i.d(t, {
    SessionInfo: () => r.SessionInfo,
    alignExchangeTimeToSessionStartAndReturnUTC: () => E,
    alignPeriodsBackForDataRequest: () => I,
    alignPeriodsBackForVisibleRange: () => A,
    getPeriodsBetweenDates: () => k,
    isTradingNow: () => D,
    newBarBuilder: () => M
  });
  var s = i(37236),
    o = i(10892),
    n = i(77914),
    r = i(47312),
    a = i(51829);
  class l extends r.BarBuilderBase {
    constructor(e, t) {
      super(), this._sessionStartMs = -Number.MAX_VALUE, this._sessionEndMs = -Number.MAX_VALUE, this._periodSec =
        e, this._session = t
    }
    alignTimeIfPossible(e) {
      const t = this.alignTime(e);
      return isNaN(t) ? e : t
    }
    indexOfBar(e) {
      return e < this._sessionStartMs ? a.SessionStage.PRE_SESSION : e >= this._sessionEndMs ? a.SessionStage
        .POST_SESSION : (0, n.toInt)((0, s.time_seconds_diff)(e, this._sessionStartMs) / this._periodSec)
    }
    startOfBar(e) {
      if (e === a.SessionStage.PRE_SESSION) {
        const e = (0, s.get_cal_from_unix_timestamp_ms)(this._session.timezone, this._sessionStartMs - 1),
          t = this._session.spec.alignToNearestSessionEnd(e, -1);
        return (0, s.cal_to_utc)(this._session.timezone, t)
      }
      if (e === a.SessionStage.POST_SESSION) return this._sessionEndMs;
      if (e < 0) throw new Error("Negative offset is not supported");
      return this._sessionStartMs + (0, s.time_seconds)(this._periodSec * e)
    }
    endOfBar(e) {
      if (e < 0) throw new Error("Index cannot be negative");
      const t = this.startOfBar(e) + 1e3 * this._periodSec;
      return t > this._sessionEndMs ? this._sessionEndMs : t
    }
    isLastBar(e, t) {
      return t >= this._sessionStartMs + (0, s.time_seconds)(this._periodSec * (e + 1) - 1)
    }
    moveTo(e) {
      const t = this._session.timezone,
        i = (0, s.utc_to_cal)(t, e),
        o = this._session.spec.alignToSessionStart(i);
      this._sessionStartMs = (0, s.cal_to_utc)(t, i), (0, s.add_minutes)(i, o), this._sessionEndMs = (0, s
        .cal_to_utc)(t, i)
    }
    indexOfLastBarInSession() {
      return (0, n.toInt)((this._sessionEndMs - 1 - this._sessionStartMs) / 1e3 / this._periodSec)
    }
    moveNext() {
      this.moveTo(this._sessionEndMs)
    }
    static minutes(e, t) {
      return new l(60 * e, t)
    }
    static seconds(e, t) {
      return new l(e, t)
    }
  }
  var c = i(50151),
    h = i(71149);
  const d = (0,
    s.get_timezone)("Etc/UTC");

  function u(e, t, i) {
    const o = (0, s.clone)(t),
      n = e.businessDaysToCalendarDays(o, 1);
    n > 1 && (0, s.add_date)(o, n - 1);
    const r = e.leftBorderOfDailyBar(o);
    if (null === r) throw new Error("Cannot calculate left border of daily bar");
    return (0, s.cal_to_utc)(i, r, !0)
  }
  class _ {
    constructor(e, t) {
      this.from = e, this.to = t
    }
    toString() {
      return `${this.from.toString()} - ${this.to.toString()}`
    }
  }
  class p extends r.BarBuilderBase {
    constructor(e, t, i, s, o = !1) {
      super(), this._periodStart = -Number.MAX_VALUE, this._periodEnd = -Number.MAX_VALUE, this
        ._periodLastBarStart = -Number.MAX_VALUE, this._periodStartDay = new h.BusinessDay(0, 0, 0), this
        ._periodEndDay = new h.BusinessDay(0, 0, 0), this._period = i, this._sessionTgt = e, this._builder = s, this
        ._useBusinessDays = o, o ? ((0, c.assert)(null === t,
            "useBusinessDays and sessionSrc are mutually exclusive arguments"), this._sessionSrc = new r
          .SessionInfo("Etc/UTC", "24x7")) : this._sessionSrc = t || e
    }
    builder() {
      return this._builder
    }
    alignTimeIfPossible(e) {
      return this.tradingDayToSessionStart(e)
    }
    tradingDayToSessionStart(e) {
      return this.moveTo(e), this.startOfBar(0)
    }
    indexOfBar(e) {
      if (this._useBusinessDays) {
        const t = h.BusinessDay.fromCalendar((0, s.get_cal_from_unix_timestamp_ms)(this._sessionSrc.timezone, e));
        return t.before(this._periodStartDay) ? a.SessionStage.PRE_SESSION : this._periodEndDay.before(t) ? a
          .SessionStage.POST_SESSION : 0
      }
      return e < this._periodStart ? a.SessionStage.PRE_SESSION : e >= this._periodEnd ? a.SessionStage
        .POST_SESSION : 0
    }
    startOfBar(e) {
      if (e === a.SessionStage.PRE_SESSION) {
        const e = (0, s.get_cal_from_unix_timestamp_ms)(this._sessionTgt.timezone, this._periodStart - 1),
          t = this._sessionTgt.spec.alignToNearestSessionEnd(e, -1);
        return (0, s.cal_to_utc)(this._sessionTgt.timezone, t) - 1
      }
      return e === a.SessionStage.POST_SESSION || e > 0 ? this._periodEnd : e === a.SessionStage.LASTBAR_SESSION ?
        this._periodLastBarStart : this._periodStart
    }
    moveTo(e) {
      let t = (0, s.get_cal_from_unix_timestamp_ms)(this._sessionSrc.timezone, e);
      t = this._sessionSrc.spec.correctTradingDay(t);
      const i = (0, s.get_year)(t),
        o = this._indexOfPeriodInYear(t),
        n = o + this._period,
        r = this._sessionTgt.spec,
        a = this._sessionTgt.timezone,
        l = this._builder.startOfPeriod(o, i);
      this._periodStart = u(r, l, a);
      const c = r.businessDaysToCalendarDays(l, 1);
      c > 1 && (0, s.add_date)(l, c - 1), this._periodStartDay = h.BusinessDay.fromCalendar(l);
      let d = this._builder.startOfPeriod(n, i);
      this._periodEnd = u(r, d, a);
      const _ = (0, s.clone)(d);
      for ((0, s.add_date)(_, -1); r.isCalWeekEnd(_);)(0, s.add_date)(_, -1);
      this._periodEndDay = h.BusinessDay.fromCalendar(_), (0, s.add_date)(d, -1), d = function(e, t) {
        const i = (0, s.clone)(t);
        for (; e.isCalWeekEnd(i);)(0, s.add_date)(i, -1);
        return i
      }(this._sessionTgt.spec, d), this._periodLastBarStart = u(r, d, a), (this._periodLastBarStart < this
        ._periodStart || this._periodLastBarStart === this._periodEnd) && (this._periodLastBarStart = this
        ._periodStart)
    }
    endOfBar(e) {
      return e === a.SessionStage.LAST_SESSION_END ? this._getZonedDateTimeOfBorder(a.SessionStage.LAST_SESSION_END)
        .getTime() + 1e3 : ((0, c.assert)(0 === e), this._periodEnd)
    }
    isLastBar(e, t) {
      if (0 !== e) throw new Error("index should be 0");
      return t >= this._periodLastBarStart
    }
    moveBarsForward(e, t) {
      (0, c.assert)(t > 0);
      const i = (0, s.get_cal_from_unix_timestamp_ms)(this._sessionTgt.timezone, e);
      let o = this._sessionTgt.spec.correctTradingDay(i);
      for (let e = 0; e < t; e++) {
        const e = this._period + this._builder.indexOfPeriod(o);
        o = this._builder.startOfPeriod(e, (0, s.get_year)(o)), o = this._sessionTgt.spec.correctTradingDay(o)
      }
      return this.moveTo((0, s.cal_to_utc)(this._sessionTgt.timezone, o)), this.startOfBar(0)
    }
    currentRange() {
      return new _(this._periodStartDay, this._periodEndDay)
    }
    indexOfBarInYear(e) {
      const t = (0, s.get_cal_from_unix_timestamp_ms)(this._sessionSrc.timezone, e),
        i = (0, s.get_year)(t),
        o = this._builder.indexOfPeriod(t),
        r = this._sessionTgt.timezone;
      let a = this._builder.startOfPeriod(o, i),
        l = u(this._sessionTgt.spec, a, r);
      return a = (0, s.get_cal_from_unix_timestamp_ms)(d, l), i < (0, s.get_year)(a) ? (a = this._builder
        .startOfPeriod(o - 1, i), l = u(this._sessionTgt.spec, a, r), {
          index: (o - 1) / this._period,
          time: l
        }) : {
        index: (0, n.toInt)(o / this._period),
        time: l
      }
    }
    sessionSrc() {
      return this._sessionSrc
    }
    sessionTgt() {
      return this._sessionTgt
    }
    static days(e, t, i) {
      return new p(t, i, e, new S(t), !1)
    }
    static weeks(e, t, i) {
      return new p(t, i, e, new C(t), !1)
    }
    static months(e, t, i) {
      return new p(t, i, e, new T(t), !1)
    }
    static daysFromBusinessDays(e, t) {
      return new p(t, null, e, new S(t), !0)
    }
    static weeksFromBusinessDays(e, t) {
      return new p(t, null, e, new C(t), !0)
    }
    static monthsFromBusinessDays(e, t) {
      return new p(t, null, e, new T(t), !0)
    }
    _getZonedDateTimeOfBorder(e) {
      (0, c.assert)(e === a.SessionStage.FIRST_SESSION_START || e === a.SessionStage.LAST_SESSION_END);
      const t = this._sessionTgt.spec.timezoneObj();
      if (e === a.SessionStage.FIRST_SESSION_START) {
        const e = this.currentRange()
          .from.toCalendar(t);
        return (0, c.ensureNotNull)(this._sessionTgt.spec.bordersOfDailyBar(e))
          .from
      } {
        const e = this.currentRange()
          .to.toCalendar(t);
        return (0, c.ensureNotNull)(this._sessionTgt.spec.bordersOfDailyBar(e))
          .to
      }
    }
    _indexOfPeriodInYear(e) {
      const t = this._builder.indexOfPeriod(e);
      let i = (0, n.toInt)(t / this._period) * this._period;
      return -1 === t && (i = -this._period), i
    }
  }

  function m(e, t) {
    const i = e.getWeekIndex(t),
      o = (0, s.get_day_of_week)(t) - e.getEntriesForWeek(i)
      .firstDayOfWeek();
    return o < 0 ? o + 7 : o
  }

  function g(e, t) {
    const i = (0, s.get_day_of_year)(t) - 1;
    let o = m(e, t) - i % 7;
    return 0 === o ? (0, n.toInt)(i / 7) : (o >= 0 && (o -= 7), (0, n.toInt)((o + i) / 7))
  }
  class f {
    indexOfPeriod(e) {
      return (0, s.get_day_of_year)(e) - 1
    }
    startOfPeriod(e, t) {
      const i = (0, s.days_per_year)(t);
      return (0, s.get_cal)(d, t, s.JANUARY, 1 + Math.min(e, i))
    }
  }
  class y extends f {
    constructor(e) {
      super(), this._sessionsSpec = e
    }
    indexOfPeriod(e) {
      return super.indexOfPeriod(e) - function(e, t) {
        const i = g(e, t),
          o = (0, s.get_cal)(d, (0, s.get_year)(t), s.JANUARY, 1);
        (0, s.add_date)(o, 7 * i);
        const n = i * e.weekEndsCountForSingleSession() + e.holidaysFromYearStart(o),
          r = (0, s.get_day_of_year)(t) - (0, s.get_day_of_year)(o);
        return n + r - e.calendarDaysToBusinessDays(o, r)
      }(this._sessionsSpec, e)
    }
    startOfPeriod(e, t) {
      const i = 7 - this._sessionsSpec.weekEndsCountForSingleSession(),
        o = Math.max(0, Math.trunc(e / i) - 1),
        n = (0, s.get_cal)(d, t, s.JANUARY, 1),
        r = (0, s.days_per_year)(t);
      if ((0, s.add_date)(n, 7 * o), (e -= i * o - this._sessionsSpec.holidaysFromYearStart(n)) > 0) {
        const t = this._sessionsSpec.businessDaysToCalendarDays(n, e);
        (0, s.add_date)(n, t)
      }
      let a = (0, s.get_day_of_year)(n) - 1;
      return t < (0, s.get_year)(n) && (a += r), super.startOfPeriod(a, t)
    }
  }
  class v extends f {
    constructor(e) {
      super(), this._sessionsSpec = e
    }
    indexOfPeriod(e) {
      return super.indexOfPeriod(e) - this._sessionsSpec.daysOffFromYearStart(e)
    }
    startOfPeriod(e, t) {
      const i = (0, s.get_cal)(d, t, s.JANUARY, 1);
      (0, s.add_date)(i, e);
      const o = this._sessionsSpec.daysOffFromYearStart(i);
      (0, s.add_date)(i, o);
      const n = this._sessionsSpec.daysOffFromYearStart(i) - o;
      if (n > 0) {
        const e = this._sessionsSpec.businessDaysToCalendarDays(i, n);
        (0, s.add_date)(i, e)
      }
      let r = (0, s.get_day_of_year)(i) - 1;
      if (t < (0, s.get_year)(i)) {
        r += (0, s.days_per_year)(t)
      }
      return super.startOfPeriod(r, t)
    }
  }
  class S {
    constructor(e) {
      this._builder = null, this._initialized = !1, this._session = e
    }
    indexOfPeriod(e) {
      return this._getBuilder()
        .indexOfPeriod(e)
    }
    startOfPeriod(e, t) {
      return this._getBuilder()
        .startOfPeriod(e, t)
    }
    _getBuilder() {
      return null !== this._builder && this._initialized || (this._session.spec.hasWeekEnds() ? this._builder = this
        ._session.spec.hasHistoryCorrections() ? new v(this._session.spec) : new y(this._session.spec) : this
        ._builder = this._session.spec.hasHistoryCorrections() ? new v(this._session.spec) : new f, this
        ._initialized = !0), this._builder
    }
  }
  class b {
    constructor(e) {
      this._spec = e
    }
    indexOfPeriod(e) {
      let t = g(this._spec, e);
      return 0 === t && e.getTime() < this.startOfPeriod(0, (0, s.get_year)(e))
        .getTime() && (t = -1), t
    }
    startOfPeriod(e, t) {
      if (e < 0) {
        t--;
        const i = (0, s.get_cal)(d, t, s.DECEMBER, 31, 23, 59, 59),
          o = this.indexOfPeriod(i),
          n = -1 * e,
          r = Math.trunc(o / n) * n;
        return this.startOfPeriod(r, t)
      }
      const i = (0, s.get_cal)(d, t, s.JANUARY, 1),
        o = m(this._spec, i),
        n = 0 === o ? 7 * e : 7 * (e + 1) - o;
      return n > (0, s.days_per_year)((0, s.get_year)(i)) ? this.startOfPeriod(0, t + 1) : ((0, s.add_date)(i, n), i)
    }
  }
  class w {
    constructor(e) {
      this._yearStartDataHash = new Map, this._spec = e
    }
    startOfPeriod(e, t) {
      if (e < 0) {
        t--;
        const i = (0, s.get_cal)(d, t, s.DECEMBER, 31, 23, 59, 59),
          o = this.indexOfPeriod(i),
          n = -1 * e,
          r = Math.trunc(o / n) * n;
        return this.startOfPeriod(r, t)
      }
      const i = this._spec.getWeekIndicesWithAdditionalWeekBars(t),
        o = this._getStartOfYearData(t, i),
        n = this._moveToWeekIndexAccountingAdditional(o.firstWeekIndex, i, e),
        r = 7 * (n - o.firstWeekIndex);
      let a = (0, s.clone)((0, c.ensureNotNull)(o.startOfFirstBarInYear));
      if ((0, s.add_date)(a, r), (0, s.get_year)(a) > t) {
        const e = t + 1,
          i = this._spec.getWeekIndicesWithAdditionalWeekBars(e),
          s = this._getStartOfYearData(e, i);
        if (a.getTime() >= (0, c.ensureNotNull)(s.startOfFirstBarInYear)
          .getTime()) return this.startOfPeriod(0, e)
      }
      return a = this._calculateBarWeekStart(a, i, n, e), a
    }
    indexOfPeriod(e) {
      const t = this._spec.getWeekIndex(e),
        i = this._spec.getWeekIndicesWithAdditionalWeekBars((0, s.get_year)(e)),
        o = this._getStartOfYearData((0, s.get_year)(e), i);
      if (e.getTime() < (0, c.ensureNotNull)(o.startOfFirstBarInYear)
        .getTime()) return -1;
      if (0 === t && w.isOnFirstCalendarWeekOfYear(e) || 0 !== t && t === o.firstWeekIndex) return this
        ._calculateLastWeek(e, t, i, o.firstWeekbarsCount) - 1;
      let n = this._numberOfCalendarWeeks(e);
      return n += o.firstWeekbarsCount - o.fullWeeksAdjustment, n += this._calculateWeeksWithExtraBar(t, i, o
          .firstWeekIndex),
        n += this._calculateLastWeek(e, t, i, w.fullWeekOfAdditionalBarsCount) - 1, n
    }
    static isOnFirstCalendarWeekOfYear(e) {
      if ((0, s.get_day_of_year)(e) > s.LAST_DAY_OF_WEEK) return !1;
      const t = (0, s.get_cal)(d, (0, s.get_year)(e), s.JANUARY, 1, 0, 0),
        i = (0, s.clone)(t);
      return (0, s.add_date)(i, s.LAST_DAY_OF_WEEK - (0, s.get_day_of_week)(t)), e.getTime() < i.getTime()
    }
    _moveToWeekIndexAccountingAdditional(e, t, i) {
      let s = e + i;
      for (const i of t)
        if (!(i.weekIndex < e)) {
          if (i.weekIndex >= s) break;
          s--
        } return s
    }
    _calculateBarWeekStart(e, t, i, o) {
      const n = this._getIndexOfWeekWithExtraBarIfExists(t, i);
      if (null === n) {
        const t = this._spec.getEntriesForWeek(i)
          .firstDayOfWeek() - (0, s.get_day_of_week)(e),
          o = (0, s.clone)(e);
        return (0, s.add_date)(o, t), o
      }
      const r = this._spec.getHistoryByIndex(n.entryIndex);
      if (this.indexOfPeriod((0, c.ensureNotNull)(r.getStartDay())) === o) return (0, s.clone)((0, c.ensureNotNull)(r
        .getStartDay()));
      const a = this._spec.getHistoryByIndex(n.entryIndex - 1)
        .getEntries()
        .firstDayOfWeek() - (0, s.get_day_of_week)(e),
        l = (0, s.clone)(e);
      return (0, s.add_date)(l, a), l
    }
    _numberOfCalendarWeeks(e) {
      const t = (0, s.get_day_of_year)(e),
        i = (0, s.get_day_of_week)(e);
      return Math.trunc((t - i) / 7)
    }
    _getStartOfYearData(e, t) {
      let i = this._yearStartDataHash.get(e);
      if (void 0 !== i) return i;
      let o = (0, s.get_cal)(d, e, s.JANUARY, 1, 0, 0),
        n = this._spec.getWeekIndex(o),
        r = 0;
      for ((0, s.get_day_of_week)(o) === s.FIRST_DAY_OF_WEEK && (r = 1), i = this._getYearStartDataFromWeek(t, n,
        o); null === i.startOfFirstBarInYear;) n++, r++, o = this._moveToNextCalendarWeekStart(o), i = this
        ._getYearStartDataFromWeek(t, n, o);
      return i.fullWeeksAdjustment = r, this._yearStartDataHash.set(e, i), i
    }
    _moveToNextCalendarWeekStart(e) {
      const t = (0, s.get_day_of_week)(e),
        i = (0, s.clone)(e);
      return (0, s.add_date)(i, s.LAST_DAY_OF_WEEK - t + 1), i
    }
    _getYearStartDataFromWeek(e, t, i) {
      const o = (0, s.get_day_of_week)(i);
      let n = null,
        r = 0;
      const a = this._getIndexOfWeekWithExtraBarIfExists(e, t);
      if (null !== a) {
        let e = this._spec.getHistoryByIndex(a.entryIndex - 1)
          .getEntries()
          .firstDayOfWeek() - o;
        if (e >= 0) n = (0, s.clone)(i), (0, s.add_date)(n, e), r = 2;
        else {
          const t = this._spec.getHistoryByIndex(a.entryIndex);
          e = t.getEntries()
            .firstDayOfWeek() - o, e >= 0 && (n = t.getStartDay(), n && (n = (0, s.clone)(n)), r = 1)
        }
      } else {
        const e = this._spec.getEntriesForWeek(t),
          a = e.firstDayOfWeek() - o;
        a >= 0 && (this._hasWorkingDays(e) || this._hasWorkingDaysNextWeek(t + 1)) && (n = (0, s.clone)(i), (0, s
          .add_date)(n, a), r = 1)
      }
      return {
        startOfFirstBarInYear: n,
        firstWeekIndex: t,
        firstWeekbarsCount: r,
        fullWeeksAdjustment: 0
      }
    }
    _hasWorkingDays(e) {
      if (0 === e.entriesByDay()
        .size) return !1;
      for (let t = e.firstDayOfWeek(); t <= s.LAST_DAY_OF_WEEK; t++)
        if (void 0 !== e.entriesByDay()
          .get(t)) return !0;
      return !1
    }
    _hasWorkingDaysNextWeek(e) {
      const t = this._spec.getEntriesForWeek(e);
      for (let e = 1; e < t.firstDayOfWeek(); e++)
        if (void 0 !== t.entriesByDay()
          .get(e)) return !0;
      return !1
    }
    _calculateWeeksWithExtraBar(e, t, i) {
      let s = 0;
      for (const o of t) {
        if (o.weekIndex >= e) break;
        o.weekIndex > i && s++
      }
      return s
    }
    _calculateLastWeek(e, t, i, o) {
      const n = (0, s.get_day_of_week)(e),
        r = this._getIndexOfWeekWithExtraBarIfExists(i, t);
      if (null === r) {
        return n - this._spec.getEntriesForWeek(t)
          .firstDayOfWeek() >= 0 ? 1 : 0
      }
      const a = this._positionInsideWeekWithSeveralBars(r, n);
      return a === w.IsInNewSession ? o : a === w.IsInMidSession ? o - 1 : 0
    }
    _getIndexOfWeekWithExtraBarIfExists(e, t) {
      for (const i of e) {
        if (i.weekIndex === t) return i;
        if (i.weekIndex > t) break
      }
      return null
    }
    _positionInsideWeekWithSeveralBars(e, t) {
      let i = this._spec.getHistoryByIndex(e.entryIndex)
        .getEntries()
        .firstDayOfWeek() - t;
      if (i <= 0) return w.IsInNewSession;
      return i = this._spec.getHistoryByIndex(e.entryIndex - 1)
        .getEntries()
        .firstDayOfWeek() - t, i <= 0 ? w.IsInMidSession : w.IsBeforeAnySession
    }
  }
  w.IsBeforeAnySession = -1, w.IsInMidSession = 0, w.IsInNewSession = 1, w.fullWeekOfAdditionalBarsCount = 2;
  class C {
    constructor(e) {
      this._builder = null, this._session = e
    }
    indexOfPeriod(e) {
      return this._getBuilder()
        .indexOfPeriod(e)
    }
    startOfPeriod(e, t) {
      return this._getBuilder()
        .startOfPeriod(e, t)
    }
    _getBuilder() {
      return null == this._builder && (this._builder = this._session.spec.hasHistoryCorrections() ? new w(this
        ._session.spec) : new b(this._session.spec)), this._builder
    }
  }
  class T {
    constructor(e) {
      this._session = e
    }
    indexOfPeriod(e) {
      return (0, s.get_month)(e)
    }
    startOfPeriod(e, t) {
      if (e < 0) {
        const i = (0, n.toInt)((11 - e) / 12);
        t -= i, e += 12 * i
      } else e > s.DECEMBER && (t++, e = s.JANUARY);
      return (0, s.get_cal)(d, t, e, 1)
    }
  }
  var P, x;

  function M(e, t, i, s = !1) {
    const n = o.Interval.parse(e),
      r = n.multiplier();
    return n.isMinutes() ? l.minutes(r, t) : n.isSeconds() ? l.seconds(r, t) : n.isTicks() ? new l(1, t) : n.isRange() ?
      new l(60 * r, t) : new p(t, i ?? null, r, function(e, t) {
        switch (e) {
          case o.ResolutionKind.Days:
            return new S(t);
          case o.ResolutionKind.Weeks:
            return new C(t);
          case o.ResolutionKind.Months:
            return new T(t)
        }
        throw new Error(`Unknown dwm resolution: ${e}`)
      }(n.kind(), t), s)
  }

  function I(e, t, i, s, o, n, r) {
    return L(e, t, i, s, o, n, r, 0)
  }

  function A(e, t, i, s, o, n, r) {
    return L(e, t, i, s, o, n, r, 1)
  }

  function L(e, t, i, n, a, l, c, h) {
    const d = o.Interval.parse(a + n);
    if (d.isMonths()) {
      const e = new Date(c);
      return 0 === h && e.setUTCDate(1),
        function(e, t) {
          B(e, Math.floor(t / 12));
          let i = e.getUTCMonth() - t % 12;
          i < 0 && (B(e, 1), i += 12);
          e.setUTCMonth(i);
          for (; e.getUTCMonth() !== i;) V(e, 1)
        }(e, l * d.multiplier()), e.getTime()
    }
    const u = new r.SessionInfo("Etc/UTC", e, t, i),
      _ = d.inMilliseconds(),
      p = d.isDWM();
    let m;
    if (p) m = 864e5;
    else {
      const e = u.spec.getWeekIndex((0, s.get_cal_from_unix_timestamp_ms)(u.timezone, c));
      m = 60 * u.spec.getEntriesForWeek(e)
        .maxTradingDayLength() * 1e3
    }
    let g = 0;
    if (d.isWeeks()) g = 7;
    else {
      const e = u.spec.getWeekIndex((0, s.get_cal_from_unix_timestamp_ms)(u.timezone, c));
      g = 7 - u.spec.getEntriesForWeek(e)
        .weekEndsCount()
    }
    const f = m / _,
      y = g * f;
    let v;
    if (l < y) v = l / f;
    else {
      v = 7 * (l / y)
    }
    return p && (v = Math.floor(v)), c - 864e5 * v
  }

  function k(e, t, i, n, a, l, c) {
    const h = o.Interval.parse(a + n);
    if (h.isMonths()) {
      const e = new Date(l),
        t = new Date(c);
      let i = 12 * (t.getUTCFullYear() - e.getUTCFullYear());
      return i += t.getUTCMonth() - e.getUTCMonth(), Math.ceil(i / h.multiplier())
    }
    const d = new r.SessionInfo("Etc/UTC", e, t, i),
      u = h.inMilliseconds();
    let _;
    if (h.isDWM()) _ = 864e5;
    else {
      const e = d.spec.getWeekIndex((0, s.get_cal_from_unix_timestamp_ms)(d.timezone, c));
      _ = 60 * d.spec.getEntriesForWeek(e)
        .maxTradingDayLength() * 1e3
    }
    let p = 0;
    if (h.isWeeks()) p = 7;
    else {
      const e = d.spec.getWeekIndex((0, s.get_cal_from_unix_timestamp_ms)(d.timezone, c));
      p = 7 - d.spec.getEntriesForWeek(e)
        .weekEndsCount()
    }
    const m = c - l,
      g = _ / u,
      f = p * g;
    let y = m / 864e5 * g;
    y >= f && (y = m / 6048e5 * f);
    return y % 1 <= Number.EPSILON * Math.ceil(y) ? Math.round(y) : Math.ceil(y)
  }

  function E(e, t) {
    const i = (0, s.clone)(t);
    return e.alignToSessionStart(i), (0, s.cal_to_utc)((0, s.get_timezone)(e.timezone()), i)
  }

  function D(e, t) {
    const i = (0, s.utc_to_cal)(t.timezone, +e);
    let o = (0, s.get_day_of_week)(i),
      n = (0, s.get_minutes_from_midnight)(i);
    const r = t.spec.findSession(t.spec.getWeekIndex(i), o, n)
      .getEntry();
    return r.isOvernight() && n > r.startOffset() + r.length() && o === r.dayOfWeek() - 1 && (o++, n -= 1440), o === r
      .dayOfWeek() && n >= r.startOffset() && n < r.startOffset() + r.length()
  }

  function B(e, t) {
    const i = e.getUTCMonth();
    e.setUTCFullYear(e.getUTCFullYear() - t), e.getUTCMonth() !== i && V(e, 1)
  }

  function V(e, t) {
    e.setTime(e.getTime() - 864e5 * t)
  }! function(e) {
    e[e.AlignToFirstDay = 0] = "AlignToFirstDay", e[e.AlignToClosestDay = 1] = "AlignToClosestDay"
  }(P || (P = {})),
  function(e) {
    e[e.D = 864e5] = "D", e[e.W = 6048e5] = "W"
  }(x || (x = {}))
